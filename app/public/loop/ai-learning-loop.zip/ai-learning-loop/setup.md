# Setup: the AI learning loop prompt

The prompt goes in your agent's instructions file, the file it reads at the start of every session. Put it there once and the loop runs every time.

## Claude Code
- Every project: paste it into `~/.claude/CLAUDE.md`. Create the file if it doesn't exist.
- One project: paste it into `CLAUDE.md` in the project's root folder.

## Codex
- Every project: paste it into `~/.codex/AGENTS.md`.
- One project: paste it into `AGENTS.md` in the project's root folder.

## Cursor
- Every project: open Cursor Settings, go to Rules and add it as a User Rule.
- One project: paste it into `AGENTS.md` in the project's root folder.

## Claude or ChatGPT in the browser
- Make a Project and paste it into the project's instructions. Every chat in that project uses it.

## Check it works
Open a new session and ask for something small, like "build me a landing page for my gym". If it asks you questions before it writes anything, the loop is running. If it starts building straight away, restart the agent so it reloads the file.
