# Lenny's Podcast knowledge base: index

35 recent episodes of [Lenny's Podcast](https://www.youtube.com/@LennysPodcast/videos), from 7 December 2025 to 31 May 2026. Each one has a digest at `episodes/<slug>/summary.md`: a one-line summary, the key lessons, the frameworks, a few short quotes and a link to the full episode on YouTube.

Want the older episodes? The full back catalogue of transcripts lives in the public archive at https://github.com/ChatPRD/lennys-podcast-transcripts.

## Start here, by question

| If your question is about | Open these first |
|---|---|
| Building AI products and agents | `aishwarya-naresh-reganti-kiriti-badam`, `inside-openai-2026-agents`, `cat-wu`, `boris-cherny`, `sherwin-wu` |
| AI security, prompt injection, trust | `sander-schulhoff`, `ai-state-of-the-union-2026`, `claire-vo` |
| The PM role, careers and hiring | `nikhyl-singhal`, `professional-vibe-coder`, `zevi-arnovitz`, `anthropic-head-of-growth`, `jessica-fain`, `jacob-warwick` |
| Growth, pricing and go to market | `elena-verna`, `jason-cohen`, `jason-m-lemkin`, `brian-halligan`, `evan-spiegel` |
| Strategy, moats and where value goes | `the-most-rational-take-on-ai`, `marc-andreessen`, `matt-macinnis`, `low-heart-rate-etiquette` |
| Leadership, teams and culture | `molly-graham`, `becky-kennedy`, `keith-rabois`, `eric-ries`, `jenny-wen`, `max-schoening` |
| Evals, data and model quality | `edwin-chen`, `aishwarya-naresh-reganti-kiriti-badam`, `cat-wu` |
| Physical AI and hardware | `caitlin-kalinowski`, `qasar-younis` |

## Full catalogue

Newest first. Click an episode to open its digest.

| Date | Episode | Guest | Topics |
|------|---------|-------|--------|
| 2026-05-31 | [The most rational take on AI you'll hear this year](episodes/the-most-rational-take-on-ai/summary.md) | Benedict Evans | ai strategy, platform shifts, foundation models, jobs and automation, value capture, distribution |
| 2026-05-24 | [AI predictions: Job markets, Codex beats Claude, and the death of org charts \| Dan Shipper](episodes/dan-shipper/summary.md) | Dan Shipper | ai agents, future of work, saas, product management, ai adoption, org design |
| 2026-05-17 | [Why the next AI boom is physical AI \| Caitlin Kalinowski (ex-OpenAI, Meta, Apple)](episodes/caitlin-kalinowski/summary.md) | Caitlin Kalinowski | physical ai, robotics, hardware, supply chain, ai safety, team building |
| 2026-05-10 | [How Anthropic, Costco, and Patagonia all build incorruptible companies \| Eric Ries](episodes/eric-ries/summary.md) | Eric Ries | governance, founder control, ai labs, mission-driven companies, leadership, ipo |
| 2026-05-02 | [AI era skills: Why cultivating agency matters more than job titles \| Max Schoening (Notion)](episodes/max-schoening/summary.md) | Max Schoening | ai agents, product building, design, malleable software, team operations, taste |
| 2026-04-26 | [How to win when software is not a moat \| Evan Spiegel (Snapchat CEO)](episodes/evan-spiegel/summary.md) | Evan Spiegel | consumer product, distribution, design, moats, ai agents, leadership |
| 2026-04-23 | [How Anthropic's product team moves faster than anyone else \| Cat Wu (Head of Product, Claude Code)](episodes/cat-wu/summary.md) | Cat Wu | ai product management, ai agents, shipping velocity, evals, enterprise ai adoption, ai coding tools |
| 2026-04-19 | [Why half of product managers are in trouble \| Nikhyl Singhal (Meta, Google)](episodes/nikhyl-singhal/summary.md) | Nikhyl Singhal | career, product management, ai agents, hiring, leadership, vibe coding |
| 2026-04-12 | [Hard truths about building in the AI era \| Keith Rabois (Khosla Ventures)](episodes/keith-rabois/summary.md) | Keith Rabois | hiring, team building, leadership, ai era, venture, product management |
| 2026-04-05 | [Head of Growth (Anthropic): Anthropic is automating its own growth](episodes/anthropic-head-of-growth/summary.md) | Amol Avasare | growth, ai agents, activation, pm role, automation, leadership |
| 2026-04-02 | [An AI state of the union: We've passed the inflection point & dark factories are coming](episodes/ai-state-of-the-union-2026/summary.md) | Simon Willison | ai coding agents, ai security, prompt injection, agentic engineering, ai adoption, agents in production |
| 2026-03-29 | [From skeptic to true believer: How OpenClaw changed my life \| Claire Vo](episodes/claire-vo/summary.md) | Claire Vo | ai agents, agent design, ai security, personal productivity, automation, founder ops |
| 2026-03-22 | [The art of influence: The single most important skill left that AI can't replace \| Jessica Fain](episodes/jessica-fain/summary.md) | Jessica Fain | influence, executive stakeholders, product leadership, ai agents, career growth |
| 2026-03-15 | [He's negotiated $1B+ in executive compensation. Here's his playbook. \| Jacob Warwick](episodes/jacob-warwick/summary.md) | Jacob Warwick | career, negotiation, compensation, leadership, psychology, personal growth |
| 2026-03-12 | [A behind-the-scenes interview with Lenny Rachitsky on building his newsletter and podcast](episodes/lenny-rachitsky-behind-the-scenes/summary.md) | Lenny Rachitsky | creator economy, newsletter growth, product management, founder mindset, creativity, personal story |
| 2026-03-08 | [The real AI revolution isn't software. It's farms, mines, and trucks. \| Qasar Younis](episodes/qasar-younis/summary.md) | Qasar Younis | physical ai, autonomous vehicles, company culture, founder advice, china vs us, ai anxiety |
| 2026-03-01 | [The design process is dead. Here's what's replacing it. \| Jenny Wen (head of design at Claude)](episodes/jenny-wen/summary.md) | Jenny Wen | design, ai tools, product development, hiring, leadership |
| 2026-02-26 | [AI is critical for humanity's survival: Cisco President on the AI revolution \| Jeetu Patel](episodes/jeetu-patel/summary.md) | Jeetu Patel | enterprise ai adoption, ai infrastructure, leadership, product strategy, company building, ai safety |
| 2026-02-19 | [Head of Claude Code: What happens after coding is solved \| Boris Cherny](episodes/boris-cherny/summary.md) | Boris Cherny | ai agents, ai coding, product strategy, ai safety, leadership, future of work |
| 2026-02-15 | [How to be a CEO when AI breaks all the old playbooks \| Sequoia CEO Coach Brian Halligan](episodes/brian-halligan/summary.md) | Brian Halligan | ceo coaching, hiring, ai gtm, leadership, scaling, enterprise sales |
| 2026-02-12 | [OpenAI's head of platform engineering on the next 12-24 months of AI \| Sherwin Wu](episodes/sherwin-wu/summary.md) | Sherwin Wu | ai agents, enterprise ai adoption, engineering management, business process automation, platform strategy, ai roi |
| 2026-02-08 | [The rise of the professional vibe coder (a new AI-era job)](episodes/professional-vibe-coder/summary.md) | Lazar Jovanovic | vibe coding, ai tools, product management, career, design, prototyping |
| 2026-02-01 | [A child psychologist's guide to working with difficult adults \| Dr. Becky Kennedy](episodes/becky-kennedy/summary.md) | Dr. Becky Kennedy | leadership, management, feedback, psychological safety, communication, company building |
| 2026-01-29 | [Marc Andreessen: The real AI boom hasn't even started yet](episodes/marc-andreessen/summary.md) | Marc Andreessen | ai future, careers, founders, venture capital, moats, education |
| 2026-01-25 | [The surprising advice from a founder who built 2 unicorns \| Jason Cohen (WP Engine)](episodes/jason-cohen/summary.md) | Jason Cohen | growth, churn, pricing, positioning, nrr, gtm channels |
| 2026-01-18 | [How a Meta PM ships products without ever writing code \| Zevi Arnovitz](episodes/zevi-arnovitz/summary.md) | Zevi Arnovitz | ai coding, vibe coding, pm workflow, non-technical builder, career, ai agents |
| 2026-01-15 | [How to show up in any room with a low heart rate: Silicon Valley's missing etiquette playbook](episodes/low-heart-rate-etiquette/summary.md) | Sam Lessin | etiquette, founder skills, trust building, ai investing, vibe coding |
| 2026-01-11 | [Why most AI products fail: Lessons from 50+ AI deployments at OpenAI, Google & Amazon](episodes/aishwarya-naresh-reganti-kiriti-badam/summary.md) | Aishwarya Naresh Reganti + Kiriti Badam | ai agents, ai product development, evals, enterprise ai adoption, human-in-the-loop, ai reliability |
| 2026-01-04 | [\"I like being scared\": Molly Graham's frameworks for rapid career growth](episodes/molly-graham/summary.md) | Molly Graham | leadership, career growth, scaling, org design, okrs, culture |
| 2026-01-01 | [We replaced our sales team with 20 AI agents, here's what happened next \| Jason Lemkin (SaaStr)](episodes/jason-m-lemkin/summary.md) | Jason M. Lemkin | sales hiring, gtm, plg vs sales-led, pricing, product-sales alignment, saas metrics |
| 2025-12-28 | [\"I deliberately understaff every project\" \| Leadership lessons from Rippling's $16B journey](episodes/matt-macinnis/summary.md) | Matt MacInnis | leadership, hiring, product management, ai strategy, product market fit, startups |
| 2025-12-21 | [Why securing AI is harder than anyone expected and guardrails are failing \| HackAPrompt CEO](episodes/sander-schulhoff/summary.md) | Sander Schulhoff | ai security, ai agents, prompt injection, guardrails, ai governance, enterprise ai |
| 2025-12-18 | [The new AI growth playbook for 2026 \| How Lovable hit $200M ARR in one year](episodes/elena-verna/summary.md) | Elena Verna | growth, ai products, product-market fit, pricing, gtm, hiring |
| 2025-12-14 | [Inside OpenAI: 2026 is the year of agents, AI's biggest bottleneck, and why compute isn't the issue](episodes/inside-openai-2026-agents/summary.md) | Alexander Embiricos | ai agents, coding agents, product management, agent ux, human-in-the-loop, openai |
| 2025-12-07 | [The $1B AI company training ChatGPT, Claude & Gemini on the path to responsible AGI \| Edwin Chen](episodes/edwin-chen/summary.md) | Edwin Chen | ai data labeling, rl environments, model evals, ai alignment, bootstrapping, founder strategy |

## Themes that run across the episodes

**Agents are reaching production faster than teams can check their work, and human review is now the bottleneck.** The question has moved from "can the model do it?" to "can a person trust it, verify it and own the result?" Codex grew 20x with human review speed named as the limit. OpenAI runs every pull request through Codex but still keeps human checkpoints. Anthropic tests features internally for four to five months before release. The lesson from 50+ deployments: climb the ladder of autonomy one rung at a time, and never start at full autonomy. (inside-openai-2026-agents, sherwin-wu, boris-cherny, cat-wu, aishwarya-naresh-reganti-kiriti-badam)

**Guardrails alone don't hold. What holds is architecture, permissions and a person who is accountable.** Simon Willison puts the best prompt-injection filters at around 97%, which he calls a failing grade: three attacks in a hundred still get through. Sander Schulhoff's version is that you "can't patch a brain". The fix they describe is structural. Cut one leg of the "lethal trifecta" (usually the ability to send data out), give agents only the permissions they need, and keep a human in the loop who can contain damage. (sander-schulhoff, ai-state-of-the-union-2026, boris-cherny, caitlin-kalinowski)

**"Automation is a lie": every agent needs a human who cares about it.** Builders, designers and operators say nearly the same sentence. Augment people rather than replace them, give every agent a named owner, and widen its trust step by step. Dan Shipper's super-agent has a forward-deployed engineer who owns it. Claire Vo onboards her agents like employees. Anthropic's growth team approves the experiments its AI runs. (dan-shipper, claire-vo, max-schoening, anthropic-head-of-growth, jenny-wen, jessica-fain)

**In big companies, adoption is the bottleneck, not capability, and top-down AI mandates lose money.** Several enterprise insiders describe a trust deficit and a wide gap between what the models can do and what actually gets rolled out. The failure mode is a mandate from the top with no pull from the people doing the work. The fix they describe is a small "tiger team" that enables other teams instead of blocking them. Coding is the breakout use case. Every other function needs its own rollout. (jeetu-patel, sherwin-wu, brian-halligan, max-schoening, inside-openai-2026-agents)

**The PM role is splitting in two.** Non-technical people now ship production apps with Lovable, Cursor and Claude Code. The PM who mainly moves information between people is in trouble, and the PM who builds is doing well. (nikhyl-singhal, professional-vibe-coder, zevi-arnovitz, marc-andreessen, max-schoening)

**Software on its own is not a moat.** Models are becoming commodities and value is moving up the stack. Thin AI point tools get crushed unless they own first-party data or sell the picks and shovels. Sam Lessin argues the lasting businesses deal with the implications of AI rather than calling themselves AI companies. (the-most-rational-take-on-ai, evan-spiegel, matt-macinnis, low-heart-rate-etiquette, marc-andreessen)

**Governance has moved to the boardroom.** Eric Ries walks through how Anthropic set itself up as a public benefit corporation with a Long-Term Benefit Trust, so saying no to a dangerous launch is built into the structure. His line: a slogan is not enough, "show me the apparatus". (eric-ries, edwin-chen, caitlin-kalinowski)

**Evals only catch what you expected. Production monitoring catches the rest.** The CCCD calibration loop and Edwin Chen's case that "benchmarks lie" make the same point: static tests are not enough, and you need to watch real usage to find the failures nobody imagined. (aishwarya-naresh-reganti-kiriti-badam, edwin-chen, ai-state-of-the-union-2026, cat-wu)

## A note on quotes

Most of these episodes were digested from YouTube auto-captions, so quotes are close to what was said but not always word-for-word. Before you quote someone in public, check the episode link in the digest.
