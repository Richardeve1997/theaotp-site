# Lenny's Podcast knowledge base

Ask any product question and get answers from what Lenny's Podcast guests actually said, credited to the guest and the episode.

This folder has digests of 35 recent episodes of [Lenny's Podcast](https://www.lennyspodcast.com/), from December 2025 to May 2026. Each digest has the key lessons, the frameworks, a few short quotes and a link to the full episode on YouTube. It also includes `lenny-wisdom`, a skill that tells an AI assistant how to use the digests: find the right episodes, answer with citations and show where guests disagree.

## What's inside

```
lennys-podcast-knowledge-base/
├── README.md             this file
├── index.md              start here: every episode, topics, a "start here" table, cross-episode themes
├── all-episodes.md       all 35 digests in one file (for tools that want fewer uploads)
├── episodes/<slug>/
│   └── summary.md        one digest per episode
└── lenny-wisdom/
    └── SKILL.md          the skill for Claude Code (and Codex)
```

## What it covers, honestly

- **35 episodes, 7 December 2025 to 31 May 2026.** Full episodes only, no clips.
- **Digests, not transcripts.** They are summaries. For a full transcript, follow the YouTube link in each digest.
- **The back catalogue lives elsewhere.** Hundreds of older episodes have full transcripts in the public archive at https://github.com/ChatPRD/lennys-podcast-transcripts. Add those files next to this folder if you want older episodes in scope.
- **Quotes are close, not always exact.** Most digests were made from YouTube auto-captions. Check the episode before quoting anyone in public.

## Set it up in Claude Code

1. Unzip this folder into your project, so you have `your-project/lennys-podcast-knowledge-base/`.
2. Copy the skill into your project's skills folder:

   ```bash
   cd your-project
   mkdir -p .claude/skills
   cp -R lennys-podcast-knowledge-base/lenny-wisdom .claude/skills/
   ```

3. Start Claude Code in that project and ask a question, for example: "What would Lenny's guests say about pricing an AI feature?" You can also call it by name with `/lenny-wisdom`.

To use the skill in every project, copy `lenny-wisdom` into `~/.claude/skills/` instead. Keep the `lennys-podcast-knowledge-base/` folder in whichever project you are working in, because that is where the skill looks.

Using Codex? Same idea: copy `lenny-wisdom` into `.agents/skills/` in your project.

## Set it up as a Claude Project

1. In Claude, create a new Project.
2. Add `index.md` and `all-episodes.md` to the project knowledge. (You can upload the 35 individual `summary.md` files instead of `all-episodes.md` if you prefer.)
3. Paste this into the project instructions:

   ```
   Answer my questions using only the Lenny's Podcast digests in this project's knowledge.
   Start from index.md to find the 3 to 6 most relevant episodes, then read their digests.
   Credit every point to the guest and the episode. Show where guests disagree, not just
   where they agree. If the digests don't cover my question, say so and label your own
   reasoning as yours. Answer in this shape: Take, What the guests say, Counter-signals
   and risks, What to do next.
   ```

4. Ask away.

## Set it up in ChatGPT

**In a ChatGPT Project:** create a project, add `index.md` and `all-episodes.md` as project files, and paste the same instructions from the Claude Project step above into the project instructions.

**As a custom GPT:** create a GPT, paste the same instructions into Instructions, and upload `index.md` and `all-episodes.md` under Knowledge. Custom GPTs limit how many knowledge files you can add, which is why the single combined file is there.

## Credit

The conversations belong to Lenny Rachitsky and his guests. Listen at https://www.lennyspodcast.com/. The digests are summaries for personal reference; each one links to the original episode.
