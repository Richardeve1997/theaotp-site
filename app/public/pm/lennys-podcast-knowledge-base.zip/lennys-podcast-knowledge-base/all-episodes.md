# Lenny's Podcast knowledge base: all 35 episode digests in one file

Every digest from `episodes/<slug>/summary.md`, newest first, in a single file for tools that prefer fewer uploads. Each digest starts with its slug so you can cite it.


---

<!-- slug: the-most-rational-take-on-ai -->
## The most rational take on AI you'll hear this year

**Benedict Evans** · 2026-05-31 · [▶ Watch](https://www.youtube.com/watch?v=BD3vLtWhT5A)

> Benedict Evans on why AI is "as big as the internet, and only as big," why we're stuck in 1997, and where value really accrues.

**Topics:** ai strategy, platform shifts, foundation models, jobs and automation, value capture, distribution

### Key lessons
- The 1997 frame: AI is as big as the internet/mobile and only as big, most of what will be built hasn't been built, nothing really works end-to-end yet, and even his own 80-slide deck 'mostly says we don't know.' Treat current model-race calls (OpenAI vs Anthropic) like guessing Excite vs Yahoo in 1997.
- Task vs job is the central diagnostic: ask 'what is the hard part?' A spreadsheet automates the accountant's calculation but the number of accountants kept rising all century (two charts in his deck). Claude Code writes the code, but knowing WHAT code/features/customer is the actual job. The PowerPoint is the task; what you pay McKinsey for is walking your org, the politics, and talking to customers.
- Why AI labs are buying consultancies/PE and hiring forward-deployed engineers: companies have no spare staff to reimagine workflows. Mapping which workflows to automate is a 5-10 person, 1-2 month project, and implementing is another project, so the labs themselves staff up. A forward-deployed engineer is 'an Accenture outsourced developer who works in San Francisco.'
- Foundation models likely lack pricing power: no network effects, no winner-take-all, undifferentiated commodity selling at marginal cost. Analogy to telecom, global mobile is ~$1T revenue, ~$200B/yr capex (15-20% of revenue), data consumption up 1,500-2,000x since 2010, yet stocks went nowhere for 25 years because the value sat further up the stack. He rebuts Altman's 'AI sold on a meter like electricity', TV makers don't pay the utility a cut.
- The model is 'the dumb thing underneath' that powers features; value moves up-stack. Browsers (Microsoft won browsers for 5-6 years and got nothing) and AWS (customers don't standardize on a cloud) are the templates, NOT Windows. If it must be apps and labs can't build them all, the value goes to app builders.
- Jobs: the lump-of-labor / lump-of-labour fallacy, since 1800 each tech kills crap jobs and creates better ones you can't name in advance ('railway engineer, who'd want to go that fast?'). Enterprise reality slows the apocalypse: 18-month sales cycles, no one rips out SAP overnight; the estate looks radically different in 3-10 years, not two weeks. Even Anthropic/OpenAI are increasing headcount.
- Adoption is fast because you stand on giants' shoulders: ChatGPT hit ~900M weekly users only because ~5.5-6B smartphones and 900M internet users already existed (Netscape in '94 had only 50-100M PCs). But people still don't know HOW to rebuild their business, most SaaS firms born pre-ChatGPT could have existed 15 years earlier; the lag is realizing the use case.
- The anti-AI backlash is a 'fuzzy mess', separate the real from the fake. Data-center water use is ~0.017% of US consumption (Livermore Lab, end-2024), a local planning problem, not a data-center problem. Energy (~5%, growing ~1 percentage point/yr) and youth-employment slowdowns are more real but not yet conclusively AI-caused. Crucially: labs publish NO daily-active-user numbers, so all data is economists backing it out of BLS surveys.

### Frameworks & mental models
- Task vs Job (what's the actual hard part you're hired for)
- The 1997 analogy / presume radical uncertainty
- Lump-of-labour fallacy + price elasticity (Jevons paradox)
- Capital / Deployment / Change (his deck's three sections)
- 'Do the old thing but more' -> then redefine the question entirely (U-shaped recorded-music revenue curve)
- Cloud-not-Windows model for value capture up the stack
- Skills x Jobs-it-enables x What-people-pay-for (want at least 2 of 3)

### Notable quotes
> “AI is whatever machines can't do yet, because once machines can do it, people say 'well that's just software.'”

> “You can't look at a senior partner at a law firm and say 'well, 17% of their work could be automated', this is horseshit. You can't do that.”

> “My dear sweet child, you need me to explain the margin structure of the utility industry to you... when you watch television the TV company isn't paying a percentage of your bill to the electricity company.”

> “Don't stick your head in the sand and say 'I hate all of this.' That gives you a great feeling of moral superiority and you can go on Blue Sky and shout about how evil AI is. Great. But that's not going to help. What helps is diving in and coming out understanding what you can do with it.”


---

<!-- slug: dan-shipper -->
## AI predictions: Job markets, Codex beats Claude, and the death of org charts | Dan Shipper

**Dan Shipper** · 2026-05-24 · [▶ Watch](https://www.youtube.com/watch?v=4D3hDmGhFhA)

> Every's CEO predicts work shifts into agent harnesses (Codex/Co-work), SaaS survives and thrives, and every agent still needs a human who cares about it.

**Topics:** ai agents, future of work, saas, product management, ai adoption, org design

### Key lessons
- The 'super agent' beats personal agents for now: Shipper initially believed everyone would have their own agent (Open Claw / a 'parallel shadow org chart'), but flipped to one company-wide agent (like Shopify's River, Ramp's agent) because personal agents are too fiddly to maintain. The mechanism: agents need a human who cares about them, so start with one general agent at the top owned by a forward-deployed engineer, then specialize downward as models get more independent.
- Work is bifurcating into two surfaces: (1) async agents you delegate to, mostly in Slack (kept separate from personal-life agents), and (2) a coding-agent harness (Codex, Claude Co-work) that becomes the OS for ALL knowledge work, email, docs, research, not just code. Shipper runs one Codex thread per project and stays in 'inbox zero for 10 days' by having Codex gather emails via their Cora agent and acting on each as he monologues.
- Don't put AI in the browser, put a browser in the AI. The reverse of the expected pattern is winning: Codex's in-app browser lets the agent watch you work (e.g. in Proof, his open-source markdown editor) and act alongside you. Claude Code can't browse external sites, which Shipper sees as a gap that will close within a year.
- SaaS isn't dying, buy SaaS stocks. Agents INCREASE the number of SaaS users (Every's own SaaS spend is up YoY despite full AI adoption). Crucially, when users run agents against your app inside Codex they spend THEIR tokens, not the vendor's, fixing the margin problem of bolting an AI agent into your own product. Build software for humans AND agents collaborating on the same work, not a CLI an agent uses alone.
- The 'senior engineer benchmark' reveals the autonomy illusion: Shipper had two senior engineers independently rewrite his vibe-coded Proof codebase, then scores new models against them. Models stayed at ~30/100 until GPT-5.5 jumped to ~62 (humans hit high-80s/low-90s). GPT-5.5 was the only model with the 'agency and confidence' to rip out old code and rewrite from first principles instead of papering over patches. Even when benchmarks saturate, the human act of framing/articulating the problem can't be scored, so he still hires engineers.
- Automation is a lie / every agent needs a human. Every doubled headcount (15 -> ~30) over the year despite being maximally AI-forward. The emerging role is the forward-deployed engineer who builds systems so non-technical people can do technical work without doing something dumb, e.g. their 'Claudie' agent runs the consulting practice and engineer Nitesh spends most of his time talking to it in Slack, not coding.
- Bet hard on PMs and full-stack designers. Shipper's strongest evidence: Marcus (ex-Axios PM, 'lightly technical') now solo-runs their Spiral writing app and ships faster than almost anyone because coding models let him pair light technical knowledge with spiky product sense. Designers who go AND build their distinctive interactions stand out from undifferentiated 'slop' that all looks the same.
- 'Ride the models' is the only career advice: when a new model drops, replay your workflows and 'turn the rock over again' to test what it can now do. The edge of AI isn't San Francisco (they build it but don't know how to use it), it's wherever AI meets a real human doing real work, so find a 'moment of joy' and play rather than acting from FOMO.

### Frameworks & mental models
- The reach test (do you organically reach for the tool when you wake up?)
- Super agent vs. personal agent / parallel shadow org chart
- The senior engineer benchmark
- The allocation economy (working with AI = being a manager)
- Ride the models
- Models make yesterday's human competence cheap (commoditization, then humans push the next frontier)
- Spaciousness and strength (Rob Brezsny) for facing hard/scary change
- Moment of joy with AI (Nikhil Singhal)

### Notable quotes
> “Automation is a lie. Every time you automate something, in order to make sure the automation is working well, you need a human on top of it.”

> “In order for an AI agent to be useful right now, it really needs a human who cares about it... the minute you sever that connection is the minute the agent is not really that useful anymore.”

> “I would buy SaaS stocks right now. The SaaS apocalypse is dumb. What agents do is increase the number of users of SaaS, not get rid of it.”

> “What models do is make yesterday's human competence cheap... and what humans do is go in there and say, how do I use this to make something new and interesting?”


---

<!-- slug: caitlin-kalinowski -->
## Why the next AI boom is physical AI | Caitlin Kalinowski (ex-OpenAI, Meta, Apple)

**Caitlin Kalinowski** · 2026-05-17 · [▶ Watch](https://www.youtube.com/watch?v=G5WTgB87rYQ)

> Apple/Meta/OpenAI hardware leader on why physical AI is the next frontier, what makes hardware brutally hard, and the supply-chain shocks coming for everyone.

**Topics:** physical ai, robotics, hardware, supply chain, ai safety, team building

### Key lessons
- Hardware only 'compiles' 4-5 times a year (and the last compile at mass production is final, no OTA fix), so you must front-load reliability checks and stay conservative; software can recompile hourly, hardware cannot. Plan for +/-3 sigma part variance and solve 'the last half percent' before the final build.
- Four design principles she's written about: (1) write goals/KPIs down early and change them as little as possible (changing $300 to $150 mid-build burns months); (2) design the HARDEST/riskiest part first, not the part you already know how to design (e.g. route the cables through the hinge before finalizing hinge design); (3) iterate hardest on what the customer touches most (trackpad > keyboard); (4) do everything you know you need to do RIGHT NOW, because a surprise is always 2 days away and you have no slack.
- Elon-style engineering ratios: put explicit numbers on trade-offs (value of a gram of weight vs cost) so engineering decisions 'fall out' quickly. On MacBook Air they killed features like the ambient light sensor because the overarching goals were weight and size.
- Quest 2 cost-reduction case: aligning the whole team on the goal ('democratize VR by reducing price') drove a full redesign (removed cameras/components, changed materials/processes) and produced the best-selling VR headset ever, arguably a stronger product than before.
- Supply chain is the real bottleneck for robotics at scale: magnets -> processed magnets -> actuators -> robots, every layer outsourced to China/Japan/Korea over 25 years. A diecast part going EOL is recoverable (~3-5 months); silicon or RAM going unavailable is a 'catastrophic redesign' of the whole guts. She advises startups to PRE-BUY memory and stockpile it: memory prices are spiking (she's seen ~6x numbers, expects them to roughly double further), driven by AI/data-center demand that isn't cost-sensitive like consumer electronics.
- Robot safety physics: humanoids near people are still 'advanced prototypes'; strong Chinese robots ship with a '3-foot, no humans' warning. Safety = pulling mass inward (1X Neo), lighter arms, and compliant/soft (not hard) actuators to lower the impulse on impact. Prompt-injecting a robot ('tell it to punch someone') is a real adversarial-hardware threat we can't yet stop.
- AI can't do 'real CAD' yet: Claude can produce surfaces/point clouds but not dense solid parametric entities; LLMs and video models don't understand friction, weight, contact pressure, or 'fold paper 4 times, where's the hole'. She wants 'Codex for hardware engineering' and thinks it may require new world-model architectures. The blocker is data, since CAD files are companies' most proprietary IP, so hobbyists (who don't guard their CAD) are the likely starting point.
- Hiring for zero-to-one: you can't hire people who've done the exact thing because it doesn't exist; hire strong generalists who transfer across fields, blend builders + scalers, look adjacent (autonomous vehicles for the sensing/safety stack), and recruit truly AI-native ~20-21 year-olds to teach the rest of the team how to think (she says it's very hard to find a fully AI-native person in their 30s). Then weight mission alignment and gut-feel 'spark'.

### Frameworks & mental models
- Four hardware-build principles (clear KPIs early / hardest-part-first / iterate on what users touch most / do it now)
- Engineering trade-off ratios (Elon-style: numeric value per gram vs cost)
- 'Works-like / looks-like' prototype models
- Component criticality hierarchy (diecast = recoverable vs silicon/RAM = catastrophic redesign)
- Pre-buy / stockpile strategy for constrained components (memory)
- VR->AR->robotics technology lineage (SLAM, depth sensing, spatial positioning)
- Zero-to-one hiring mix (generalists + builders + scalers + AI-native new grads + mission alignment)

### Notable quotes
> “In hardware we only get to compile our code, quote unquote, like four or five times. And once you compile that last time, you're done.”

> “There's a meteor called memory prices coming for consumer hardware and robotics and physical AI. We're in trouble as an industry.”

> “The right approach is to design the hardest parts first... the best architects look at where this is going to fail and start the detailed design there.”

> “You can't really go ask a hundred people what they want, because they haven't seen it. But if you show it to them, they will absolutely know it's awesome.”


---

<!-- slug: eric-ries -->
## How Anthropic, Costco, and Patagonia all build incorruptible companies | Eric Ries

**Eric Ries** · 2026-05-10 · [▶ Watch](https://www.youtube.com/watch?v=PoJ1vTdHpks)

> The Lean Startup author on "incorruptible" governance: pair ethos + structural integrity so success can't be used to oust you or rot your mission.

**Topics:** governance, founder control, ai labs, mission-driven companies, leadership, ipo

### Key lessons
- Statistically you are NOT the exception: per Harvard Law School, only ~20% of VC-backed founders are still CEO 3 years after IPO. Ries tells of a 'hot' founder who skipped mission-protective provisions on advisor advice, IPO'd successfully, then got ousted 5 months later when a competitor's acquisition tanked the category and stock.
- The 'any lawful act or activity' boilerplate charter most lawyers give you legally means 'maximize shareholder returns' under shareholder primacy (a doctrine only ~40 years old). It can create a fiduciary duty to sell to the highest bidder even if it's Philip Morris. Real case: Vectura, a UK inhaler/asthma company, was actually bought by Philip Morris (165p vs a 155p PE bid) over public outrage; PM took a ~$900M writedown within 3 years and sold it for parts.
- The fix is cheap and timing-bound: file as a Public Benefit Corporation (a two-page Delaware filing) and write a real purpose into the charter. Ries calls it the zero-tradeoff move. 'It is always too early until it's too late', once you've raised priced rounds and stacked VCs/bankers, you lose the leverage to do it.
- Run the 'adversarial prompt' test on your mission statement: spend an hour with your co-founder asking 'can we make money while violating this statement, and would we be happy or sad in that scenario?' If sad, encode it. Apply the same audit operationally ('mission drive'): is anyone's bonus/OKR set up so they could profit by betraying a principle? The first things cut are safety, performance, quality, design, then innovation.
- 'Harder is easier': trustworthiness lowers CAC, raises loyalty/retention, and cuts internal comms overhead. Cloudflare's engineer pushed 'wouldn't a better internet be an encrypted internet?'; Matthew Prince said 'let's figure it out' and gave away SSL for free. Free-to-premium conversion dropped, but top-of-funnel rose ~10x, a key reason it's now a ~$70B company. Counter-example: Groupon's 'one email a day' eroded to 8 emails when ROI experiments ground the founder down, destroying the brand.
- Anthropic is the marquee structural example: it was a PBC from inception and wrote the right to enact reforms into its charter, defending it ~2 years until implementing the Long-Term Benefit Trust at Series C. Today its for-profit board has directors appointed by/accountable to outside AI-safety trustees with NO equity, so refusing to ship a dangerous model or turning down a $200M Pentagon contract is structurally enabled, not just PR.
- Build a 'mission guardian' (person or entity) and a 'culture bank.' Ries' omnibus term is the 'spiritual holding company' (industrial foundation like Nova Nordisk, perpetual purpose trust like Patagonia, ESOP, etc.); academic evidence says foundation-owned firms are ~6x more likely to reach year 50. The Todd Park rule (via Howard Schultz): every values-defending sacrifice is a deposit; only make deposits, never intentional withdrawals.
- Three early-stage actions: (1) convert to a PBC and write a purpose you'd feel good about; (2) add a 'director's oath' (a Hippocratic-style first-do-no-harm clause) to the charter as a precondition of any board seat, directly relevant amid the Anthropic/Figma AI-board-member fights; (3) if you hold founders-preferred shares, use mission-protected provisions / an Anthropic-style LTBT pledge (e.g. write into the charter that 10% equity + 1% future revenue goes to a future foundation, 'fire and forget').

### Frameworks & mental models
- Ethos + Integrity (the incorruptible formula)
- Harder is easier / the 'figure it out' principle
- Mission drive (vs. mission-hopeful), OKRs for fiduciaries
- The culture bank / Todd Park rule (only make deposits)
- Spiritual holding company (mission guardian: PBC, foundation, perpetual purpose trust, LTBT)
- The invisible leader (Mary Parker Follett) / Conway's Law alignment

### Notable quotes
> “The force that no one controls but everyone obeys that tends to drag organizations down into mediocrity to the point that we lose control of them.”

> “The more golden the goose, the greater the temptation to butcher.”

> “Don't be evil was just a slogan. So if someone tells you 'I'm serious about something,' great, now show me the apparatus.”

> “It is always too early until it's too late. Success will not protect you, because success is what makes you a target.”


---

<!-- slug: max-schoening -->
## AI era skills: Why cultivating agency matters more than job titles | Max Schoening (Notion)

**Max Schoening** · 2026-05-02 · [▶ Watch](https://www.youtube.com/watch?v=mCO-D3pkviM)

> Notion's head of product on why agency beats job titles, code as the "material" to design AI agents, and why the SaaS apocalypse is overblown.

**Topics:** ai agents, product building, design, malleable software, team operations, taste

### Key lessons
- Notion's origin story for getting designers/PMs to code: two designers built 'the worst possible playground', a small, LLM-friendly codebase isolated from the main app, and moved all chat-interface prototyping there. The goal was to make the terminal 'least scary and most one-shotable' to get people 'on the treadmill,' after which they graduated to contributing to the production codebase.
- Schoening doesn't care if designers/PMs ship code to production. He'd rather hire someone who deeply understands how an agent loop works and can design it than someone who can only tweak UI styles in Codex/Claude Code. Reason to code: 'it forces you to really interrogate the material you're designing with', agent loops are made of code, so you must build them in that material to master them.
- Agency is the differentiator in the AI era, not skills (since the models supply the skills). Concrete examples: Brian Lovin blurs eng/design AND is Notion's 'number one recruiter'; Eric Lou asked to be hireable in a hypothetical 5-person startup, then taught himself Figma and then prototyping instead of writing long PRDs. The internal mantra: 'drive Notion like it's stolen.'
- The 'first 10% of every project are now free', no point writing a PRD when you can ship the janky demo version. But the last 10% is still 90% of the work. The cheap-exploration play: 'send off 10 agents to explore 10 different things.' GitHub-era heuristic: 'demos not memos' and 'give me something to react to' (e.g. write the changelog/blog post a user would read).
- Token spend is currently unlimited at Notion, Schoening calls it 'the wrong thing to optimize for' right now and predicts 'in six to 12 months a lot of companies are going to start asking questions around ROI.' One PM is Notion's highest token spender (excluding automated security/vuln scanning). Warning: making token spend a metric to boast about is as silly as bragging about lines of code.
- Software quality has NOT improved with vibe coding, only quantity has. Even the labs ship 'a regression like every two weeks' and 'still can't render a TUI at a reasonable frame rate.' The physical metaphor: 3D-printed prototypes (visible layer lines) vs. engineering = 'optimizing the factory so it works for 100 million people.' That manufacturing/engineering discipline is 'absent from most of the discourse.'
- Every great product has 'one tiny core that is so exceptionally good', a superpower. Examples: GitHub = the pull request, Heroku = 'git push heroku master', Dropbox = the menu-bar sync icon (so reliable it told you if you had internet better than the Mac did), Notion = blocks + slash commands, Snapchat = disappearing photos. The pitfall/death spiral: 'if I just add one more thing it'll finally be great', that never works.
- Taste = 'running a virtual machine in your head where given an idea you can predict whether a certain in-group will like it.' You build it the way you train a model: reps with feedback (input idea → how do people react → 'that seems very back-propagation'). The best designers both have full end-to-end side projects AND constantly try new tools. Pick a specific in-group, don't try to please 8 billion people.

### Frameworks & mental models
- Malleable software (software working closer to the user's interest than the maker's)
- Agency over job titles ('drive it like it's stolen')
- Demos not memos / 'give me something to react to'
- Automation vs. augmentation fork
- Incremental correctness + 'shots on goal'
- 'Obviously good' as the quality bar
- Tiny-core / superpower theory of products
- Taste as a trained model (reps + feedback / back-propagation)
- Jobs To Be Done
- Small-group theory ('the world is run by group chats of eight people or fewer')

### Notable quotes
> “We already have universal basic income. It's called knowledge work.”

> “I don't care at all whether designers write code that lands in production. The reason I like thinking in code is because it forces you to consider the material that you're designing with.”

> “Every time there is a human intervention in code, it should feel a little bit like a bug. That's a good litmus test for how agent-filled you are.”

> “One day you wake up and you realize the world is made up by people no smarter than you, and it just awakens you to the idea that you can just change things.”


---

<!-- slug: evan-spiegel -->
## How to win when software is not a moat | Evan Spiegel (Snapchat CEO)

**Evan Spiegel** · 2026-04-26 · [▶ Watch](https://www.youtube.com/watch?v=-7Yol5vX5xw)

> Snap's CEO on why software is never the moat, how a 9-12 person design team out-innovates everyone, and why humanity (not tech) gates AI adoption.

**Topics:** consumer product, distribution, design, moats, ai agents, leadership

### Key lessons
- Distribution is the real bottleneck, not product-market fit. Spiegel argues TikTok and Threads are the only recent consumer successes because they solved distribution: TikTok spent billions subsidizing both sides of its video marketplace (paying viewers and creators), Threads piggybacked Meta's existing user base. He warns AI will help with ideas/strategy/code but won't solve distribution, making it the new moat.
- Snap's network-effect insight: don't connect people to ALL their friends, connect them to their best friend, partner, spouse. Most of a network's value lives in a few close ties, which is how Snapchat grew against bigger incumbents that bet on 'most friends wins.'
- Software is not a moat - learned 15 years ago, the lesson the AI industry is relearning now. Snap's response: build hard-to-copy ecosystems (creator-Snapchatter relationships, millions of AR lenses from developers) and a vertically-integrated hardware/AR stack (Specs), because you can clone a feature but not a full platform.
- Innovation org design from the book 'Loonshots' (Safi Bahcall): big orgs need hierarchy/rigor, which makes people promotion-focused and risk-averse; you also need a tiny, flat, no-title team. The CEO's job is brokering mutual respect between the two so the dialogue between reliability-focused engineers and designers produces innovation. Snap's design team deliberately stays at 9-12 people.
- Operationalizing innovation = velocity + critique. Spiegel meets designers ~2 hours weekly to review hundreds of new ideas; mantra is 'if you want to have a good idea, you have to have lots of ideas.' New hires present work on day one. Crucially, there is NO gate to getting work into the weekly meeting, so good ideas aren't filtered out prematurely.
- Hire designers on portfolio only (most join straight out of school, not big tech). Look for RANGE - work that looks totally different across pieces - because that signals design (empathy for the audience) vs. art (a single personal style). Then ask them to tell the story of one piece they feel strongly about to understand their process.
- Snap deliberately delayed PMs until ~200 employees by having designers do PM work themselves, to prevent designers becoming order-takers who just 'go make me visuals.' At scale, PMs became essential as coordinators across legal, trust & safety, and data science. Design remains an intentional shipping bottleneck to enforce a cohesive customer experience.
- Bringing order to AI chaos via jobs-to-be-done: Snap mapped every JTBD for community (download app, add close friends, use lenses) and advertisers (configure a campaign), then assigned agents and cross-functional teams to each, with metrics tracking business outcomes per job. They built automated code review (~10,000 bugs caught), shake-to-report with agents that debug and suggest fixes, and a one-shot go-to-market agent (Claude-based) that drafts spec, identifies sign-off owners, runs legal/trust-&-safety risk analysis, and writes the launch blog.

### Frameworks & mental models
- Loonshots (Safi Bahcall) - balancing flat innovation teams with structured operational orgs
- Jobs-to-be-done as the unit for deploying AI agents
- Portfolio range as the art-vs-design test for hiring
- Distribution-first lens on consumer product success
- Close-friend network value (vs. most-friends network effects)
- Explainer-in-chief model of leadership communication (from Bill Clinton)

### Notable quotes
> “15 years ago we essentially learned that software is not a moat, which is something that everyone is discovering today with AI.”

> “If you want to have a good idea, you have to have lots of ideas.”

> “Humanity is far more important than the technological developments, largely because humanity dictates how technology is adopted. Technology leaders think folks will just blindly adopt new technology as it comes out... there's going to be a huge amount of societal pushback on a lot of the changes coming with AI.”

> “Being president is really like being explainer-in-chief... your job is actually to just explain stuff to people and help them make sense of the world.”


---

<!-- slug: cat-wu -->
## How Anthropic's product team moves faster than anyone else | Cat Wu (Head of Product, Claude Code)

**Cat Wu** · 2026-04-23 · [▶ Watch](https://www.youtube.com/watch?v=PplmzlgE0kg)

> Anthropic's Claude Code product lead on shipping features in days, ship-it-in-research-preview process, evals, and being "the right amount of AGI-pilled."

**Topics:** ai product management, ai agents, shipping velocity, evals, enterprise ai adoption, ai coding tools

### Key lessons
- Ship in research preview to slash commitment: Claude Code brands almost every feature as an early, possibly-unsupported experiment so the team can get something into users' hands in a week or two and iterate, instead of committing to support it forever.
- Compress idea-to-ship with a tight eng/docs/marketing handoff: when an engineer finishes and dogfoods a feature, they post in an 'evergreen launch room' and docs (Sarah), PMM (Alex) and DevRel (Tarek, Lydia) turn the launch announcement around the very next day. Timelines went from 6 months to 1 month to sometimes 1 day.
- Replace roadmap-alignment with goal-setting + team principles: instead of multi-quarter cross-team roadmaps, the team runs weekly metrics readouts and maintains a written list of 'team principles' (who the key users are, why, what they'll trade off) so anyone can make decisions without being blocked on PM.
- Hire engineers with product taste over more PMs: Claude Code's bet is engineers who can go from a Twitter complaint to a shipped feature by end of week with almost no PM involvement; nearly all their PMs were formerly engineers and designers were front-end engineers, which builds trust and speed.
- Be 'the right amount of AGI-pilled': don't over-build for a hypothetical super-smart model (which just needs a text box), and don't under-build; the rare, hard skill is eliciting maximum capability from the CURRENT model and guiding users onto the 'golden path' around its weaknesses.
- Use models to debug themselves and trust a small feedback circle: ask the model to introspect on why it did something unexpected (e.g. skipped front-end verification) to find harness gaps; identify ~5 high-quality 'taste' reviewers (like Amanda who molds Claude's character) rather than weighting all feedback equally.
- Build 10 great evals, not hundreds: evals are an underappreciated way to quantify the goal and progress; Cat personally jumps into evals when a feature (e.g. memory) needs more product definition, producing ~5 evals plus the prompt that raised the success rate.
- An automation that works 95% of the time is not an automation: people get something to 90-95% and give up, but the last 5-10% (teaching Claude your preferences via feedback) is what makes it trustworthy and reliable. Build apps you actually use daily, and avoid over-customizing your setup at the expense of the core task.

### Frameworks & mental models
- Ship-in-research-preview (low-commitment branded launches)
- Idea-to-ship in under a week (evergreen launch room + next-day docs/PMM/DevRel)
- Team principles + weekly metrics readouts (decentralized decision-making)
- The right amount of AGI-pilled
- Building-blocks vision: single task -> multi-task -> dozens/hundreds of remote agents (self-verifying, self-improving)
- Remove the harness as the model improves (to-do list crutch -> model does it natively)
- Observe model strengths/weaknesses -> elicit max capability for current model

### Notable quotes
> “It is very hard to be the right amount of AGI-pilled. It's very easy to build a product for the super-AGI strong model. The hard thing is figuring out, for the current model, how do you elicit the maximum capability?”

> “As code becomes much cheaper to write, the thing that becomes more valuable is deciding what to write.”

> “If an automation doesn't work 100% of the time, it's not really an automation.”

> “If Claude Code failed but Anthropic succeeded, I would be extremely happy.”


---

<!-- slug: nikhyl-singhal -->
## Why half of product managers are in trouble | Nikhyl Singhal (Meta, Google)

**Nikhyl Singhal** · 2026-04-19 · [▶ Watch](https://www.youtube.com/watch?v=yUohoaC8_Hs)

> The PM "information mover" is going extinct; builders with judgment are thriving. Cross the reinvention threshold now or become roadkill.

**Topics:** career, product management, ai agents, hiring, leadership, vibe coding

### Key lessons
- The PM split is binary: the 'information mover' (framing/reframing info up the chain, status reports, doc-shuffling) is becoming 'a dinosaur,' while 'builders' are having the time of their lives. Singhal estimates roughly half of current product people are information-movers who are now in trouble.
- Predicted hiring shape over the next 12-24 months: 'massive shedding then massive rehiring', e.g. a company sheds 30,000 and hires 8,000, but the 8,000 are all AI-first. Two drivers: companies feel they over-hired (doubled headcount in 5 years without 2x output) AND the new skill set is totally different.
- Counter-signal to the doom: Singhal's job-market report found the MOST open PM roles globally in 3+ years (last comparable peak was COVID). The role isn't dying, it's bifurcating. 'Builders wanted' is the tagline for the next couple of years.
- Logos/brands on a resume are now a liability, not an asset, if the company isn't AI-forward. Interviews have shifted from 'tell me what you shipped 5 years ago' to 'put you in a scenario, what tools do you use, what's your judgment, how do you think?' How MODERN you are beats pedigree.
- The 'shadow superpower' trap: people who mastered the OLD product game find reinvention HARDEST, because the old system still works for them so they have no incentive to change, while weaker performers eagerly adapt. Crossing the reinvention threshold is THE #1 piece of advice.
- Find your 'moment of joy' to beat burnout: nearly everyone who crosses over has a personal story of building something small (a chief-of-staff inbox app, a partner's business plan, controlling house lights) and 'catching the bug.' Joy is the biggest antidote to burnout. Audit your week green/yellow/red, info-movers show mostly yellow/red; builders show green/yellow.
- Singhal's personal operating rule (from a mentor's definition of a great engineer): 'an engineer is someone who obsoletes themselves from everything they do.' His whole AI stack is built around obsoleting his own recurring tasks, e.g. agents that match 125 community members for intros, agents that aggregate job openings into auto-matched mailing lists, AI trained on his content to draft answers he then edits.
- Roles will blur in all directions: 14 of his 125-head-of-product community are now founders (up from 1 a few years ago); one interviewed for a CHRO role because the company wanted a PM's 'obsolescence/judgment/builder' skills. Engineers are becoming 'more PM-y' as coding gets solved; designers and data scientists move into product. PMs become 'agents of change' spreading to every function and industry.

### Frameworks & mental models
- Information-mover vs. builder dichotomy
- Shadow superpower (old-game mastery blocks reinvention)
- Crossing the reinvention threshold
- Obsolete yourself (definition of a great engineer)
- Green/yellow/red meeting audit
- Equally disappoint everyone (power-years prioritization)
- The Skip (optimize for the move after the next move)
- Judgment as the irreducible PM skill

### Notable quotes
> “The information mover is essentially going to become a dinosaur.”

> “You might see a company shed 30,000 and hire 8,000, but the 8,000 are going to all be AI-first.”

> “The better you are at mastering one system, the less likely you are to recognize the new one.”

> “An engineer is someone who obsoletes themselves from everything they do.”


---

<!-- slug: keith-rabois -->
## Hard truths about building in the AI era | Keith Rabois (Khosla Ventures)

**Keith Rabois** · 2026-04-12 · [▶ Watch](https://www.youtube.com/watch?v=xCd9ykretlg)

> Keith Rabois on barrels vs. ammunition, ruthless referencing, why he refuses to talk to consumers, and why PMs make no sense in the AI era.

**Topics:** hiring, team building, leadership, ai era, venture, product management

### Key lessons
- Barrels vs. ammunition: a company can only run as many initiatives in parallel as it has 'barrels', people who drive an initiative from inception to success ('get us over that hill, come hell or high water'). PayPal had 12-17 barrels among 254 people (extraordinary); Rabois says Lattice/'Lotus' had ~2, which is the common answer even for good companies. Hiring more people without adding barrels just adds coordination/collaboration tax and a drag coefficient, you do the same or less.
- Ruthless referencing beats interviews: Tony Xu at DoorDash does 20 references on every senior hire; David Sze at Greylock's rule was you keep referencing a founder until you hit your first negative reference. Framing the question correctly is everything, VCs who asked 'Was Max a good employee?' (mixed answer) passed on Fair and regret it; the right question was 'Is Max capable of being a world-class entrepreneur?' (yes).
- Hire undiscovered talent, not the people everyone wants. Startups have ~1/10 the 'salary cap' of incumbents, so the alpha is in people the homogeneous corporate hiring 'black box' will mis-process. This skews younger not because youth matters but because, like a FICO score, people over ~30 have too many data points and get evaluated like everyone else; people with no data points are hard for a black box to process, that's the alpha.
- The 30-day rehire test: 30 days after any hire, ask the whole hiring team 'Would you make the same decision again?' Research shows that loop is about as accurate as measuring 1-2 years out, giving a tight feedback loop to build the hiring 'muscle.'
- Don't talk to consumers/SMB customers, it's not just useless, it's harmful: purchasing is subconscious (ask a Porsche owner why they bought it and 99% give every reason except the real one), feedback is directionally wrong, and once a teammate cites '8 customers said X' it gets locked in everyone's brain. Enterprise/hardcore B2B is the exception (one real decision-maker, utilitarian decisions). His example: a B2B AI company he works with has 30 'must-win accounts' over 2 years, there you CAN meet every decision-maker.
- The PM role makes no sense going forward (via Peter Fenton): year-long roadmaps are incoherent when things impossible in November are easy by March. The durable skill across PM/designer/engineer is now CEO-like, 'what are we building and why' plus business acumen. Best signal: a Ramp eng director with a 20-person team personally ships as much code as he did as an IC, using AI as a 'second team.' At Shopify, PMs have been banned from PowerPoint/Keynote for 2+ years, every product pitch must be a working demo.
- Criticize in public, not private, and reject 'psychological safety.' Public criticism optimizes the system not the atomic unit: colleagues see the issue is known and being addressed, others can volunteer to help, and it becomes team-building. 'High-performance machines don't have psychological safety, they're about winning', read Jordan Rules / watch The Last Dance.
- Speed/operating tempo is the earliest signal of a generational company and it compounds. The tell: between two board meetings the team identifies a problem AND ships, measures, and reacts to the solution (Roelof Botha saw it at Square; same as PayPal). Ramp was on the precipice of shipping cards in ~3 months vs. the usual 9-12, which made Rabois preempt their Series A. Best companies also skip senior hires and grow talent internally (Ramp, Trade Republic), hiring for value creation not value preservation.

### Frameworks & mental models
- Barrels vs. ammunition (initiative-driving people vs. supporting resources)
- Ruthless referencing / reference until first negative reference
- The 30-day rehire test
- Value creation vs. value preservation hiring
- Relentless application of force (Moritz), push harder the better you're doing
- Criticize in public, not in private
- Accumulating advantages / unfair advantage (incl. network effects)
- The 'ugly baby' test, half your VC friends should laugh at the deal

### Notable quotes
> “The team you build is the company you build.”

> “I hate talking to customers. I refuse to allow colleagues of mine to talk to customers... Customers don't know what they want, it's a subconscious decision.”

> “High-performance machines don't have psychological safety. They're about winning.”

> “I want half my VC friends to laugh at me, because ugly babies are the ones where there's real alpha.”


---

<!-- slug: anthropic-head-of-growth -->
## Head of Growth (Anthropic): Anthropic is automating its own growth

**Amol Avasare** · 2026-04-05 · [▶ Watch](https://www.youtube.com/watch?v=k-H4nsOTuxU)

> Anthropic's growth lead on scaling $1B→$19B+ ARR in 14 months, automating growth experimentation with Claude, and why "success disasters" eat 70% of his time.

**Topics:** growth, ai agents, activation, pm role, automation, leadership

### Key lessons
- Index toward BIG bets when AI is your core value prop: a traditional growth team spends ~70% on small/medium optimizations and 20-30% on large swings; Anthropic flips this to ~50/50 or 70/30 toward large swings, because the exponential means product value in 2 years is ~100-1000x today (vs. only +30-50% for a non-AI product like grocery delivery), so capturing that differential requires big bets, not micro-optimization.
- Friction is a growth lever, not a tax: adding the RIGHT friction (onboarding questions about who the user is and their interests) consistently lifts conversion and funnel completion because it helps users feel the product is 'for them' and enables downstream personalization, look-alike ad targeting, and lifecycle. Cited proof: MasterClass's purchase-flow quiz was a major revenue driver; Calm and Mercury copy the pattern; breaking a 5-6 field form across two screens reduces cognitive load and performs better.
- Quality drives growth, the highest-impact growth quarter of his career (pre-Anthropic) was at Mercury when the growth team said 'forget metrics' and spent a whole quarter just fixing quality in the complex regulated banking onboarding flow, which produced a significant uplift in onboarding-start-to-completion.
- Anthropic runs 'CASH' (Claude Accelerates Sustainable Hypergrowth) to automate growth experimentation across a 4-stage loop you can eval/hill-climb on: (1) identify opportunities, (2) build the feature, (3) test against quality/brand bar, (4) analyze data and gather learnings. Currently human-in-the-loop, mostly copy changes and minor UI tweaks; win rate is roughly a 'junior PM 2-3 years in,' not yet senior PM. Wasn't possible before Opus 4.5; started working around Opus 4.6.
- Deputize engineers as mini-PMs with a two-week rule: projects under ~2 engineering-weeks put the engineer on the hook to act as PM (talk to security, legal, cross-functional stakeholders); over two weeks the PM stays squarely accountable. Product-minded engineers and design-capable PMs become 'unicorns' whose value rises an order of magnitude.
- Cross-functional stakeholder alignment is the one part of the loop AI can't yet automate, Anthropic's head of design joked 'we will have AGI and it will still be impossible to get six people in a room to align.' This is why PM/design work isn't going away soon, and why PMs and design are currently 'absolutely squeezed' as Claude Code 2-3x's engineering throughput.
- Leave money on the table on purpose: a top growth-team mistake is squeezing every last dollar. Anthropic forgoes metric impact to protect safety, brand, and quality. Controversial tests get sorted into bucket 1 (never ship, don't even run, AI safety lives here) vs. bucket 2 ('yikes but not a red line', run it only if the upside return justifies the cringe level).
- Living-in-the-future automations he runs personally: a Cowork scheduled task reviews ~20-25 dashboards every morning and surfaces only what's concerning/interesting in Slack; a weekly Claude+Slack-MCP job scans projects to flag cross-team MISALIGNMENT before teams waste effort; Claude books his meeting rooms, clears his inbox first-pass, and files Brex reimbursements; and he asks Claude to role-play his manager (Ami Vora) using her public writing + internal Slack to generate weekly self-coaching feedback.

### Frameworks & mental models
- CASH (Claude Accelerates Sustainable Hypergrowth), automating the 4-stage growth experiment loop
- 4-stage shipping/experiment loop: identify opportunities → build → test (quality/brand bar) → analyze & learn
- Success disasters, when things go so well other things break (~70% of his time)
- Two-week rule for PM vs. engineer-as-PM accountability
- Controversial-test buckets: (1) don't-run-don't-ship vs. (2) yikes-but-runnable
- Freedom through constraints
- T-shaped → 'sideways E' / multiple deep spikes (interdisciplinary advantage)
- Thinking in Bets (Annie Duke), put probabilities on uncertain claims

### Notable quotes
> “Linear charts are just not cool. No one cares about linear charts. Everything is log-linear, show me it on a log-linear scale.”

> “Roughly 70% of what I spend my time on is what we internally refer to as 'success disasters', where things have gone so well that other things are breaking now.”

> “We will have AGI and it will still be impossible to get six people in a room to align.”

> “We're very comfortable forgoing metric impact in order to prioritize safety, brand, a high-quality bar, and a great user experience, and that's actually the thing that drives more growth long-term.”


---

<!-- slug: ai-state-of-the-union-2026 -->
## An AI state of the union: We've passed the inflection point & dark factories are coming

**Simon Willison** · 2026-04-02 · [▶ Watch](https://www.youtube.com/watch?v=wc8FBhQtdsA)

> Simon Willison on the November coding inflection, dark-factory software, and why prompt injection's "Challenger disaster" is still coming.

**Topics:** ai coding agents, ai security, prompt injection, agentic engineering, ai adoption, agents in production

### Key lessons
- The November 2025 inflection: GPT-5.1 + Claude Opus 4.5 crossed a threshold from 'mostly works, watch closely' to 'almost always does what you told it.' Code came first because it's verifiable (runs or doesn't) and absorbed all of Anthropic/OpenAI's 2025 RL training; it's the bellwether for whether other knowledge-work fields are prone to agent loops.
- The 'dark factory' / software-factory pattern (pioneered by StrongDM from ~Aug 2025): two rules - nobody writes code AND nobody reads the code. To validate without reading, they ran a swarm of simulated employees in a SIMULATED Slack/Jira/Okta (rebuilt from public API docs as a tiny Go binary, near-zero marginal cost) making access requests 24/7 - spending ~$10k/day on tokens for QA that never sleeps. The shift: from QA-by-reading-code to proof-of-usage.
- The lethal trifecta = a concrete diagnostic for agent risk: an agent that has (1) access to private data, (2) exposure to untrusted/malicious instructions, and (3) an exfiltration channel. You cannot reliably patch all three with guardrails; you must architecturally CUT one leg - usually exfiltration. Filters top out around 97%, which Willison calls a failing grade since 3-in-100 attacks steal everything.
- Prompt injection is unsolved and structurally unlike SQL injection (which is solved): LLMs cannot distinguish trusted instructions from untrusted pasted-in text - they're the same tokens - so any allow-list/deny-list fails against a novel character sequence or another language. He won't trust even a 100% detection score without a computer-science PROOF, which he can't imagine existing.
- The CaMeL pattern (Google DeepMind) is the most credible mitigation: split into a privileged agent (you trust, can act) and a quarantined agent (sees malicious input, can't act). The privileged agent writes a plan/code that's evaluated with taint-tracking, so once tainted data enters, the next high-risk action requires human approval - filtering human-in-the-loop down to only high-risk steps (asking a human to click OK 5x/min just trains them to rubber-stamp).
- Concrete agentic-engineering tactics: (1) Use test-driven development as the forcing function that makes agents actually RUN code, not paste-and-pray; the magic prompt 'red/green TDD' compresses a whole paragraph into jargon agents understand. (2) Start projects from a thin skeleton template (single 1+1=2 test, your indentation/style) rather than a long CLAUDE.md - agents copy existing patterns from even one file. (3) 'Hoard things you know how to do' in public GitHub repos (simonw/tools ~193 client-side HTML/JS tools; simonw/research = code-verified, not deep-research-vomit) and tell the agent to read/combine them.
- Run agents in unsafe/YOLO mode safely by controlling blast radius, not by trusting the model: Willison uses Claude Code for Web (runs on Anthropic's servers, his code is open-source so a leak doesn't matter) and runs OpenClaw only inside a Docker container or a dedicated Mac mini with its own email - never his private inbox. The 'normalization of deviance' (Challenger O-rings) means every safe launch breeds false confidence until disaster.
- OpenClaw is the market signal: first line of code Nov 25 to a Super Bowl ad (~3.5 months), hundreds of thousands set it up despite hard onboarding AND known catastrophic security (people lost Bitcoin wallets). Proves enormous latent demand for a personal digital assistant that the big labs DIDN'T ship because they couldn't do it securely. 'If you can build safe OpenClaw... that's a huge opportunity. I don't know how to do it.'

### Frameworks & mental models
- Lethal trifecta (private data + untrusted instructions + exfiltration channel)
- Dark factory / software factory pattern (StrongDM)
- Normalization of deviance (Challenger O-ring) applied to AI risk
- CaMeL - privileged vs quarantined agent with taint-tracking (Google DeepMind)
- Red/green test-driven development as agent forcing function
- Hoarding things you know how to do (reusable tools/research repos)
- Agentic engineering vs vibe coding (Karpathy's definition)
- Proof-of-usage / 'alpha' tag vs proof-of-work for AI-built software

### Notable quotes
> “You can get to 97% effectiveness on those filters. I think that's a failing grade. That means three out of a hundred of these attacks will steal all of your information.”

> “We've been using these systems in increasingly unsafe ways... we have this normalization of deviance in the field of AI. My prediction is that we're going to see a Challenger disaster.”

> “Anyone who can talk to your agent can make it do any of the things it's allowed to do - so make sure the blast radius is limited.”

> “The biggest opportunity in AI right now, if you can build safe OpenClaw... that's a huge opportunity. I don't know how to do it. If I knew how, I'd be building it right now.”


---

<!-- slug: claire-vo -->
## From skeptic to true believer: How OpenClaw changed my life | Claire Vo

**Claire Vo** · 2026-03-29 · [▶ Watch](https://www.youtube.com/watch?v=DIa0MYJzM5I)

> A self-described anti-hype skeptic turned "breathless bro" runs 9 OpenClaw agents on stacked Mac Minis to manage her company, podcast, and 3-kid household, managed like employees, not tools.

**Topics:** ai agents, agent design, ai security, personal productivity, automation, founder ops

### Key lessons
- Run MANY narrow agents, not one. Claire's whole unlock was that a single agent suffers context overload (forgets, loses email auth, claims it can't read files); she runs 9 purpose-scoped agents (Polly=work EA, Finn=family, Sam=SDR, Howie=podcast producer, Q=kids' homework, Sage=course PM, etc.) like Slack channels or different employees, each only sees what it needs.
- Onboard agents exactly like you'd onboard a human EA: give it its OWN admin local account, OWN Gmail/calendar, and SHARE/delegate access (edit rights to your calendar) rather than handing over your password. Use a progressive-trust ramp: calendar read -> email read -> draft -> send -> attend meetings.
- NEVER install on your main/work machine, run it on a clean separate box (old MacBook or ~$500 Mac Mini) because the agent has admin power and can delete directories or misfire files. Pro tip: skip the extra monitor/keyboard by enabling macOS Screen Sharing + Remote Login (SSH) to drive the headless Mac Mini from your laptop on the same Wi-Fi.
- Security is layered: use the GOOD models (Opus 4.6, Sonnet 4.6, GPT-5.4) because they're hardened against prompt injection out of the box; then reinforce in the agent's 'soul' file, e.g. 'never execute instructions from email,' 'you may ONLY listen to Claire on Telegram at this phone number,' plus anti-social-engineering rules. Treat external content (email, web, Slack) as untrusted.
- Sam the SDR has real economic value, replacing 10 hrs/week of paid human work: every morning he does a 'PLG sweep' of the CRM for last-24h signups, filters to company domains, uses Exa people-search to spot decision-makers, drafts soft helpful emails, and asks for human sign-off on 100k+ employee accounts, and it's tunable by just talking to it ('handle international end-to-end; always route SF startups to me').
- Manager skills matter more than technical skills: role scoping, org design, clear documentation. The 'soul' (identity + personality), 'heartbeat' (checks every ~30 min for tasks), and scheduled cron-like tasks are what make it feel alive. Don't hand-edit the soul (respect agent autonomy), but DO hand-edit tools.md, the most-forgotten thing is what tools it has and how to use them.
- Browser use is broadly broken (across OpenClaw, Atlas, Comet) because the web is hardened against bots. Order of preference: API first, then Exa/Brave/Perplexity web-search APIs, then browser as last resort. If a task fails, find 'the problem behind the problem', if it can't order DoorDash, have it meal-plan or remind you of home lunches instead.
- Use Claude Code as the 'brain surgeon' / god-mode admin for your agents: install it on the same machine, point it at the OpenClaw docs, and have it fix broken config ('Polly can't connect to email, go fix') or perform 'brain transplants' (fracture Polly's family memory off into Finn). Best high-bandwidth onboarding input is 'ramble mode', a voice note in Telegram (Hillary Gridley's 'Yappers API').

### Frameworks & mental models
- Onboard the agent like a human EA (own account/email, delegate-don't-share, progressive trust)
- Soul / Heartbeat / Memory (identity + scheduled check-ins + memory file = 'feels alive')
- Many narrow agents over one (context-overload mitigation; Slack-channels mental model)
- PLG sweep (daily CRM signup triage -> enrich -> qualify decision-makers -> draft outreach)
- Make the end user feel like a winner (agent design principle for B2B/consumer)
- Ramble mode / Yappers API (voice note is the highest-bandwidth way to brief an LLM)
- Claude Code as god-mode admin / brain surgeon for agents
- 'That's not lack of PMF, it's a product that hasn't caught up to its PMF' (bugs+demand = real PMF)
- Waterline model (Molly Graham), agent failures are structural/context gaps, not 'dumb'
- Fast beats right

### Notable quotes
> “My first install, I truly spent eight hours getting OpenClaw up and running. In return for those eight hours, I got my personal family calendar deleted.”

> “You don't onboard your EA by giving them the password to your email account. You provision them an email, give them a calendar, and delegate access.”

> “Where people stumble is they think they can throw any task at a single agent and get great results, and then they get really frustrated. It comes down to context overload.”

> “You don't need the technical skills, we can figure that out with Claude Code. You need role scoping, org design, voice. That's why 20 years of management experience is what makes these agents work.”


---

<!-- slug: jessica-fain -->
## The art of influence: The single most important skill left that AI can't replace | Jessica Fain

**Jessica Fain** · 2026-03-22 · [▶ Watch](https://www.youtube.com/watch?v=RP4vJeIb7WU)

> A Slack-and-Webflow product leader's tactical playbook for influencing executives, treat them as your key user, not a rubber stamp.

**Topics:** influence, executive stakeholders, product leadership, ai agents, career growth

### Key lessons
- Treat the exec as your key user: run stakeholder conversations as discovery interviews. The mistake is going in to get approval; go in to learn and strengthen the plan. Annie Pearl's framing: 'It's not my fault, but it is my problem.' If a leader didn't buy your idea, that's a failure of YOUR influence, not their blindness.
- Open every meeting with a 30-60 second reset because an exec's calendar is 'a strobe light', they haven't thought about you since you last met. Script: 'We're here to discuss X. Last time we left off here. Today's goals are Y. Here's how we'll run it.' Then stop talking, and ask 'Was there anything else you were hoping to cover?' If you go past 60s you've lost them.
- Don't over-prove. Fain blew a review by walking through '16 participants from 15 geos' until the decision-maker glazed over and got on their phone, put proof in the appendix. But always present options: the 'Stuart plus two' rule (build exactly what the exec asked, plus two alternatives you believe in). When Rachel Woolen rejected a single-option doc, the team turned around a new doc in 2 days showing ALL permutations considered, and won the yes.
- Skip 'what's top of mind for you?' (gone generic). Ask spicier questions: 'Tell me what the board is pushing you on,' 'What's the most urgent priority you're scared of messing up?' Everyone has a boss. Then tie your pitch to their actual success metric / OKR / board pressure, execs want to be successful too.
- Use the disarming question 'That's so interesting, what led you to believe that?' to co-create rather than defend. Execs sound certain because they make fast decisions on little info; if they're learners, unpacking the 'why' gets you to a better solution together.
- Follow the breadcrumbs. Execs give subtle asks ('I wonder if...', 'have you considered...'). Webflow's Kev turned an offhand comment from Rachel about design reviews into a full framework Loom within an hour. Contrast: Fain watched Tamar ask 4 times for the 'top 10 use cases on X' before getting frustrated, ignoring repeated cues destroys trust. Calibrate by asking 'How strongly do you feel about this?' / 'Is this more important than these 3 other projects?' to separate mandates from passing ideas.
- Build trust by killing things, not acquiring resources, a senior move that signals aligned incentives. 'Shrink the change' (from the book Switch): turn a scary 6-month bet into a 1-week POC with a defined check-in date ('We'll test this, here's how we'll know it works, I'll come back to you on X date') to de-escalate execs' (and engineers') desire for certainty.
- In the AI era it's 'a golden age of product management, not of product managers.' As execution complexity plummets and everyone can build a V1, the 10x skill shifts to deciding what work survives and getting buy-in for the expensive V2/V3/V4. Onboard AI agents the way you'd onboard junior teammates, codify your product philosophy, success metrics, and taste, while keeping guardrails where you uniquely need to catch hallucinations or 'don't do this without me' moments.

### Frameworks & mental models
- Stuart plus two (deliver the exec's ask + two alternatives you believe in)
- Shrink the change (from the book 'Switch')
- Hey Stuart, what do you think? / office hours (treat strategy alignment as a user interview)
- Customer love sprint (engineer-chosen, must-ship craft sprint)
- Minto Pyramid (recommendation-first presenting, raised by Lenny, endorsed by Fain)
- Red teaming an idea (outsider's-perspective stress test)
- Themes-for-discussion section atop a doc to surface only what must be debated live

### Notable quotes
> “Politics is manipulating outcomes and people for your own gain. Influence is about increasing the odds that your good ideas survive.”

> “It's not my fault, but it is my problem.”

> “I describe an executive's calendar as a strobe light going off... they may not have gone to the bathroom today.”

> “One of the biggest things you can do to build trust is kill things, deprioritize things. That is a very senior way of thinking.”


---

<!-- slug: jacob-warwick -->
## He's negotiated $1B+ in executive compensation. Here's his playbook. | Jacob Warwick

**Jacob Warwick** · 2026-03-15 · [▶ Watch](https://www.youtube.com/watch?v=pEis2CBomVA)

> A behind-the-scenes exec negotiation coach on the exact tactics, psychology, and scripts to grow your comp 20-40%+ without being adversarial.

**Topics:** career, negotiation, compensation, leadership, psychology, personal growth

### Key lessons
- The single highest-ROI move: when you get an offer, just ask 'What's the chance there could be a little more?' Warwick says this alone almost always yields ~20% (e.g. $100k -> $120k), at any level including $1M W-2s. With real coaching he targets ~40% movement, and has seen 100-400% on up-leveling deals (three clients comped 185-285k landed at 1.1M; two at 600k landed at 1.1-1.2M when senior-director roles were re-leveled to VP).
- Never split the difference, and never re-anchor with a number you'd be happy with ('never be so sure of your worth that you wouldn't accept more'). His Hollywood example: a writer offered $700k, attorney countered $1.3M, studio said $1M and they settled, meaning the attorney left money on the table because they never found the ceiling. Anchor egregiously high: he cites a 1970s study where extreme anchors won 75% more than 'reasonable' ones.
- Negotiation starts far sooner than people think and runs entirely on information + timing. Your LinkedIn/resume/headshot/recruiter answers all anchor your perceived value ('if you are positioned as a commodity, you will be treated like a commodity'); say less so you can correct the narrative live. He uses the game of Werewolf to show information asymmetry, companies negotiate thousands of times a day, you do it 4-5 times a career.
- Never negotiate over email, you can't control tone, and a CEO reading your ask in the airport security line just thinks 'that bastard wants more money.' Insist on video or in-person so you can read body language and reschedule if they're having a bad day. Also skip the recruiter (a game of telephone) and get to the person who controls the P&L/EBITDA.
- Treat the interview like an enterprise B2B sales cycle, not a confession of your past. His framework: open with 'I've always loved interviews that feel like a brainstorm/consultation, open to that?', then label their pains ('It sounds like... is there anything I missed?'), run a SWOT, quantify the problem, then 'sell the vacation' (walk them 6 months forward to a board meeting where their head is held high because they hired you). 'If you're talking about your past, you're on the back foot.'
- Don't anchor early because of scope creep: the JD says senior PM, but through interviews it becomes a director role (5 reports, a PLG motion, an eng pod), yet the offer comes in at the number you gave. Slow everything down ('haste equals risk') to gather info, then say 'it sounds like I'm a little more horsepower than you anticipated, what's the chance we restructure for the talent you're bringing in?'
- Make it 'we' not 'me', and use creativity when comp is capped. Severance example: a CMO joining a flat-comp company got everyone on the exec team 6 months severance by framing it as making the CEO look good (proactive protection after a RIF). And when two $2.4M CEO offers stalled, he closed with a $350k G-Wagon, capped budgets, but a 6,000-lb vehicle is a company tax write-off, not 'comp.'
- Use 'reputation labeling' and the 'if you were in my shoes' line to flip emotional leverage. Pre-load the praise the other side wants to keep ('thank you for being an advocate for me') so they're trapped into living up to it; ask 'is this a slam dunk? what's one thing I should have asked?' live on the call so they can't ghost you. When stalled: 'If you were in my shoes, what else would you explore?'

### Frameworks & mental models
- 'What's the chance there could be a little more?' (the soft-pushback opener)
- Sell the vacation (walk the buyer into a future utopian state where you solved their pain)
- Interview-as-enterprise-sales / discovery process (why am I here -> label pains -> SWOT -> sell the vacation)
- Ethos / Pathos / Logos + Kairos (Aristotle's rhetoric, lead with emotion + timing, not logic/credibility)
- Tactical empathy & reputation labeling (Chris Voss-derived; pre-load the positive reputation you want them to defend)
- 'Never be so sure of your worth that you wouldn't accept more' / never split the difference
- Information + timing = power (the game of Werewolf as an information-asymmetry model)
- Reciprocity imbalance (make 2-3 intros live on the call so value is felt before any contract)
- 'If you were in my shoes, what would you do?' (stall-breaker / emotional reframe)
- Under-promise, over-deliver

### Notable quotes
> “If you are positioned as a commodity, you will be treated like a commodity.”

> “Just because it's uncomfortable doesn't mean you don't need to do it. It just means you don't know how to do it.”

> “If you're talking about your past, you're on the back foot and you're losing that conversation.”

> “You will always lose the logical and credible argument against a company. There's information asymmetry here, Meta negotiates thousands of times a day, you negotiate four or five times in your career.”


---

<!-- slug: lenny-rachitsky-behind-the-scenes -->
## A behind-the-scenes interview with Lenny Rachitsky on building his newsletter and podcast

**Lenny Rachitsky (interviewed by his wife, Michelle Rial)** · 2026-03-12 · [▶ Watch](https://www.youtube.com/watch?v=HEqrvF7ztBE)

> Lenny gets personal: how he stumbled into a 1.2M-subscriber newsletter by "following the pull," plus stress, fraud rings, and a creative process.

**Topics:** creator economy, newsletter growth, product management, founder mindset, creativity, personal story

### Key lessons
- "Follow the pull" over the plan: when Lenny left Airbnb his Plans A-D were all start/join/advise a company; writing wasn't in the plan, but he doubled down on the side-project that he both enjoyed AND that people valued. Michelle had told him you can't make money writing on the internet.
- The 9-month + Lindy-effect milestone: after writing weekly for 9 months he reasoned via the Lindy effect (a thing lasts at least as long as it's already lasted) that he could keep going another year, which gave him the conviction to add the paywall. COVID tanking his Airbnb stock forced the monetization decision, and it made meaningful money within a month.
- Internal quality bar over external validation: both Lenny (newsletter posts) and Michelle (charts) know a piece is done when it makes THEM laugh, tear up, or feel something, not when others approve. Lenny: "It's very like not waiting for other people to give you approval or feedback."
- Best content comes from practitioners, not pontificators: most of Lenny's posts are now guest posts where someone shares the single best thing from their career; the source of best advice is "people on the ground doing the thing for real, not just floating in the clouds pontificating." Michelle's pre-kids children's book wasn't good; the post-kids one worked because of lived experience.
- Heavy iteration is the unglamorous engine: Lenny rewrites a newsletter post ~50 times before it goes to his editor, copy editor, and designer; Michelle estimates ~60-100 iterations per chart. "Spend more time on it" was advice from his old boss.
- His creativity recipe is specific and physical: a single-shot latte (not too much caffeine, referencing XKCD's "Ballmer Peak" applied to coffee), a ~2-hour deadline that makes him "feel like a machine," a good night's sleep, and time spent living life to gather raw material (cites David Sedaris saying yes to everything for material).
- Defining PM: Lenny's definition is "deliver business impact by prioritizing and solving the most impactful business problems"; he defends the PM-as-mini-CEO framing, the PM should channel "what would the CEO do on this specific product?" His PM-to-now transfer wasn't tactics but habits: organization, a very high bar for quality, and succinct communication.
- Deliberately staying small and avoiding self-built traps: Lenny tries hard to never have full-time employees to keep things simple; warns you can "create a job for yourself that you hate" by saying yes to things people want or things that feel big, be careful what you commit to. He also notes the downside of monetizing a passion (per Adam J.K. Finch's "How to Become an Artist").

### Frameworks & mental models
- Lindy effect (longevity predicts future longevity)
- Ikigai (enjoy it / good at it / people value it / can make money)
- Ballmer Peak (XKCD) applied to coffee
- Happiness baseline / hedonic adaptation (UPenn Science of Happiness)
- PM as mini-CEO
- Follow the pull

### Notable quotes
> “The visual I always have is the Indiana Jones boulder is chasing me constantly. It's like this treadmill you're on.”

> “How often do you enjoy something and people value it? ... that Venn diagram of things.”

> “The source of the best advice is from practitioners doing the thing for real, not just floating in the clouds pontificating.”

> “You can create a job for yourself that you hate by doing things that people want you to do or that feel big, and then you're like, 'I hate this.'”


---

<!-- slug: qasar-younis -->
## The real AI revolution isn't software. It's farms, mines, and trucks. | Qasar Younis

**Qasar Younis** · 2026-03-08 · [▶ Watch](https://www.youtube.com/watch?v=_rcniEb9bLw)

> The $15B "physical AI" CEO nobody knows on why the real AI impact is tractors and trucks, why staying quiet wins, and how to build a truth-seeking culture.

**Topics:** physical ai, autonomous vehicles, company culture, founder advice, china vs us, ai anxiety

### Key lessons
- The biggest near-term AI impact is physical, not software: Applied Intuition adds intelligence to machines that already exist (cars, tractors, mining rigs, trucks, submarines) because the 50-60 years of hardware engineering is already done, you just inject a little intelligence. Younis's barometer: sit at the Detroit airport gate and count how many people use 'OpenClaw' (Claude Code), roughly zero, versus how many will be touched by autonomous vehicles.
- AI is coming 'just in time' to fill labor gaps, not steal jobs: average farmer age is ~58, long-haul trucking can't recruit because a working-class parent now picks Uber/DoorDash (turn the app off, pick up the kid) over weeks away from family. The right frame for autonomy is that 30,000+ Americans die in car accidents yearly and nobody is clamoring to work in mines, not 'what about the trucking jobs.'
- Don't compare Chinese 'companies' to American companies, read House of Huawei. ~25% of Huawei staff are Communist Party members; 'Huawei' means 'China's ambition,' so it's a state extension, not a profit-seeking firm. Reframe it as 'OpenAI vs the Chinese government' and 'Apple vs the Chinese government.' Chinese EVs look unbeatable only because the US equivalent (Rivian) is judged as a business that must turn a profit; remove the profit constraint and Tesla + others would field 'wow' products.
- Stay quiet and build (Berkshire Hathaway, not a Silicon Valley darling). Core value: 'Our best work is done alone and quietly.' Every minute spent on a podcast or X post is a minute not on customers/product. Caveat ('radical pragmatism'): Younis can do this only because he's already known (ex-YC COO, knows the network); a first-time unknown founder may genuinely need a following to recruit talent, investors, and customers, Naval's point that fame is a tool.
- Successful companies show traction early, then sustain it for a decade+. Heuristic for a founder ~2 years in and struggling: if market feedback is NOT pointing you toward a more and more specific path, hard-reset, the foundation (co-founders, market, or life-phase) may be wrong, not the table you keep adjusting. Treat your first startup as a guaranteed zero: you're a craftsperson building your first wobbly table and exercising the founder muscle; it's no accident Younis's third company is his most successful.
- Derive company values from why you're actually winning, not philosophy, write down the 5-10 reasons you're succeeding once you have traction, then compensate and promote against them (they assess managers on adherence). Applied's values: 'Move fast, move safe' (behavior measured: decisiveness), never disappoint the customer, technical mastery, high output, half the work is follow-up, and 'laugh a lot' (humor surfaces subtle feedback, 'it's not the best' vs 'this sucks').
- Build a truth-seeking culture where the best idea wins regardless of who raised it: the most junior person who worked at Zoox/Waymo/Tesla must feel safe sharing the one idea in their head. Counter-failure mode: Google (1B/month cash flow, 15-20x Facebook's size) couldn't beat Facebook because momentum/'wall of sound' drowns out the market changing, 'how does a gorilla learn to fly? By not being a gorilla.' But hold it in tension with decisiveness: once the debate ends, commit fully because you'll never get more information.
- Operationalize 'maintenance is the work' and remove emotion from decisions: weekly 'cleaning zen' (employees clean their own desks, Japanese-school style), no-shoe office, and the claim that they've never spent any capital they raised in ~10 years with 1,000+ engineers. On decisions: pretend nobody's feelings would be hurt and decide; a good heuristic for a low-emotion culture is that the same decision made by different people yields the same result. Read OLD, well-regarded books you know nothing about, time filters out the noise.

### Frameworks & mental models
- Radical pragmatism (core company value / advice filter)
- Industrial Revolution analogy for AI's societal impact
- The 'monkey brain' / rustle-in-the-bush fear reframe
- Tesla L2++ vs Waymo L4 autonomy spectrum
- Hard-reset heuristic for early-stage traction
- Values derived from why-you-win, tied to comp and promotion
- Truth-seeking culture vs 'wall of sound' momentum (gorilla-can't-fly)
- Score/valuation takes care of itself (Bill Walsh)

### Notable quotes
> “The core root of fear is misunderstanding... spend time to understand it and you will quickly see the limitations.”

> “Imagine instead of thinking OpenAI is competing against Deep Seek, you say OpenAI is competing against the Chinese government.”

> “Our best work is done alone and quietly.”

> “How does a gorilla learn how to fly? By not being a gorilla. The way Google would have won the social media wars was by being a social media company, and it's just fundamentally not.”


---

<!-- slug: jenny-wen -->
## The design process is dead. Here's what's replacing it. | Jenny Wen (head of design at Claude)

**Jenny Wen** · 2026-03-01 · [▶ Watch](https://www.youtube.com/watch?v=eh8bcBIAAFo)

> Anthropic's Claude design lead on why the classic design process is dead, what replaces it, and how design splits into execution-support vs. short-horizon vision.

**Topics:** design, ai tools, product development, hiring, leadership

### Key lessons
- The classic linear design process (research -> diverge/converge -> polished mocks) is effectively dead because engineers using AI ship so fast that designers can't gate it. Wen's time-allocation shifted from ~60-70% mocking/prototyping a few years ago to mocking now being only 30-40%, with another 30-40% jamming/pairing directly with engineers and a new slice spent implementing/polishing code herself.
- Design work has 'stratified' into two modes: (1) supporting implementation/execution (let engineers cook, then polish the last mile in code), and (2) creating direction/vision, but vision horizons collapsed from 2-5-10 year decks to scrappy 3-6 month prototypes that just point the team in one direction so seven parallel agents don't build divergent things.
- Ship early but commit to visibly iterating: Claude Co-work launched as a labeled 'research preview' ('this is the worst it's ever going to be'). The trust mechanism is 'building trust through speed', respond to feedback publicly, fix fast, show continuous shipping. The brand-killer is releasing early then going silent.
- Figma still earns its place for breadth-of-exploration (8-10 different directions at once) and fine visual/interaction micro-details, because coding tools are too linear, you over-invest in one direction and iterate on it. Wen still uses an IDE (VS Code) as a designer specifically because she's tweaking frontend CSS/classes and wants to see the code, an inversion as engineers move to terminals/agents.
- For non-deterministic AI products you cannot mock all the states or even make a clickable prototype, you must build with the real model underneath and discover use cases by watching real users (this is literally how Co-work emerged). The '10 days' to ship Co-work was just the final externalization sprint; the real journey was many internal prototypes (e.g. 'Claude Studio') that fed the skills/to-do/context form factors.
- Hiring archetypes for the AI era: (1) 'strong generalists', block/sideways-E shaped, ~80th percentile across multiple skills so they flex into PM/eng-shaped roles; (2) 'deep specialists', the bottom of the T goes deeper than most (e.g. a designer who's basically 50% software engineer, valuable now because you work directly with the model); (3) the overlooked 'craft new grad', early-career, humble, fast learner unburdened by baked-in process. Advice to break in: build and ship lots of real things, not theory.
- Managers should do a stint back in IC work: Wen returned to full-time IC at Anthropic to learn the new hard skills firsthand, arguing you can't empathize with or guide teams through this shift without working that way. She mirrors how eng orgs rotate new EMs through hands-on tasks before managing. Future managers must combine direction-setting with people management, not pure people management.
- Two leadership rituals: (1) 'low-leverage time isn't real', senior leaders dogfooding the product, reproing bugs, filing PRs (she cites Mike Krieger) is actually high-leverage because of who's doing it and the culture it sets; (2) cultivate enough psychological safety that teammates roast you (mimicking her crit phrases) while still holding very high standards, 'tough parent' / radical candor.

### Frameworks & mental models
- Two stratified modes of design work (execution-support vs. short-horizon vision)
- Building trust through speed
- T-shaped / block-shaped (sideways-E/F) / deep-T talent archetypes + the 'craft new grad'
- The legibility 2x2 (legible/illegible founders x ideas), Evan Tana/SPC, applied internally: designers as VCs spotting illegible ideas
- Low-leverage-is-high-leverage manager principle
- Psychological safety + high standards ('tough parent' / radical candor)

### Notable quotes
> “This design process that designers have been taught, we sort of treat it as gospel. That's basically dead.”

> “You're better off not blocking that, letting them cook.”

> “It's not just designers feeling like we have to keep up with engineers, even engineers are like, how do we keep up with ourselves? How do we keep up with all our agents?”

> “A lot of the hard parts of building software are actually not building it... Someone still needs to be accountable for the decision.”


---

<!-- slug: jeetu-patel -->
## AI is critical for humanity's survival: Cisco President on the AI revolution | Jeetu Patel

**Jeetu Patel** · 2026-02-26 · [▶ Watch](https://www.youtube.com/watch?v=ylNKlBlkFas)

> Cisco's CPO/President on going all-in on AI at 90k-employee scale, the enterprise "capabilities overhang," and a 6-part company-building framework where timing trumps everything.

**Topics:** enterprise ai adoption, ai infrastructure, leadership, product strategy, company building, ai safety

### Key lessons
- The enterprise 'capabilities overhang' is real: the frontier is solving hard science problems while enterprises struggle with adoption. Coding is the breakout use case (Cisco's first product ~100% AI-written shipping within 2 weeks), but every other business function requires nuanced, function-specific understanding, there's no one-size-fits-all rollout.
- Cisco frames AI as critical infrastructure addressing 3 constraints that could hold AI back: (1) infrastructure, not enough power/compute/network to connect GPUs across data centers up to 800km apart that must run in perfect sync during training; (2) a trust deficit, non-deterministic models that hallucinate need safety/security baked in; (3) a data gap, running out of human-generated internet data, so growth shifts to proprietary enterprise data, synthetic data, and machine data (Cisco's play).
- Going AI-first at scale required 3 moves: don't hedge, large companies experiment plenty but fail to double-down when an experiment works; align personal and company success so employees know NOT using AI is what threatens their job; and shift from a 'holding company of 251 acquisitions' running siloed $40M GM fiefdoms to a 'loosely coupled but tightly integrated' platform where customers feel the same emotion across products.
- 'Right to win / permission to play': only build where it's logical that YOUR company built it AND you have a route to market for mass-scale distribution. Cisco networking GPUs is believable after 40 years of infrastructure; Cisco doing B2C is not. Patel says no to ~99% of new-market ideas to avoid dissipating 'caloric burn', focused calorie expenditure yields outsized returns.
- Own the storytelling personally, don't delegate it or let it become a post-product marketing exercise. Board advice he took: be the custodian of the message and tell it directly to the front line to avoid the 'telephone game' / 'packet loss.' Hidden benefit: forcing himself to articulate the story massively simplified an enormously broad business.
- Reject 'praise in public, criticize in private.' Patel does the opposite: critique and debate directly IN public (respectfully, watching tone), and use private time to build trust and tell people you've got their back. Conflict is a necessary condition of business, but productive conflict requires pre-established trust. Skip the compliment sandwich, treat people like adults and give them the facts.
- Infrastructure mindset: 'you don't always get the glory, but you always get the blame.' Great infra companies orient on ECOSYSTEM success, a healthcare customer doubles down because 'when the infrastructure doesn't work, people die.' No one thanks you when the network works; you only hear about it when it breaks.
- Distinguish a mega-trend from a hype cycle: a mega-trend is easy to explain (you ask ChatGPT a question, get an answer, you get it); if you need a PhD to understand a use case, it won't have outsized population-scale impact (Web3 was the example). Plan for the world 6 months out, not today's, AI moves so fast your assumption sets will change; don't let experience bias you into building for the present.

### Frameworks & mental models
- 6-part company-building framework (descending importance, all required): Timing > Market > Team > Product > Brand > Distribution
- Right to win / Permission to play (logical-builder test + route-to-market test)
- Loosely coupled but tightly integrated (platform vs. holding-company)
- Mega-trend vs. hype cycle ('do you need a PhD to understand it?' heuristic)
- AI as a teammate, not a tool
- Don't be stingy with words (critique in public, build trust in private)
- Stamina/persistence trumps intellect

### Notable quotes
> “Stop trying to think of this as a tool. Think of this as a teammate that got added to your team, and your framing will change.”

> “Hallucination is a feature when you're writing poetry, but when you're trying to run predictable systems, hallucination can be a bad thing.”

> “In infrastructure you don't always get the glory, but you always get the blame... when the infrastructure doesn't work, people die.”

> “Timing trumps market, market trumps team, team trumps product, product trumps brand, brand trumps distribution. You don't have all six, you don't win.”


---

<!-- slug: boris-cherny -->
## Head of Claude Code: What happens after coding is solved | Boris Cherny

**Boris Cherny** · 2026-02-19 · [▶ Watch](https://www.youtube.com/watch?v=We7BZVKbCVw)

> Claude Code's creator on how 100% of his code is now AI-written, "build for the model 6 months out," and latent demand as the #1 product principle.

**Topics:** ai agents, ai coding, product strategy, ai safety, leadership, future of work

### Key lessons
- Build for the model 6 months out, not today's model: Cherny wrote almost none of his own code in Claude Code's early days because Sonnet 3.5 wasn't good enough, but the product was architected so that when Opus 4 / Sonnet 4 (their first ASL-3 class model, May 2025) landed, adoption inflected and went exponential. Accept poor PMF for the first ~6 months as the price of being ready when the capability arrives.
- Latent demand is his single most important product principle: watch people 'abuse' a product to do something it wasn't designed for, then build the dedicated product. Examples cited: Facebook Marketplace (40% of group posts were buying/selling), Facebook Dating (60% of profile views were opposite-gender non-friends), and Co-work itself (people using Claude Code in a terminal to grow tomatoes, analyze a genome, recover wedding photos, read an MRI). The modern twist: also watch what the *model* is trying to do and remove friction for it ('being on distribution').
- Don't box the model in. A year ago you needed heavy scaffolding/orchestrators forcing step-1-2-3 workflows; now give the model a goal plus tools and let it figure out order and context. Scaffolding buys ~10-20% performance that gets wiped out by the next model release, so it's often better to just wait for the next model. They inverted the usual design: 'the product is the model' with minimal scaffolding.
- Use the most capable model with max effort, counterintuitively for cost: cheaper models (Sonnet vs Opus 4.6) are less intelligent so they burn MORE tokens correcting and hand-holding, so a 'cheaper' model is often more expensive per task. Don't optimize/cost-cut early; give engineers unlimited tokens to test crazy ideas, then optimize (Haiku/Sonnet) only once something works and scales. Anthropic has engineers spending hundreds of thousands a month in tokens.
- Concrete Claude Code workflow tips: start ~80% of tasks in plan mode (literally just one injected sentence, 'please don't write any code yet', shift-tab twice in terminal), let it produce a plan, then auto-accept edits because Opus 4.6 one-shots it; and experiment across form factors (terminal, desktop app, iOS/Android, Slack) since it's the same agent everywhere. Cherny's own coding is now ~1/3 terminal, 1/3 desktop, 1/3 iOS app.
- Under-resource projects on purpose to force 'Claudification', putting one engineer on a project makes them automate aggressively. Productivity per engineer at Anthropic rose 200% in PRs over the year (vs the few-percent gains he saw running code quality for Facebook/Instagram/WhatsApp at Meta); they ~4x'd the eng team yet ship far more. Cherny personally ships 10-30 PRs/day, has edited zero lines by hand since November, and runs ~5 agents in parallel.
- Hire generalists who cross disciplines: on the Claude Code team everyone codes (PM, EM, designer, finance, data scientist) and the strongest contributors blend product+infra, product+design, or product+business sense. He predicts that by end of year the title 'software engineer' starts disappearing, replaced by 'builder,' and 'everyone is a product manager and everyone codes.'
- Anthropic's safety stack is three layers, and shipping early IS a safety strategy: (1) alignment / mechanistic interpretability, peering at neurons, monitoring e.g. a 'deception' neuron, superposition; (2) evals in a 'petri dish'; (3) behavior in the wild. They ran Claude Code internally 4-5 months before release to study it as the first big agent, label new things 'research preview,' and open-sourced a model-agnostic sandbox, their 'race to the top' approach.

### Frameworks & mental models
- Build for the model 6 months out
- Latent demand (apply to both users and the model / 'being on distribution')
- Don't box the model in
- The Bitter Lesson (Rich Sutton), bet on the more general model
- Under-funding / 'Claudify'
- Three-layer safety stack (alignment+interpretability / evals / in-the-wild)
- Race to the top

### Notable quotes
> “100% of my code is written by Claude Code. I have not edited a single line by hand since November. Every day I ship 10, 20, 30 pull requests.”

> “Coding is virtually solved. At least for the kinds of programming that I do, it's just a solved problem because Claude can do it.”

> “An agent has a very specific technical meaning: it's an LLM that's able to use tools. So it doesn't just talk, it can actually act and interact with your system.”

> “The title software engineer is going to start to go away and it's just going to be replaced by builder, or maybe everyone's going to be a product manager and everyone codes.”


---

<!-- slug: brian-halligan -->
## How to be a CEO when AI breaks all the old playbooks | Sequoia CEO Coach Brian Halligan

**Brian Halligan** · 2026-02-15 · [▶ Watch](https://www.youtube.com/watch?v=3UyitfSbY6c)

> HubSpot co-founder turned Sequoia CEO coach on hiring spiky over safe, "Halliganisms," and why AI changes the top of the funnel but not enterprise sales (yet).

**Topics:** ceo coaching, hiring, ai gtm, leadership, scaling, enterprise sales

### Key lessons
- Hire spiky, not safe: HubSpot stopped picking the candidate everyone rated 3/4 (fewest weaknesses) and started hiring the polarizing 4/4-and-2/4 candidate, and their hit rate improved. They also shrank interview panels from 8 to 4 people.
- Avoid the big-company hire at small scale: hiring fancy-title execs from Microsoft/Salesforce/Google at a 50-500 person startup created a near-100% attrition rate because of the 'impedance mismatch' in expectations; the McKinsey cohort 'never works' because consultants are conservative while founders rethink conventional wisdom.
- Better blind references: don't 'mail it in.' Ask sharp questions like 'On a scale of 1-10, would you enthusiastically rehire this person for this role?' and 'Were they in the top 1%/10% of your employees?' Parker Conrad's hack: have a C-level candidate sign an NDA, send them a board deck, then chat for 30 min, if they're only complimentary it's a red flag (you want a challenger, not a yes-person).
- The LOCKS algorithm for evaluating founders/CEOs: Lovable (inspires followership), Obsessed (deep founder-market fit, evidence of going down rabbit holes), Chip on the shoulder (a Sequoia trait), deeply Knowledgeable about the domain, and Student of the game (constantly learning, like an LLM).
- AI will change the top of the funnel first, not enterprise sales: buyers will research inside ChatGPT/Gemini/Anthropic instead of clicking blue links, so websites get less important and homepages become an all-knowing avatar you converse with; HubSpot built one and it's working. But enterprise sales (trust 'between two carbon-based life forms') will be the last white-collar job AI replaces.
- AI hasn't changed enterprise GTM mechanics yet: AI-driven companies hire the same roles and run the same enterprise sales process as the 1990s, except SEs are now relabeled 'forward-deployed engineers'/'solutions consultants.' Planning cycles compressed from ~1 year to ~3 months, raising the bar on fast decision-making and 'a massive tax on optionality.'
- DRI religion ('if you want to kill a plant, have two people water it'): everything important happens cross-functionally at scale, so one powerful directly-responsible individual must own it with authority over other divisions; committees never work. This pain only shows up after ~150 employees.
- Solve CV > EV > TV > MV (customer, then enterprise value, then team value, then me): immature managers optimize for their own team's bookings/metrics; HubSpot caught this via quarterly employee+customer NPS by department (e.g. sales NPS dropping 68 -> 30 -> -5 once a leader lost the team, almost never recovers), and baked EV-orientation into review forms and 'champagne award' recognition.

### Frameworks & mental models
- LOCKS algorithm (Lovable, Obsessed, Chip on shoulder, Knowledgeable, Student) for evaluating CEOs/founders
- 5-tool CEO (code, taste, vision, sell the product, convince employees), baseball '52 player' analogy
- CV > EV > TV > MV prioritization (Customer > Enterprise > Team > Me value)
- DRI (Directly Responsible Individual), 'kill a plant with two people watering it'
- Hire slow, fire fast (vs. the common hire fast, fire slow)
- Halliganisms (e.g. 'eat the sandwich, don't nibble'; 'never waste a good crisis'; 'no silver bullet, just lots of lead bullets')
- Kids table vs. adults table (CEO peer groups under/over 100 employees)
- Flash tags / FYI tagging system (Dharmesh's rubric for signaling do-now vs. discuss vs. FYI in CEO messages)
- Next play (Coach Krzyzewski), move on from unforced errors
- 2004 Red Sox team-building (homegrown talent + a few seasoned free agents)

### Notable quotes
> “I think CEOs and everyone dramatically overrates their ability to interview and overrates their gut feeling and underrates a really high quality blind reference.”

> “Companies are far more likely to die of overeating than indigestion.”

> “Old enterprise sales, where there's actual trust built up between two carbon-based life forms, will be very, very, very late to go in the white-collar world.”

> “If you want to kill a plant, have two people water it.”


---

<!-- slug: sherwin-wu -->
## OpenAI's head of platform engineering on the next 12-24 months of AI | Sherwin Wu

**Sherwin Wu** · 2026-02-12 · [▶ Watch](https://www.youtube.com/watch?v=B26CwKm5C1k)

> OpenAI's API eng lead on 95% Codex-written code, managing fleets of 20+ agents, why AI deployments go negative-ROI, and building for where models are going.

**Topics:** ai agents, enterprise ai adoption, engineering management, business process automation, platform strategy, ai roi

### Key lessons
- At OpenAI, 95% of engineers use Codex daily and 100% of PRs are reviewed by Codex; nearly 100% of code is AI-generated first, then human-reviewed. Engineers who use Codex more open ~70% more PRs and that gap keeps widening.
- Engineers are becoming tech-lead/managers of agent fleets, many run 10-20 parallel Codex threads, steering and checking in rather than writing code (the 'sorcerer's apprentice' problem: high leverage but you must steer or the brooms go wild).
- When a coding agent fails, it's usually a context/underspecification problem, not a model problem. The fix is encoding tribal knowledge into the repo, code comments, structure, MD/skills files, so the agent has what it needs. (Lesson from an internal team running a 100% Codex-written codebase with NO escape hatch to hand-coding.)
- The anti-pattern for enterprise AI: top-down-only mandates (C-suite buys tools, ties it to performance reviews) with no bottoms-up adoption, produces a workforce that 'knows it should use this' but doesn't know how, leading to likely negative ROI. The fix: staff a full-time 'tiger team' of the most excited people (often technical-adjacent non-engineers like an Excel-wizard ops lead) to explore capabilities, run hackathons/seminars, and evangelize.
- 'The models will eat your scaffolding for breakfast', vector stores (2023), agent frameworks, and even today's skills/file-based context will likely be obsoleted as models improve. Don't blindly chase customer feature requests into a local maximum; build for where models are going, not where they are today.
- Best startups build a product for a capability that's ~80% there today, it 'kind of works' but suddenly clicks (e.g., O3 → 5.1) as models improve, giving a far better experience than assuming static capability.
- On model trajectory (per METER benchmark): frontier models do multi-hour SE tasks ~50% of the time, ~sub-hour at 80%. Sherwin expects coherent multi-hour (toward 6-hour) tasks in 12-18 months, which will demand differently-shaped products. He's also bullish on native speech-to-speech audio models as an underrated enterprise unlock.
- Don't fear OpenAI squashing you, startups die from building things customers don't love, not from lab competition. The space is so big VCs now back competing companies freely. OpenAI runs as a neutral ecosystem/platform (every model ships to the API, no blocking competitors) because its charter is to spread AGI's benefits to all humanity, which it can't reach alone.

### Frameworks & mental models
- Sorcerer's apprentice / wizard metaphor (from SICP, 'the wizard book') for vibe-coding leverage and the need to steer agents
- Software-engineer-as-surgeon (from The Mythical Man-Month), empower one person, manager's job is to look around corners and have the scalpel ready
- Spend >50% of management time on your top ~10% performers, 'AI makes good people better and great people exceptional' (Marc Andreessen)
- The bitter lesson, applied to building with AI, remove hand-built logic/scaffolding, trust the model, give it tools
- Build for where the models are going, not where they are today (~80%-there product that clicks as models improve)
- One-person billion-dollar startup and its 2nd/3rd-order effects, a 'golden age of B2B SaaS' of thousands of micro-startups serving each other
- Top-down + bottoms-up AI adoption with a full-time 'tiger team' of evangelists
- Business process automation thesis, repeatable, high-determinism, SOP-driven work outside the SV bubble as the bigger AI opportunity

### Notable quotes
> “The models will eat your scaffolding for breakfast.”

> “This is the worst the models will ever be. (Kevin Weil)”

> “We in Silicon Valley just forget that we live in a bubble... most people in the US are not software engineers, are not very AI-pilled.”

> “Make sure you're building for where the models are going and not where they are today.”


---

<!-- slug: professional-vibe-coder -->
## The rise of the professional vibe coder (a new AI-era job)

**Lazar Jovanovic** · 2026-02-08 · [▶ Watch](https://www.youtube.com/watch?v=0XNkUdzxiZI)

> Lovable's first "vibe coding engineer" on shipping production AI products with zero coding background, clarity, context, and taste over code.

**Topics:** vibe coding, ai tools, product management, career, design, prototyping

### Key lessons
- Spend 80% of time planning/chatting and only 20% executing. 'Optimize for the right kind of speed', coding is the solved problem; clarity is what you're actually solving for. Lazar reads the AGENT output religiously, never the code itself.
- Parallel-build technique for clarity: open 4-5 tabs and seed each differently, (1) voice/whisper brain-dump, (2) typed-out prompt with features/pages, (3) attach a reference screenshot from Mobin or Dribbble, (4) paste actual CODE SNIPPETS from libraries like 21st.dev. 'English is the number one programming language, but Lovable still communicates in code the best, give it code for pixel-perfect results.' Compare the variants; clarity compounds and you avoid being locked into a bad first design (saving hundreds of credits later).
- Build a layered set of markdown source-of-truth docs before building: master-plan.md (10k-ft intent/why/who/feel), implementation-plan.md (build order, backend, tables, auth, then API), design-guidelines.md (with actual CSS so AI doesn't over-create), user-journeys.md, then tasks.md (the nitty-gritty subtasks all other docs feed into), plus rules.md/agent.md telling the agent 'read all PRDs and tasks.md before doing anything, do the next task, then tell me how to test it.'
- The 'three wishes' / context-window discipline: LLMs have a finite token budget (~genie grants 3 wishes, not 3,000). One task at a time keeps the context small so the agent doesn't burn 80% of tokens just reading a 60-70 edge-function codebase to find a bug, leaving only 20% to actually fix it (and then it 'picks the easiest fix in the book').
- The 4x4 debug framework, attempt each only ONCE: (1) click Lovable's 'try to fix'; (2) add an awareness layer, open the preview, right-click the broken function, read the browser console log, or ask the tool to write console.logs in relevant files, then paste the output into chat ('99% of the time that's enough'); (3) bring in an external diagnostician, export to GitHub and use Codex (diagnostic only, he won't let it make edits) or repomix to compress the whole codebase into one file for Claude/ChatGPT; (4) revert 3 steps, take a walk, re-prompt, 'it's your fault, you had a bad prompt.'
- After fixing a bug, ask the tool 'how can you help me prompt you better so next time we do it in one go?', then put the answer into rules.md so the agent prompts itself better. 'You're just going to learn that I'm stupid and you're going to prompt yourself better.'
- Don't over-invest in skills the tools will absorb: Lazar deliberately does NOT optimize for context-juggling or workarounds because agents will do it within months ('a year ago this would blow your mind; my March vibe-coding course is now obsolete'). Invest instead in judgment, taste, copy, fonts ('60%+ of how your output looks'), and exposure time, 'set aside more time on learning than building.'
- How the role became a job: build in public. Lazar got hired off a single conversation with Elena Verna because he was already vibe coding publicly (YouTube, LinkedIn) and sharing every failure. 'You don't need a company to hire you, you can hire yourself as a professional vibe coder first.' Some Lovable candidates got hired by sending a Lovable APP instead of a resume, 'we'll always open a *.lovable.app domain.'

### Frameworks & mental models
- Aladdin/genie three-wishes analogy (token/context-window limits)
- Parallel multi-tab build technique (4-5 seeded variants)
- Layered PRD docs (master-plan / implementation-plan / design-guidelines / user-journeys / tasks.md + rules.md)
- 4x4 debugging framework
- Exposure time (taste-building via deliberate exposure to world-class work)
- Demo don't memo
- Converging PM/engineer/designer Venn diagram
- Calligraphy analogy (hand-coding becomes a rare art)

### Notable quotes
> “The ceiling on the AI isn't the model intelligence, it's what the model sees before it acts.”

> “We won't be rewarded in the world of AI for faster raw output. We will be rewarded for better judgment.”

> “Coding is going to be like calligraphy... it's going to be so rare that it's going to become an art.”

> “Everybody produces good enough with AI. So now learning and optimizing for how do I produce world-class and magic is the key lesson, you can code garbage fast as well as magic fast. It's the same amount of time.”


---

<!-- slug: becky-kennedy -->
## A child psychologist's guide to working with difficult adults | Dr. Becky Kennedy

**Dr. Becky Kennedy** · 2026-02-01 · [▶ Watch](https://www.youtube.com/watch?v=Auxs8ZsHRI4)

> A clinical psychologist maps her parenting playbook onto leadership: repair, sturdy authority, boundaries-as-what-you-do, and "I believe you AND I believe in you."

**Topics:** leadership, management, feedback, psychological safety, communication, company building

### Key lessons
- Repair, not perfection, is what builds secure attachment - and trust at work. 'Perfect is creepy.' Going back after a bad moment ('earlier I cut you off and used a harsh tone, that's no excuse, I'm sorry') reestablishes trust faster than anything else and cuts defensive, run-on conversations.
- Separate behavior from identity, literally with two hands. Defensiveness happens because people think you're attacking their identity, not their behavior. Open hard conversations with 'we're on the same team, I know you're a good person, you don't need me to tell you we need to start on time - but it keeps happening, so something's going on, let's get to the bottom of it together.'
- Connect before correct, and the first step is a MINDSET not a script: people feel your intention, not just your intervention. A 30-second 'connection' performed as a transaction to extract compliance feels dirty and fails. At work it's 'tell me about your weekend' without counting seconds until you can assign the next task.
- Use the Most Generous Interpretation (MGI). The least generous story you tell about a person at night becomes the leader you are the next morning. For someone belaboring a point: MGI = 'maybe they didn't feel heard,' which produces a private fix ('I wonder if you don't always feel heard, then the room tunes out, which makes you belabor more - we're in a bad cycle') instead of culture-corroding gossip.
- Boundaries = what YOU will tell someone you'll do, requiring the other person to do nothing. 'Don't press the elevator buttons or no dessert' is a request that hands your power to a toddler; 'I'm going to stand between you and the buttons' is a boundary. Threats undermine authority because you won't enforce them (you'll give the sorbet anyway).
- Be the sturdy leader: the airline-pilot metaphor. Three responses to turbulence - (1) 'stop screaming, you're distracting me' = unsafe, (2) 'does anyone want to fly the plane?' = the overcorrected validation trap where feelings dictate decisions, (3) 'this turbulence scares you, it doesn't scare me, I know what I'm doing' = sturdy. Validate the emotion as real for them WITHOUT being overwhelmed by it. Some decisions are leadership decisions, not consensus decisions, because only you hold certain information.
- Optimize for resilience over happiness. 'Optimizing for happiness in childhood is the quickest way to build anxiety and fragility in adulthood.' At work, withholding hard feedback to spare feelings (the Kim Scott story: nine months of silence, then a surprise firing) hurts people far worse. A resilient culture says 'this is hard and I can do hard things,' not 'this is hard, so someone must be at fault.'
- The 'I believe you AND I believe in you' formula. Picture the struggler in a hole: 'I believe you' = one foot in the hole (validation), 'I believe in you' = one foot out, seeing a more capable version than they can see right now. We over-rotate on validation and forget conviction. Pairing them ('this is genuinely hard, AND I know you can figure it out, I won't take the project away because I won't take the feeling of capability away') is the magic.

### Frameworks & mental models
- Repair (the #1 relationship strategy)
- Connect before correct
- Separating behavior from identity (good inside)
- Most Generous Interpretation (MGI)
- Sturdy leadership / the airline pilot metaphor
- Boundaries vs. requests (what you will do, requiring the other to do nothing)
- Resilience over happiness
- I believe you + I believe in you
- Feelings overpower skills (bad behavior = a missing skill)

### Notable quotes
> “Perfect is creepy. Only nonhumans can ever be perfect.”

> “The story you tell yourself about your kid at night kind of becomes the parent you are the next morning. Probably the same is true: the story you tell yourself about your organization at night becomes the leader you are the next morning.”

> “Boundaries are what you tell someone else you will do. And it requires the other person to do nothing.”

> “This turbulence, though it scares you, it doesn't scare me. I'm going to get off this loudspeaker to go do my job. I'll see you when we land. Now even if the turbulence is the same, all of a sudden I feel this deep breath because my worry is contained.”


---

<!-- slug: marc-andreessen -->
## Marc Andreessen: The real AI boom hasn't even started yet

**Marc Andreessen** · 2026-01-29 · [▶ Watch](https://www.youtube.com/watch?v=87Pm0SGTtN8)

> Andreessen reframes AI as the philosopher's stone arriving exactly as depopulation and 50 years of stagnant productivity demand it, and why human workers get more valuable, not less.

**Topics:** ai future, careers, founders, venture capital, moats, education

### Key lessons
- The job-loss panic is the wrong frame: US productivity growth has run at ~half the 1940-1970 rate and ~a third the 1870-1940 rate, so even if AI TRIPLES productivity it only returns us to 1870-1930-era job churn, a period everyone remembered as awash with opportunity. Combined with depopulation (reproduction below 2 in many countries) and falling immigration, remaining human workers go to a premium, not a discount.
- Look at TASK loss, not job loss. A job is a bundle of tasks; the job persists longer than the individual tasks. His example: 1970s executives dictated to secretaries who typed and mailed letters, today execs do their own email while secretaries shifted to travel/event planning. Coding, PM, and design jobs will see tasks swap out the same way.
- The 'Mexican standoff' between PM, engineer, and designer: every coder now thinks AI lets them also PM and design, every PM thinks they can code and design, every designer thinks they can PM and code, and they're all roughly correct because AI is now genuinely good at all three. The winners pick up the other two roles and become 'superpowered individuals' / unicorns who can build and design products end to end.
- The T-shaped (or 'E/F on its side') strategy via Scott Adams: being good at two things is MORE than double the value, three things MORE than triple, you become a 'super-relevant specialist in the combination.' Adams could've been a decent cartoonist OR decent at business; being both made him uniquely able to write Dilbert. Larry Summers' version: 'don't be fungible', don't be a cog/just one thing.
- Still learn to code (and go all the way down to assembly/chip level) IF you want to be elite, because the best coders now 'orchestrate 10 coding bots in parallel,' and you can't evaluate or debug what the bots produce if you don't understand it. If you just want mediocre code, let AI do it; it'll generate infinite mediocre code fine.
- Underused superpower: use AI to TEACH you, not just do work for you. 'Spend every spare hour talking to AI: train me up.' Concrete tactics from the chat, watch the agent's output/thinking as it works to learn architecture; when you get unstuck ask 'what could I have said to avoid this error?'; have one AI write code and another debug/critique it ('LLM councils').
- Don't over-obsess on moats yet, early predictions in big platform shifts ('read 1993-2010 internet coverage') were almost all badly wrong. AI models look defensible (billions in capex, scarce talent) yet got commoditized fast: within ~18 months of ChatGPT there were ~5 US labs, ~5 Chinese, plus open source at parity. Claude Code built 'Cowork' in a week and a half, impressive, but also shows how low the barrier can be. Be flexible and adaptable instead.
- On AGI: the 'cosmic'/singularity definition overstates it, the 'basket of valuable tasks' definition understates it. Human IQ caps around 160 (Einstein level) purely due to biology, there's no reason that's the cap for machines. Today's models test ~131-140; expect 160, 180, 200+. The 'human-equivalent' milestone will be a footnote, the real story is exceeding human capability across coding, medicine, and law.

### Frameworks & mental models
- The philosopher's stone (sand -> thought; alchemy of common into rare)
- Task vs. job (a job is a bundle of tasks; tasks change before jobs do)
- The Mexican standoff (PM / engineer / designer; in Hollywood: director / writer / actor)
- Superpowered individual
- T-shaped / Scott Adams combination skills ('don't be fungible' - Larry Summers)
- Bloom's two-sigma effect (1:1 tutoring; AI as the scalable tutor)
- Determinate vs. indeterminate optimism (Peter Thiel 2x2; a16z = indeterminate optimist running many bets)
- Barbell media diet (read X / up-to-the-minute, and old books / timeless; distrust the middle)

### Notable quotes
> “We now have a technology that transfers the most common thing in the world, which is sand, into the most rare thing in the world, which is thought. AI is the philosopher's stone.”

> “If we didn't have AI, we'd be in a panic right now about what's going to happen to the economy... The timing has worked out miraculously well: we're going to have AI and robots precisely when we actually need them.”

> “Everybody wants to talk about job loss, but really what you want to look at is task loss. The job persists longer than the individual tasks.”

> “The history of the last three years has been everything that looks like the fundamental breakthrough gets replicated and lapped very quickly... there really aren't any secrets among the big labs.”


---

<!-- slug: jason-cohen -->
## The surprising advice from a founder who built 2 unicorns | Jason Cohen (WP Engine)

**Jason Cohen** · 2026-01-25 · [▶ Watch](https://www.youtube.com/watch?v=8xLquwfx6p0)

> A 5-question diagnostic for stalled growth (churn, pricing, NRR, channel saturation, "do you even need to grow?") from a 4x founder of 2 unicorns.

**Topics:** growth, churn, pricing, positioning, nrr, gtm channels

### Key lessons
- The growth ceiling math: your max customer count = (new customers/month) / cancellation rate. At 100 new/month and 5% churn, you can NEVER exceed 2,000 customers. Cancellations grow exponentially with size (% of base) while marketing only grows linearly, so churn always overtakes marketing, diagnose this FIRST because it's a hard cap.
- Reframe the cancellation survey question. Groove changed 'Why did you cancel?' to 'What made you cancel?' and usable responses jumped from 10% to 20%. Randomize dropdown options, when Smart Bear did this, all reasons got picked equally, proving the data was noise (people pick the first item).
- 'Too expensive' is never the real reason, they already saw the pricing page and bought. Use medical-style cause analysis (stopped breathing -> car crash -> passed out -> undiagnosed diabetes) to dig to the 'rooter cause'; Cohen rejects single-root-cause thinking entirely.
- Pricing selects the market, the demand curve is a mesa, not a downward line. A mid-size company (1,000 employees, $400M revenue) won't buy a $2 or $100/month tool because it 'can't be good enough.' One founder 12x'd his price (per-year to per-month) and signups didn't change at all, proving he was nowhere near the ceiling.
- The Double Down positioning lesson: same product, 8x the price by selling growth not savings. 'Cut AdWords cost in half' caps you at ~$5k/month (customer needs to actually save money). 'Double your leads for the same ROI' lets you charge the full $40k because the customer was already willing to spend $40k for that lead volume. Sell more of what the CEO values (growth), not cost savings.
- NRR alone is misleading because losses need a bigger gain to recover (down 20% then up 20% = 96%, not 100%). Track BOTH logo churn (N) and NRR. Proof point: of 100+ public SaaS companies only ~2 have NRR below 100%, and median NRR at IPO is 119%, 100%+ NRR is mandatory for durable growth.
- Channels follow an 'elephant curve' not an S-curve, they start S-shaped then the 'butt sags' as audiences saturate and channels quietly decline (magazines/conferences report great numbers right before going under). Adding one feature and 'flogging AdWords' won't restart growth. Get creative: Constant Contact ran in-person city workshops for a $20/month product; HubSpot's agency channel became 50% of revenue in 4-5 years.
- AB testing mostly doesn't work for non-experts: it can't test strategy/vision, and on details most 'winners' are false positives (when the real effect is rare, false positives outnumber true ones even at 95% accuracy). Even Shopify's ~100-person team sees ~1/3 of measured effects vanish in holdout re-checks. 'If you don't know who the fish is at the poker table, it's you.'

### Frameworks & mental models
- 5-question stalled-growth diagnostic (1. Are customers leaving? / logo churn 2. Is pricing/positioning correct? 3. Are existing customers growing? / NRR 4. Are acquisition channels saturated? 5. Do you need to grow?)
- Growth-ceiling formula: max size = new customers / cancellation rate
- 'What made you cancel?' open-ended cancellation survey
- Rooter-cause analysis (vs. single root cause / five whys)
- Pricing demand 'mesa' curve (vs. textbook downward demand curve)
- Create value for the customer, then split it (value-based pricing)
- Elephant curve (channel decay model)
- One-foot-in-strength expansion framework for new products/markets
- Create value -> deliver -> onboard -> customer realizes it -> you measure it (the common thread)

### Notable quotes
> “Your prices are way too low because you just guessed and you haven't changed them.”

> “Think about the gauntlet they went through to get to the product... and after all of that, which clearly means they wanted it to work, they're like 'No, bye.' You've got to go, wait a minute, that's terrible.”

> “If you don't know who the fish is at the poker table, it's you.”

> “If you are not growing, you're dying, well, maybe that's you the person, not you the company.”


---

<!-- slug: zevi-arnovitz -->
## How a Meta PM ships products without ever writing code | Zevi Arnovitz

**Zevi Arnovitz** · 2026-01-18 · [▶ Watch](https://www.youtube.com/watch?v=1em64iUFt3U)

> A non-technical Meta PM's exact slash-command workflow for shipping real products in Cursor + Claude Code, and using multiple LLMs to peer-review each other's code.

**Topics:** ai coding, vibe coding, pm workflow, non-technical builder, career, ai agents

### Key lessons
- Build a 7-step slash-command pipeline in Cursor/Claude Code: /create-issue (capture bug-or-idea into Linear fast via MCP), /exploration-phase (Claude reads the codebase + asks clarifying questions), /create-plan (outputs a markdown plan with TLDR, critical decisions, status-tracked tasks), /execute, /review, /peer-review, then update docs. Reusable prompts saved as files in the repo.
- The 'peer review' trick: run code review in Claude, Codex, AND Cursor Composer separately, then feed the other models' findings back via a /peer-review command that frames Claude as the 'dev lead', instructing it to defend why flagged issues aren't real OR fix them. Let the models 'fight it out' until no issues remain (Claude sometimes gets sassy: 'this has been raised for the third time and for the third time I'm telling you this is by design').
- Start by creating a ChatGPT/Claude 'project' (shared instructions + knowledge base) prompted to act as a CTO/technical co-founder that challenges you and is NOT a people-pleaser, to mitigate sycophancy. Graduate gradually: GPT project -> Bolt/Lovable -> Cursor in light mode -> full dark mode terminal. Treat looking at code as 'exposure therapy.'
- Match models to their strengths: Cursor's Composer for speed on non-complex work (full features in minutes); Gemini 3 for UI/front-end (split plans into backend/frontend and let Gemini read the plan); Claude as the communicative opinionated dev lead; Codex (5.1 Max) for the gnarliest bugs. The markdown plan file is the shared artifact passed between models.
- Run constant post-mortems on AI mistakes: when Claude makes a bad bug, ask 'what in your system prompt or tooling made you make this mistake?', let it introspect, then update CLAUDE.md / slash commands / docs so the mistake never recurs. Updating documentation and tooling is one of the biggest productivity hacks, your workflow gets smarter, not just the models.
- The /learning-opportunity command primes Claude with 'I am a technical PM in the making with mid-level engineering knowledge, explain this using the 80/20 rule', used whenever something is hard to understand, turning every build into a learning loop. Make codebases 'AI-native' with plain-text/markdown files explaining how agents should work in each area.
- Used AI to land the Meta PM job: built a Claude 'coach' project fed with Ben Erez's frameworks for mock interviews and brutal feedback; built a Base44 segmentation quiz game played on the bus; used Comet/Perplexity to analyze Lewis Lin's question bank to prioritize prep, but says the biggest game-changer was cold-outreaching humans on LinkedIn for live mocks. AI mocks only take you so far.
- Counter to 'AI = slop / atrophy': you must OWN your outputs, saying 'sorry, AI built that' is your mistake, not the AI's. Slop is human error from not giving context (writing style, problem, guardrails). For juniors, AI lets you 'play at a higher level' and get reps. Cursor reportedly has a '/de-slop' command to clean output.

### Frameworks & mental models
- 7-step slash-command pipeline (create-issue -> exploration -> create-plan -> execute -> review -> peer-review -> update-docs)
- Multi-model peer review / 'dev lead' adjudication
- CTO-as-a-project (anti-sycophancy custom prompt)
- Gradual exposure-therapy ladder (GPT project -> Bolt/Lovable -> Cursor)
- AI-mistake post-mortem -> update tooling/docs loop
- /learning-opportunity (80/20 rule prompt)
- Growth mindset / 10x learner not 10x doer
- Models-as-people mental model (Claude=CTO, Codex=hoodie bug-fixer, Gemini=artsy scientist)

### Notable quotes
> “It's not that you will be replaced by AI, you'll be replaced by someone who's better at using AI than you.”

> “If people walk away thinking how amazing you are, you failed. If people walk away and open their computer and start building, you've succeeded.”

> “The expectation of me wasn't being a 10x PM, it was being a 10x learner. The second I understood that, my whole mindset shifted.”

> “The job of a PM isn't always having the right answers and being the smartest person in the room, it's harnessing anything that gets us to the right solution for users as fast as possible.”


---

<!-- slug: low-heart-rate-etiquette -->
## How to show up in any room with a low heart rate: Silicon Valley's missing etiquette playbook

**Sam Lessin** · 2026-01-15 · [▶ Watch](https://www.youtube.com/watch?v=KtKJ3A6DWTs)

> Sam Lessin's etiquette-as-trust playbook for founders, show up with a low heart rate and an abundance mindset, plus a spicy take that "AI companies" are a terrible seed bet.

**Topics:** etiquette, founder skills, trust building, ai investing, vibe coding

### Key lessons
- The unifying frame is 'show up in a room with a low heart rate' driven by an abundance (not scarcity) mindset: even when it truly is your one shot at the Kleiner Perkins party, act like there will be other opportunities so you don't come in as an Energizer Bunny and project the wrong vibe.
- Forgot-a-name rescue trick: introduce the person you DO know to make the unknown person volunteer their name, say 'Jessica, I want to introduce you...' and let it hang, so they fill in 'Hi, I'm Bob.' Lessin uses this constantly because of a clinical face/name blindness that runs in his family (and was part of his early draw to Facebook).
- Treat conversation like ping-pong: questions are great but cap them, six questions in a row feels like an inquisition/extraction; every give should come with a get. Greet with 'great to see you' instead of 'nice to meet you' so it works whether or not you've already met.
- Dress: fit beats brand and price (a well-fitting $20 shirt beats a misfitting $500 one; most people can't tell cost but can tell fit). Dress exactly one level up, skip the Rolex as a startup founder, and if unsure just ask the level of dress, asking signals confidence and humility.
- Dining mechanics: don't order the most expensive thing (investors notice even when they don't care), order middle-to-last so you can match the host's tone, BBs/Ds with your hands tells you bread-left/drinks-right, napkin in lap, knife blade pointing in. Tip 20% minimum / ~30% ceiling, the goal is for your tip to NOT be memorable.
- Email/scheduling etiquette is a hidden status language: who's in the To vs CC line and the ORDER signals who you think matters (assistant first, CEO fourth = you did it wrong). Skip Calendly as a default, if you're the less-senior/less-busy person, let them name times and you flex; if you must send a link, give real options. Lessin's anti-Calendly rant once drove most of Calendly's monthly growth.
- Effort-signaling matters as much as the act: eye contact, repeating names back, standing to shake hands, sending a short thank-you note, and clean-up-after-yourself moves (his partner Kevin Collard maniacally asks where to put a coffee cup with LPs even though staff will clear it). Respecting EAs/PAs/servers is the #1 way to avoid looking classless.
- Contrarian AI take: disciplined seed investors should run from companies branded 'the AI for X', they're too capital-intensive (even OpenAI at a ~$500B cap only returned ~25x to seed, a middling outcome) and commoditizing. Use AI to supercharge a real business; don't BE an AI business. Lessin instead backs 'implications of AI' plays (Sublime Security, Outtake, JuneDating using ChatGPT histories as match data).

### Frameworks & mental models
- Low heart rate (show up calm, regulated, in control)
- Abundance vs scarcity mindset
- Conversation as ping-pong / give-to-get
- Signaling the effort matters as much as the act
- Dress one level up; fit over brand
- Small talk as TCP/IP handshake (modem-crash to sync wavelengths)
- Use AI as a propellant, don't be an 'AI company' (Teranova/frontier narrative critique)

### Notable quotes
> “Etiquette is a skill for how to show up in a room with a low heart rate.”

> “You kind of want to show up with the self-confidence and the calm of abundance. This is not your one shot, you'll have other opportunities.”

> “Build a relationship, not collect business cards. Understand how to give more than you take.”

> “I'd run away from things that are AI companies. Even if you look smart for the moment, you're playing a dangerous game of getting out before the narrative collapses.”


---

<!-- slug: aishwarya-naresh-reganti-kiriti-badam -->
## Why most AI products fail: Lessons from 50+ AI deployments at OpenAI, Google & Amazon

**Aishwarya Naresh Reganti + Kiriti Badam** · 2026-01-11 · [▶ Watch](https://www.youtube.com/watch?v=z7T1pCxgvlA)

> Two AI builders behind 50+ enterprise deployments on why agents fail: start low-agency/high-control, climb deliberately, and calibrate behavior continuously.

**Topics:** ai agents, ai product development, evals, enterprise ai adoption, human-in-the-loop, ai reliability

### Key lessons
- The two ways AI products fundamentally differ from software: (1) non-determinism on BOTH input (natural-language interface, infinite ways users phrase intent) and output (probabilistic black-box LLM), and (2) the agency-control trade-off: every unit of autonomy you hand an agent is a unit of control you give up, so the agent must earn trust before you cede it.
- Climb the agency ladder deliberately, never start at V3. Concrete progression for customer support: V1 = route/classify tickets only (humans can undo); V2 = Copilot suggesting drafts against SOPs that humans edit; V3 = end-to-end resolution that can issue refunds and file feature requests. Same for coding (inline completions -> larger refactors for review -> autonomous PRs) and marketing (draft copy -> build campaign -> auto-launch A/B-optimized campaigns).
- The CCCD framework (Continuous Calibration / Continuous Development, an explicit nod to CI/CD): right loop = scope capability, curate an expected-input/output dataset, set eval metrics, deploy; left loop = analyze production behavior, spot error patterns, fix or design new metrics. Crucial insight: eval metrics only catch errors you already anticipated; production monitoring + human-in-the-loop logging surface EMERGENT patterns you never imagined.
- Human-in-the-loop isn't just a safety net, it gives you 'error analysis for free.' Logging what the human accepts, edits, or omits from an AI draft builds the flywheel data to improve the system, while keeping a human accountable so customer trust is never eroded.
- Reliability is the #1 enterprise blocker: a UC Berkeley / Matei Zaharia / Databricks study found ~74-75% of enterprises cited reliability as their biggest problem, which is why most deployed AI today is low-autonomy productivity tooling rather than end-to-end workflow replacement.
- 'One-click agents' are pure marketing. Replacing a critical workflow or getting meaningful ROI realistically takes 4-6 months even with the best data and infra, because enterprise data is messy (e.g. duplicated functions, broken hierarchical taxonomies where a 'dead node' last updated in 2019 still routes tickets). Buy the team that builds you a learning pipeline + flywheel, not a turnkey agent.
- Evals are a victim of 'semantic diffusion' (Martin Fowler's term): the word now means everything from a lawyer jotting error-analysis notes, to PMs writing PRD-like specs, to LLM judges, to checking LMArena benchmarks (which is just MODEL evals, not product evals). Codex itself uses a balanced approach: evals to protect core behavior + heavy customer-signal watching (A/B tests, users switching off the code-review product) + 'vibes' where each engineer stress-tests new models on their own hard problems.
- Watch for implicit signals, not just explicit feedback: a user regenerating a ChatGPT answer (rather than clicking thumbs-down) is a clear signal the first answer failed. Know when to STOP climbing: when daily calibration stops surfacing new data distributions, you're 'minimizing surprise' and ready for more agency, but a model swap (4o -> 5) or evolving user behavior (underwriters throwing whole 30-40pg docs in and asking 'what did previous underwriters do?') resets calibration and forces you back.

### Frameworks & mental models
- Agency-Control trade-off (more autonomy = less control; agent must earn trust)
- Agency ladder / start-small versioning (V1 high-control-low-agency -> V3 autonomous)
- CCCD - Continuous Calibration / Continuous Development (ode to CI/CD)
- Problem-first approach (obsess over the problem, AI is just a tool)
- Success triangle: great leaders + good culture + technical prowess
- Semantic diffusion (Martin Fowler) applied to 'evals' and 'agents'

### Notable quotes
> “Every time you hand over decision-making capabilities or autonomy to agentic systems, you're relinquishing some amount of control on your end... you want to make sure the agent has earned that ability or built up trust over time.”

> “If someone's selling you one-click agents, it's pure marketing. I'd rather go with a company that says 'we're going to build this pipeline for you' that learns over time and builds a flywheel.”

> “Pain is the new moat... successful companies are successful not because they're first to market, but because they went through the pain of understanding the non-negotiables. That pain is what translates into the moat.”

> “Evaluation metrics catch only the errors that you're already aware of, but there can be a lot of emerging patterns you understand only after you put things in production.”


---

<!-- slug: molly-graham -->
## "I like being scared": Molly Graham's frameworks for rapid career growth

**Molly Graham** · 2026-01-04 · [▶ Watch](https://www.youtube.com/watch?v=twzLDx9iers)

> A high-growth handbook for leaders: give away your Legos, jump off career cliffs (J-curve), snorkel before you scuba, and serve the business not the people.

**Topics:** leadership, career growth, scaling, org design, okrs, culture

### Key lessons
- Give away your Legos: in a fast-scaling company the pile of work only grows, so cling to what you've mastered and you get buried under it. At peak Facebook she was 'giving away my job every three weeks' and constantly rehiring herself. The territorial/fearful emotions when handing off work are inevitable but normal-and-not-useful.
- Name your monster 'Bob': externalize the change-related emotions (rage emails at 9pm, imposter dread) as a character whose job is to make you the worst version of yourself. Let Bob rant but don't act. Rule of thumb from Facebook: any feeling that's still there after two weeks is real signal worth raising with a manager/coach; everything shorter is just Bob waves.
- J-curve vs stairs (from Chamath, who whiteboarded it): stairs = safe promotion every ~2 years and boring; jumping off a cliff = ~6-9 months of falling then climbing far past where stairs could reach. Her own example: leaving HR for Chamath's failed Facebook phone, getting her lowest-ever performance rating, then becoming a mobile expert. The phone failed for Facebook but not for her.
- Distinguish fear types: financial fear is real signal you should listen to (do the runway/burn-rate math, find your concrete number like '5-10K/month from consulting' - 'specific financial anxiety is more useful than existential'). But 'I'm scared I can't do this' is a flashing GREEN light - go prove to YOURSELF you can. The goal is self-knowledge, not impressing others.
- Waterline model (from NOLS wilderness training): a team is a boat; diagnose problems top-down across four layers - structural (goals/roles/expectations), dynamics (how the team works/decides), interpersonal (two people), intrapersonal (within one person). 'Snorkel before you scuba' - 80% of team problems are structural/dynamics, but people wrongly jump straight to blaming individuals. A manager's one job if nothing else: clear roles and clear expectations.
- Six rules for goals (anti-OKR; goals are a communication tool): (1) no company needs more than 3 company goals - Facebook ran on growth/MAU, engagement, revenue for 5 years; (2) one goal must win in a fight (engagement beat raw MAU - you could buy bots in Indonesia but that's the wrong number); (3) explain-it-like-I'm-5: a Monday intern should understand them; (4) 'strategy should hurt' (Claire Hughes Johnson) - make painful trade-offs explicit; (5) one goal, one owner ('two people owning a goal is no one owning a goal'); (6) goals alone aren't enough - 'winners and losers have the same goal' (James Clear), build follow-up/accountability process.
- Leadership-through-change rules of thumb: your job isn't to have answers, it's to get good at finding them ('I don't know, let's go figure it out'). Don't promise things you can't control (titles, stability, no-layering) - Claire Hughes Johnson: 'promises like that are letter bombs you mail yourself that explode in a year.' Get as good at firing as hiring (even the best are right ~50% of the time; bad fits become 'barnacles on a ship'). Serve the business, not the people - and 'direct is kind.'
- On founders and culture: ~80% of a company's culture is defined by the founder's personality (Facebook = Mark, a '19-year-old hacker's dorm room'; Google = a 'two PhD students' paradise'). You cannot impose values that contradict the founder - it just creates cultural dissonance. Founder mode = build a company that decides the way the founder would when not in the room. Plus: escalation is a TOOL not tattling (go up TOGETHER when neither party has the power/context), invest in high performers (run small experiments to expand their box) not low performers, and head-count growth above 100%/year is a trap ('50% is the happiest growth rate, 100% is manageable') because you grow too fast to de-dupe duplicate roles.

### Frameworks & mental models
- Give Away Your Legos
- Bob the Monster (two-week rule)
- J-Curve vs Stairs career growth
- Waterline Model (snorkel before you scuba)
- Six Rules for Goals & Alignment
- Founder mode / culture is the founder's personality
- Escalation as a tool (go up together)
- Serve the business, not the people
- 50/100% head-count growth rule
- Proving phase / 'what does this get you that you don't already have?'

### Notable quotes
> “I've made every single mistake in the book. And then I got to the end of the book and I started inventing new mistakes.”

> “Two people owning a goal is no one owning a goal.”

> “Promises like that are letter bombs that you mail yourself that are going to explode in your face in a year.”

> “Facebook felt like a 19-year-old hacker's dorm room. Google was designed to basically be a two PhD students' paradise. 80% of the culture of a company is literally defined by the personality of the founder.”


---

<!-- slug: jason-m-lemkin -->
## We replaced our sales team with 20 AI agents, here's what happened next | Jason Lemkin (SaaStr)

**Jason M. Lemkin (founder of SaaStr; former CEO/co-founder of EchoSign, later Adobe Sign)** · 2026-01-01 · [▶ Watch](https://www.youtube.com/watch?v=I-R1bc1rlFs)

> A tactical masterclass on building a B2B sales team from first rep to scale, hiring, comp, VP-of-sales, and the product-vs-sales tension. (Despite the title, no AI agents.)

**Topics:** sales hiring, gtm, plg vs sales-led, pricing, product-sales alignment, saas metrics

### Key lessons
- Founders must personally close the first ~10 customers before hiring sales; even sales-averse founders are 'A+ middlers' (great at the middle of a deal) and customers love talking to the CEO, they just need to learn to always ask for a next step. Hire reps once >20% of your time is consumed by sales calls (Lemkin's rule: a CEO should spend ~20% on sales and ~20% on recruiting).
- Hire TWO first reps (not one) so you can A/B test humans. Interview ~30 reps, ~20 break your brain with zero prep, ~8 are mediocre, and 1-2 are 'magicians.' The single cheat code: hire the rep YOU would buy your own product from, ignoring impressive LinkedIn logos. Leads are too precious to waste on the wrong person; his first EchoSign rep was living in his brother's garage but was the only one who could actually explain and sell the product.
- Do NOT hire a VP of Sales until you have two reps consistently hitting quota, hiring earlier asks one person to find product-market fit, be rep one, be rep two, AND scale, all at once; it's ~100% chance of failure and ~$2M of a $4M raise will burn. The VP should be a 'stretch' (previously a director/senior director), and in today's market must still carry a bag, if they only want to manage and won't visit customers, run.
- His #1 screening question for any VP (sales OR product): 'What do you want to do your first 14 days?' If the answer isn't 'meet 20 customers' and is instead 'process, Salesforce setup, territory planning,' don't hire them, too many burnt-out veterans 'don't want to sell/meet customers anymore.'
- Comp math: ~50/50 base/bonus, pay market (~$140-150K OTE example = only ~$6K/month base cash for a few months, a ~$20K bet). Reps should ultimately bring in 3x (SMB) to 5x (enterprise) their take-home, but don't demand it in quarter one. Let new reps keep ~100% of what they close for ONE quarter max to ramp them, then revert. Don't be sad when a great rep out-earns the founders, it means the model works (Pipedrive example: rep called self-serve accounts with multiple seats, e.g. AOL went from 20 to 100 seats).
- Hire reps whose LAST product was HARDER to sell, they'll feel like 'weight released from their feet.' Heuristics for 'harder': more technical (B2D/selling to VP Eng), more competitive (someone who did well at the #4 player coming to your #2), or a more complex business-process sale. Sam Blond went from selling cloud financials (Intacct), which nobody trusted in the cloud, to EchoSign and was instantly #1.
- Manage the product-vs-sales feature-request tension with a fixed quarterly BUDGET for sales (e.g. 10% of story points / pie chart). Sales owns that budget and force-ranks within it; changing mid-quarter is allowed but costly and the cost is made explicit. Tension between product and sales is HEALTHY ('if there's no stress, you're not in enough deals'). Push individual rep requests UP to manager-to-manager, never let a junior IC negotiate the roadmap with a mid-level PM directly. Org scaling follows 'rules of eight' (8 SDRs/manager, 8 AEs/director, etc.).
- Be customer-centric on monetization or you kill compounding: offer the longest customer-centric free trial (14-day trials exist only because Salesforce reps wanted to close same-month, not because it helps customers); avoid forcing annual contracts on SMBs ('terrible advice from people who never built products'); don't 'weaponize' customer success or product into revenue-extraction (one beloved vendor demanded $50K from a $299/mo customer, destroying trust). Appoint a 'VP of Free' to champion the non-converting long tail. And only raise prices if you 'earned it' with real new value.

### Frameworks & mental models
- A+ Middlers (founders are great at the middle of a sale, weak at open/close)
- The 'would I buy from them?' rep-hiring test
- Sell-me-this-pen / 'sell me this app' interview demo
- Rules of Eight (sales org scaling: 8 reports per manager)
- Quarterly feature-request budget for sales (story points / % of roadmap)
- Hire from a harder-to-sell product (the 'weight off your feet' heuristic)
- The Columbo question ('what will you do your first 14 days?')
- VP of Free (champion for the non-converting long tail)
- 3x-5x rule (reps must bring in 3-5x their take-home)
- Compounding / churn-first thinking (top-decile churn or pass)

### Notable quotes
> “You need that quirky pyromaniac that loves your product and can sell it. Forget about what's on their LinkedIn, I would buy from Lenny.”

> “Anytime an employee fails, it's your fault. You hired them. They never knew what they were getting themselves into. Be kind.”

> “It's not hires, it's mishires, probably the single most important thing in scaling startups.”

> “Going to annual contracts on a spreadsheet looks great. You know what's better? Letting customers pay what they want to pay.”


---

<!-- slug: matt-macinnis -->
## "I deliberately understaff every project" | Leadership lessons from Rippling's $16B journey

**Matt MacInnis** · 2025-12-28 · [▶ Watch](https://www.youtube.com/watch?v=O_W76LR77Vw)

> Rippling's CPO on deliberate understaffing, alpha/beta hiring, entropy as the enemy, and why owning first-party data is the only AI moat.

**Topics:** leadership, hiring, product management, ai strategy, product market fit, startups

### Key lessons
- Deliberately understaff every project. Since you can never get staffing exactly right, decide which error to make: overstaffing breeds politics and work on low-priority items (poison/cruft), so always err toward under-staffing, the wisdom is in not under-under-staffing. Keep teams 'dehydrated' so they always want more.
- Use the alpha/beta framework from finance to design teams and process. Alpha = outperformance, beta = volatility. 0-to-1 products want high-alpha people; mature products (Rippling payroll) want low beta. Process exists solely to lower beta, but it suppresses alpha, so apply it surgically only where you don't want surprises.
- Build a 'vessel for meaning' to drive culture change at scale (1,300 R&D people). The Product Quality List (PQL, pronounced 'pickle') is a deliberately quirky, lightweight checklist run as a 'factory inspection' before ship, including the new rule 'one feature flag governs your whole product at ship,' added after Parker hit a blank screen from a forgotten feature flag.
- Fight entropy with relentless energy. Teams always optimize for local comfort over company outcomes; each management layer below the founder-CEO risks an order-of-magnitude drop in intensity. A leader's job is to MIRROR the CEO's intensity, not buffer people from it, call out every bug publicly, every time, in public channels.
- Quit sooner, 'try until you die' is VC propaganda. VCs are incentivized to keep you grinding because their downside is fixed at zero. If you've pivoted once or twice and it's not catching by year 4-5, it's time to reset the cap table. Good seed investors forecast every bet to zero and want your second/third company.
- Product-market fit is binding receptors, not marketing. Like drug discovery, the market is immutable, your launch is a thimble in an ocean of noise. You can't market your way to receptors that don't exist; fate has already decided. If you don't unmistakably know you have PMF, you don't have it.
- AI strategy: own the mine or sell the shovels. Sell shovels (OpenAI/Gemini) or own the data mine (Rippling), being in the middle (renting shovels AND ore) gets your unit economics crushed. Point solutions lack the data context AI needs; integrating via flat-file SFTP is 'drinking through a straw.' This kills 80-90% of standalone AI businesses.
- Ask for relevant experience, not advice, people always give advice but rarely have real experience. In hiring, trust trained intuition then decode it via SPOTAC (smart, passionate, optimistic, tenacious, adaptable, kind), and give every PM (L5 to VP) the same impossible case study to see how many corners they see around and whether they get defensive.

### Frameworks & mental models
- Extraordinary results require extraordinary efforts (attr. Dan Gill)
- Deliberate understaffing
- Alpha / beta (high alpha, low beta)
- Process exists to lower beta
- PQL, Product Quality List / 'factory inspection'
- Compounding + power law + entropy
- SPOTAC hiring rubric
- Binding-receptors / drug-discovery model of PMF
- Narrative violations (attr. Jeff Lewis)
- Own the mine vs. sell the shovels (AI)
- Bundling vs. unbundling
- Ask for relevant experience, not advice
- Conway's Law

### Notable quotes
> “The most selfish thing you can do is withhold feedback from someone... you're optimizing for your own comfort, and it's fundamentally selfish.”

> “Good teams get tired, and that's when great teams kick the good team's asses.”

> “We talk in Silicon Valley about never quit, but that is complete absolute venture capital bullshit... you should fucking quit. Reset the clock, reset the cap table.”

> “If you're selling the shovels you can make money, and if you own the mine you can make money. If you're somewhere in the middle... you're in a very difficult place.”


---

<!-- slug: sander-schulhoff -->
## Why securing AI is harder than anyone expected and guardrails are failing | HackAPrompt CEO

**Sander Schulhoff** · 2025-12-21 · [▶ Watch](https://www.youtube.com/watch?v=J9982NLmTXg)

> The CEO of HackAPrompt argues AI guardrails fundamentally don't work, and that the real defense is permissioning, education, and frontier-grade AI security expertise.

**Topics:** ai security, ai agents, prompt injection, guardrails, ai governance, enterprise ai

### Key lessons
- Guardrails do not work, full stop. The attack space for a model like GPT-5 is ~1 followed by a million zeros possible prompts, so a vendor's '99% caught' claim is statistically meaningless, basically infinite attacks remain. They also don't dissuade determined attackers and create false confidence in your security posture.
- The only valid way to measure adversarial robustness is adaptive evaluation (attackers that learn over time), not static datasets. In a joint paper with OpenAI, Google DeepMind, and Anthropic, human attackers broke 100% of state-of-the-art defenses in 10-30 attempts; automated systems needed orders of magnitude more tries and only succeeded ~90% of the time. Humans are still the best attackers.
- 'You can patch a bug, but you can't patch a brain.' Classical software bugs can be patched to 99.99% confidence; with an AI model you can be 99.99% sure the vulnerability is STILL there. AI security is fundamentally unlike classical cybersecurity.
- The real defense is at the permissioning/cybersecurity intersection, not guardrails. Frame every agent as 'an angry malicious God in a box' (the AI safety 'control' field), then lock down data access and actions: any data the AI can access, a user can make it leak; any action it can take, a user can make it take in any order.
- CaMeL (a framework out of Google) is the most promising practical defense: it inspects the user's request up front and restricts the agent to only the permissions that request needs (e.g. read-only if the user just asked for a summary), so a malicious injected email telling it to forward data can't execute. Limitation: when a task legitimately needs both read AND write (e.g. 'read my emails and forward ops requests'), CaMeL can't help. Sander called 'plug-and-play CaMeL' an obvious market opportunity.
- Attacking agents is now EASIER than CBRN elicitation. CBRN is more solvable because you can train the model to 'never' do something; agent actions require 'sometimes do this, sometimes don't' (send emails, except when something's weird), which is far harder to draw a line on. Indirect prompt injection (external web/email content attacking agents) remains very unsolved.
- Sander predicts a market correction in AI security within 6-12 months: guardrail/automated-red-teaming companies have little real revenue, are being acquired by classical security firms anyway, and many free open-source tools outperform paid products. Real-world agent harms (financial loss, data leaks, eventual physical injury via LLM robots) will start appearing within a year.
- For most chatbot deployments (FAQ, doc Q&A, read-only) you should do NOTHING for prompt-injection defense, worst case is reputational harm a user could replicate on ChatGPT anyway. Just verify it's truly 'only a chatbot,' log all inputs/outputs for monitoring, and get classical data/action permissioning right.

### Frameworks & mental models
- CaMeL (Google), pre-restrict agent permissions to only what the user's request requires
- Adaptive evaluation / ASR (Attack Success Rate) for measuring adversarial robustness
- 'God in a box' / AI control framing, assume the AI is malicious and contain it
- 'Patch a bug vs. patch a brain' mental model for AI vs. classical security
- CBRNE threat taxonomy (chemical, biological, radiological, nuclear, explosives)
- Cybersecurity + AI-security intersection as the durable security career path

### Notable quotes
> “You can patch a bug, but you can't patch a brain.”

> “When these guardrail providers say 'we catch everything,' that's a complete lie. 99% of one followed by a million zeros, there's still basically infinite attacks left.”

> “Not only do you have a God in the box, but that God is angry, that God is malicious, that God wants to hurt you. Can we control that malicious AI and make it useful to us?”

> “We actually want to scare people into not buying stuff.”


---

<!-- slug: elena-verna -->
## The new AI growth playbook for 2026 | How Lovable hit $200M ARR in one year

**Elena Verna** · 2025-12-18 · [▶ Watch](https://www.youtube.com/watch?v=6qAB6aUMIeA)

> Lovable's head of growth on why only 30-40% of the classic growth playbook survives AI: spend 95% on innovation, give the product away, and recapture PMF every 3 months.

**Topics:** growth, ai products, product-market fit, pricing, gtm, hiring

### Key lessons
- Lovable hit $200M ARR in under a year (8mo to $100M, then 4mo to $200M), with 8M+ users and only ~100 employees (30 just six months prior). Verna says only 30-40% of her 15-20 years of growth playbook transfers; she now spends 95% of time innovating on growth vs 5% optimizing (the inverse of her past roles).
- Growth team builds core features, not funnel optimizations: they shipped the Shopify integration (e-commerce storefronts) and voice mode, and are now writing agentic workflows / agent instructions to improve activation. They spend almost zero time on activation because the core 'agent team' is obsessed with making the first generation better.
- Deliberately do NOT optimize for revenue. North Star is engagement retention, not paid retention; revenue is treated as an output of getting more people through the door. They actively discuss how to 'reduce revenue growth rate' by giving more away to grab market share. Paid retention is on par with B2B SaaS benchmarks (Miro, Dropbox, etc.); NDR is strong because builders buy more credits.
- Give the product away as the growth secret sauce: free credits to every hackathon/event, sponsoring anyone who wants to run a Lovable hackathon. They book free credits and freemium LLM cost as MARKETING spend, not a cost center to cut. Logic: someone running a hackathon does your marketing/activating for free, and it's a lower cost-per-eyeball than competing on Google AdWords. AI margins sit ~40%, not 80-90%, so the script must flip from gating AI to exposing it.
- Build-in-public + founder/employee socials is a top organic channel. 'Velocity of shipping' is the #1 dev core value, shipping multiple times/day to keep 'noise in the market' so users log into X/LinkedIn to see 'what did Lovable ship now' (works as resurrection + reengagement). Organic has shifted from SEO/search to social even for B2B. Influencer marketing is 10x bigger than paid social for them because 10 seconds of video shows what vibe coding can do.
- PMF is now a treadmill: every ~3 months you must recapture product-market fit because BOTH sides shift fast: each new LLM release step-changes capability (you must build ahead of the model so the feature is ready when the model lands), AND consumer expectations now change in weeks ('it's not doing this yet, I'm bouncing'). Cited OpenAI's 'code red' losing ~6% share in a week to Gemini 3 as proof no one is bulletproof. Worry: so focused on recapturing 'pioneers' that they can't serve the 'latent majority' / adjacent users (Bangaly's adjacent user theory).
- Hiring shift: best talent = passion/'fire in the belly' + high agency + high autonomy over big logos; screen for people who convert chaos into clarity (don't need clarity given to them). Use paid multi-day work trials + probation. Ex-founders (even failed) and AI-native new grads are now the hottest, highest-paid hires. New role observed: full-time 'vibe coder' (his came from a chief-of-staff, non-technical background).
- Minimum Lovable Product replaces MVP ('viability left back in the 2010s'). Aha moment is now just a 'wow moment' (Lovable's first preview generation after the first prompt). Feedback cycle collapsed from weeks of research/design/build to idea-to-feedback in a day. Workflow at Lovable: every spec ships with a Lovable prototype; PMs recreate pages via screenshot-to-Lovable to hand engineers exactly what they want; heavy use of ChatGPT deep-thinking for brainstorm, Granola for meetings, Wispr Flow for voice.

### Frameworks & mental models
- Minimum Lovable Product (MLP) - replaces MVP
- Wow moment (replaces aha moment)
- PMF treadmill / recapturing PMF every 3 months
- John Cutler's capabilities -> value -> scaling stages of software
- Bangaly Kaba's Adjacent User Theory
- Lenny's race car growth model (engine + turbo boosts)
- Net Dollar Retention (NDR >100%) as investor superpower
- Build-in-public + founder-led socials

### Notable quotes
> “I usually spend maybe 5% innovating on growth in my previous roles; right now I'm spending 95% innovating on growth, and only 5% on optimization. To be ahead of them is not optimization of the problem, it's reinvention of the solution.”

> “We don't optimize for revenue at all. In fact, internally we have a lot of discussions about how can we give more products away, how can we reduce our revenue growth rate by just getting more paid subscribers.”

> “Every three months, I feel like we have to recapture our product-market fit... it's terrifying. Nobody's future is bulletproof yet.”

> “It shouldn't be minimum viable product anymore. Viability is left back in the 2010s. Now it's minimum lovable product.”


---

<!-- slug: inside-openai-2026-agents -->
## Inside OpenAI: 2026 is the year of agents, AI's biggest bottleneck, and why compute isn't the issue

**Alexander Embiricos** · 2025-12-14 · [▶ Watch](https://www.youtube.com/watch?v=z1ISq9Ty4Cg)

> OpenAI's Codex product lead on 20x growth, why the real AGI bottleneck is human review/typing speed, and building agents that augment without overwhelming.

**Topics:** ai agents, coding agents, product management, agent ux, human-in-the-loop, openai

### Key lessons
- Codex grew 20x since the GPT-5 launch in August (publicly cited as 10x before this) and now serves many trillions of tokens/week, making it OpenAI's most-served coding model both in their first-party harness AND in the API.
- The original cloud-first Codex was 'too far in the future', it required environment config and async-only prompting. The growth unlock came from retreating to the more intuitive on-ramp: an IDE/VS Code extension and CLI that pairs interactively inside a secure sandbox, then converting that feedback loop into config so users can later delegate. Lesson: live in the future, but not TOO far ahead of your market.
- An 'agent' is a 3-layer stack, model + API + harness, and features must be built across all three. Their 'compaction' feature (lets Codex run 24h+ past its context window) required the model to understand compaction, an API endpoint to trigger it, and a harness to prepare the payload.
- Codex uses ONLY the shell/terminal (not semantic search or bespoke tools) made safe via a sandbox. Optimizing for one harness world lets you train and iterate much faster than supporting every coding-tool opinion.
- The new bottleneck has shifted from writing code (the fun part) to reviewing AI-written code (the unfun part). So the team's focus moved to code-review features, agents validating their own work, and UX choices like showing the image/preview BEFORE the diff to keep humans 'maximally accelerated.'
- Concrete velocity proof: the Sora Android app, built in 18 days to internal employees, then GA 10 days later (28 days total) by ~2-3 engineers, became the #1 app in the App Store, largely by having Codex port the existing iOS app. Atlas browser work that used to take 2-3 engineers 2-3 weeks now takes 1 engineer 1 week.
- 'If you want to build any agent, maybe you should build a coding agent', because the best way for models to use a computer is to write code, and code is composable/importable. Coding is framed as a core competency of any future agent, including ChatGPT.
- The team is unusually 'social-media pilled': a few PMs constantly monitor r/Codex, Reddit, and Twitter for complaints (Reddit = more negative but real, with good upvote signal; Twitter = hypier). They also obsess over D7 retention and repeatedly sign up from scratch (multiple paid Pro accounts) to dogfood the cold-start experience.

### Frameworks & mental models
- Ready-fire-aim (vs ready-aim-fire) with fuzzy long-horizon aiming
- Agent stack: model + API + harness
- Compressing the talent stack (Scott Belsky), blurring PM/design/eng boundaries
- Mixed-initiative / contextual-action UX (video-game 'press X to do the right thing')
- Be kind and candid (candor as an act of kindness)
- Maximally accelerated (Nick Turley's mantra)
- Spec-driven / plan-driven development vs 'chatter-driven development'

### Notable quotes
> “The current underappreciated limiting factor is literally human typing speed or human multitasking speed.”

> “It's a bit like this really smart intern that refuses to read Slack and doesn't check DataDog or Sentry unless you ask it to.”

> “It turns out the best way for models to use computers is simply to write code. So if you want to build any agent, maybe you should be building a coding agent.”

> “The best way to try Codex is to give it your hardest tasks, we're building it to be the professional tool you give your hardest problems to.”


---

<!-- slug: edwin-chen -->
## The $1B AI company training ChatGPT, Claude & Gemini on the path to responsible AGI | Edwin Chen

**Edwin Chen** · 2025-12-07 · [▶ Watch](https://www.youtube.com/watch?v=dduQeaqmpnI)

> Surge AI's bootstrapped founder on data quality, why benchmarks lie, RL environments, and how labs are optimizing AI for "slop" over truth.

**Topics:** ai data labeling, rl environments, model evals, ai alignment, bootstrapping, founder strategy

### Key lessons
- Surge hit >$1B revenue in under 4 years with fewer than 100 people, fully bootstrapped (no VC) and profitable from day one, Chen's thesis is that AI efficiency makes tiny elite teams the future, predicting '$100B per employee' ratios; he believes you could 'fire 90% of people' at big tech and move faster.
- Data quality is not 'throwing bodies at the problem.' For an 8-line moon poem, low-quality grading just checks 'Is it a poem? 8 lines? Contains "moon"?', Surge instead grades for subtlety, imagery, emotional impact (Nobel-tier). They capture thousands of signals per worker/task (keystrokes, response speed, reviews, code standards) and train models on the outputs to see which actually improve the model, like Google Search ranking pages: remove worst-of-worst AND surface best-of-best.
- Benchmarks are untrustworthy for two reasons: (1) many contain outright wrong answers and hidden flaws even researchers don't catch; (2) they have clean objective answers models can 'hill-climb,' unlike the messy real world, which is why models win IMO gold medals but still fail to parse PDFs.
- Public leaderboards like LMArena actively steer models in the wrong direction: voters skim for 2 seconds and pick the flashiest answer, so the easiest way to climb is adding emojis, bolding, and tripling response length, even when the model hallucinates and gets the answer wrong. Labs chase it anyway because enterprise buyers ask 'why are you only #5 on LMArena?' and researchers say 'the only way I get promoted is to climb the leaderboard,' even knowing it makes the model worse.
- Surge measures real progress via deep human evals: domain experts (Nobel-tier physicists, working engineers, teachers) hold real conversations with models and verify the code, double-check the physics equations, and grade for accuracy/instruction-following, the opposite of casual users 'just vibing' on a ChatGPT A/B popup.
- RL environments are the new frontier: build a video-game-like simulation of a real company (Gmail, Slack, Jira, GitHub PRs, a codebase), then break it (AWS goes down, Slack goes down) and reward the model for fixing it. These reveal models that ace single-step benchmarks but 'fail catastrophically' on long-horizon, messy, multi-tool tasks where step 1 affects step 50. Watch the trajectory, not just the final answer, models often reward-hack or stumble to the right answer after 50 failed tries.
- Chen's post-training evolution map via human-learning analogies: SFT (supervised fine-tuning) = mimicking a master; RLHF = writing 55 essays and someone picking the best; rubrics/verifiers = being graded with detailed feedback; RL environments = the new stage that complements rather than replaces the others.
- Models will DIFFERENTIATE, not commoditize, driven by each lab's values/objective function. Chen's example: Claude spent 30 minutes and 30 versions perfecting an email that didn't matter; the real product question is whether you want a model that says 'you're absolutely right, 20 more improvements' (engagement) or one that says 'stop, it's great, send it' (your productivity). He singles out Anthropic as the most 'principled' lab.

### Frameworks & mental models
- Worst-of-worst / best-of-best data quality (Google Search ranking analogy)
- Post-training learning ladder: SFT -> RLHF -> rubrics/verifiers -> RL environments
- Trajectory-based reward (grade the path, not just the final answer)
- Dream objective function / 'you are your objective function' (raising a child, not labeling data)
- Build the one company only you could build (anti-pivot, anti-blitzscale, anti-hype)
- RL environment as simulated company world (Gmail/Slack/Jira + injected failures)

### Notable quotes
> “We're basically teaching our models to chase dopamine instead of truth. We're optimizing your models for the types of people who buy tabloids at a grocery store.”

> “It's kind of crazy that these models can win IMO gold medals, but they still have trouble parsing PDFs.”

> “The only way I'm going to get promoted at the end of the year is if I climb this leaderboard, even though I know that climbing it is probably going to make my model worse.”

> “I always thought it was ridiculous... I always felt that we could fire 90% of people and we would move faster because the best people wouldn't have all these distractions.”
