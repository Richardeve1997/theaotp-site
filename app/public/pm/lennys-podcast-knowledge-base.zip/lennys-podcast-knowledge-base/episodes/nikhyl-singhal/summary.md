---
title: "Why half of product managers are in trouble | Nikhyl Singhal (Meta, Google)"
guest: "Nikhyl Singhal"
date: "2026-04-19"
youtube_url: "https://www.youtube.com/watch?v=yUohoaC8_Hs"
slug: "nikhyl-singhal"
tags: ["career", "product management", "ai agents", "hiring", "leadership", "vibe coding"]
---

# Why half of product managers are in trouble | Nikhyl Singhal (Meta, Google)

**Nikhyl Singhal** · 2026-04-19 · [▶ Watch](https://www.youtube.com/watch?v=yUohoaC8_Hs)

> The PM "information mover" is going extinct; builders with judgment are thriving. Cross the reinvention threshold now or become roadkill.

**Topics:** career, product management, ai agents, hiring, leadership, vibe coding

## Key lessons
- The PM split is binary: the 'information mover' (framing/reframing info up the chain, status reports, doc-shuffling) is becoming 'a dinosaur,' while 'builders' are having the time of their lives. Singhal estimates roughly half of current product people are information-movers who are now in trouble.
- Predicted hiring shape over the next 12-24 months: 'massive shedding then massive rehiring', e.g. a company sheds 30,000 and hires 8,000, but the 8,000 are all AI-first. Two drivers: companies feel they over-hired (doubled headcount in 5 years without 2x output) AND the new skill set is totally different.
- Counter-signal to the doom: Singhal's job-market report found the MOST open PM roles globally in 3+ years (last comparable peak was COVID). The role isn't dying, it's bifurcating. 'Builders wanted' is the tagline for the next couple of years.
- Logos/brands on a resume are now a liability, not an asset, if the company isn't AI-forward. Interviews have shifted from 'tell me what you shipped 5 years ago' to 'put you in a scenario, what tools do you use, what's your judgment, how do you think?' How MODERN you are beats pedigree.
- The 'shadow superpower' trap: people who mastered the OLD product game find reinvention HARDEST, because the old system still works for them so they have no incentive to change, while weaker performers eagerly adapt. Crossing the reinvention threshold is THE #1 piece of advice.
- Find your 'moment of joy' to beat burnout: nearly everyone who crosses over has a personal story of building something small (a chief-of-staff inbox app, a partner's business plan, controlling house lights) and 'catching the bug.' Joy is the biggest antidote to burnout. Audit your week green/yellow/red, info-movers show mostly yellow/red; builders show green/yellow.
- Singhal's personal operating rule (from a mentor's definition of a great engineer): 'an engineer is someone who obsoletes themselves from everything they do.' His whole AI stack is built around obsoleting his own recurring tasks, e.g. agents that match 125 community members for intros, agents that aggregate job openings into auto-matched mailing lists, AI trained on his content to draft answers he then edits.
- Roles will blur in all directions: 14 of his 125-head-of-product community are now founders (up from 1 a few years ago); one interviewed for a CHRO role because the company wanted a PM's 'obsolescence/judgment/builder' skills. Engineers are becoming 'more PM-y' as coding gets solved; designers and data scientists move into product. PMs become 'agents of change' spreading to every function and industry.

## Frameworks & mental models
- Information-mover vs. builder dichotomy
- Shadow superpower (old-game mastery blocks reinvention)
- Crossing the reinvention threshold
- Obsolete yourself (definition of a great engineer)
- Green/yellow/red meeting audit
- Equally disappoint everyone (power-years prioritization)
- The Skip (optimize for the move after the next move)
- Judgment as the irreducible PM skill

## Notable quotes
> “The information mover is essentially going to become a dinosaur.”

> “You might see a company shed 30,000 and hire 8,000, but the 8,000 are going to all be AI-first.”

> “The better you are at mastering one system, the less likely you are to recognize the new one.”

> “An engineer is someone who obsoletes themselves from everything they do.”
