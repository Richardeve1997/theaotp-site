---
title: "How Anthropic, Costco, and Patagonia all build incorruptible companies | Eric Ries"
guest: "Eric Ries"
date: "2026-05-10"
youtube_url: "https://www.youtube.com/watch?v=PoJ1vTdHpks"
slug: "eric-ries"
tags: ["governance", "founder control", "ai labs", "mission-driven companies", "leadership", "ipo"]
---

# How Anthropic, Costco, and Patagonia all build incorruptible companies | Eric Ries

**Eric Ries** · 2026-05-10 · [▶ Watch](https://www.youtube.com/watch?v=PoJ1vTdHpks)

> The Lean Startup author on "incorruptible" governance: pair ethos + structural integrity so success can't be used to oust you or rot your mission.

**Topics:** governance, founder control, ai labs, mission-driven companies, leadership, ipo

## Key lessons
- Statistically you are NOT the exception: per Harvard Law School, only ~20% of VC-backed founders are still CEO 3 years after IPO. Ries tells of a 'hot' founder who skipped mission-protective provisions on advisor advice, IPO'd successfully, then got ousted 5 months later when a competitor's acquisition tanked the category and stock.
- The 'any lawful act or activity' boilerplate charter most lawyers give you legally means 'maximize shareholder returns' under shareholder primacy (a doctrine only ~40 years old). It can create a fiduciary duty to sell to the highest bidder even if it's Philip Morris. Real case: Vectura, a UK inhaler/asthma company, was actually bought by Philip Morris (165p vs a 155p PE bid) over public outrage; PM took a ~$900M writedown within 3 years and sold it for parts.
- The fix is cheap and timing-bound: file as a Public Benefit Corporation (a two-page Delaware filing) and write a real purpose into the charter. Ries calls it the zero-tradeoff move. 'It is always too early until it's too late', once you've raised priced rounds and stacked VCs/bankers, you lose the leverage to do it.
- Run the 'adversarial prompt' test on your mission statement: spend an hour with your co-founder asking 'can we make money while violating this statement, and would we be happy or sad in that scenario?' If sad, encode it. Apply the same audit operationally ('mission drive'): is anyone's bonus/OKR set up so they could profit by betraying a principle? The first things cut are safety, performance, quality, design, then innovation.
- 'Harder is easier': trustworthiness lowers CAC, raises loyalty/retention, and cuts internal comms overhead. Cloudflare's engineer pushed 'wouldn't a better internet be an encrypted internet?'; Matthew Prince said 'let's figure it out' and gave away SSL for free. Free-to-premium conversion dropped, but top-of-funnel rose ~10x, a key reason it's now a ~$70B company. Counter-example: Groupon's 'one email a day' eroded to 8 emails when ROI experiments ground the founder down, destroying the brand.
- Anthropic is the marquee structural example: it was a PBC from inception and wrote the right to enact reforms into its charter, defending it ~2 years until implementing the Long-Term Benefit Trust at Series C. Today its for-profit board has directors appointed by/accountable to outside AI-safety trustees with NO equity, so refusing to ship a dangerous model or turning down a $200M Pentagon contract is structurally enabled, not just PR.
- Build a 'mission guardian' (person or entity) and a 'culture bank.' Ries' omnibus term is the 'spiritual holding company' (industrial foundation like Nova Nordisk, perpetual purpose trust like Patagonia, ESOP, etc.); academic evidence says foundation-owned firms are ~6x more likely to reach year 50. The Todd Park rule (via Howard Schultz): every values-defending sacrifice is a deposit; only make deposits, never intentional withdrawals.
- Three early-stage actions: (1) convert to a PBC and write a purpose you'd feel good about; (2) add a 'director's oath' (a Hippocratic-style first-do-no-harm clause) to the charter as a precondition of any board seat, directly relevant amid the Anthropic/Figma AI-board-member fights; (3) if you hold founders-preferred shares, use mission-protected provisions / an Anthropic-style LTBT pledge (e.g. write into the charter that 10% equity + 1% future revenue goes to a future foundation, 'fire and forget').

## Frameworks & mental models
- Ethos + Integrity (the incorruptible formula)
- Harder is easier / the 'figure it out' principle
- Mission drive (vs. mission-hopeful), OKRs for fiduciaries
- The culture bank / Todd Park rule (only make deposits)
- Spiritual holding company (mission guardian: PBC, foundation, perpetual purpose trust, LTBT)
- The invisible leader (Mary Parker Follett) / Conway's Law alignment

## Notable quotes
> “The force that no one controls but everyone obeys that tends to drag organizations down into mediocrity to the point that we lose control of them.”

> “The more golden the goose, the greater the temptation to butcher.”

> “Don't be evil was just a slogan. So if someone tells you 'I'm serious about something,' great, now show me the apparatus.”

> “It is always too early until it's too late. Success will not protect you, because success is what makes you a target.”
