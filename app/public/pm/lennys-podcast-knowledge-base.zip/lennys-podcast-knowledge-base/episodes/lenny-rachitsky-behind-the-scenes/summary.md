---
title: "A behind-the-scenes interview with Lenny Rachitsky on building his newsletter and podcast"
guest: "Lenny Rachitsky (interviewed by his wife, Michelle Rial)"
date: "2026-03-12"
youtube_url: "https://www.youtube.com/watch?v=HEqrvF7ztBE"
slug: "lenny-rachitsky-behind-the-scenes"
tags: ["creator economy", "newsletter growth", "product management", "founder mindset", "creativity", "personal story"]
---

# A behind-the-scenes interview with Lenny Rachitsky on building his newsletter and podcast

**Lenny Rachitsky (interviewed by his wife, Michelle Rial)** · 2026-03-12 · [▶ Watch](https://www.youtube.com/watch?v=HEqrvF7ztBE)

> Lenny gets personal: how he stumbled into a 1.2M-subscriber newsletter by "following the pull," plus stress, fraud rings, and a creative process.

**Topics:** creator economy, newsletter growth, product management, founder mindset, creativity, personal story

## Key lessons
- "Follow the pull" over the plan: when Lenny left Airbnb his Plans A-D were all start/join/advise a company; writing wasn't in the plan, but he doubled down on the side-project that he both enjoyed AND that people valued. Michelle had told him you can't make money writing on the internet.
- The 9-month + Lindy-effect milestone: after writing weekly for 9 months he reasoned via the Lindy effect (a thing lasts at least as long as it's already lasted) that he could keep going another year, which gave him the conviction to add the paywall. COVID tanking his Airbnb stock forced the monetization decision, and it made meaningful money within a month.
- Internal quality bar over external validation: both Lenny (newsletter posts) and Michelle (charts) know a piece is done when it makes THEM laugh, tear up, or feel something, not when others approve. Lenny: "It's very like not waiting for other people to give you approval or feedback."
- Best content comes from practitioners, not pontificators: most of Lenny's posts are now guest posts where someone shares the single best thing from their career; the source of best advice is "people on the ground doing the thing for real, not just floating in the clouds pontificating." Michelle's pre-kids children's book wasn't good; the post-kids one worked because of lived experience.
- Heavy iteration is the unglamorous engine: Lenny rewrites a newsletter post ~50 times before it goes to his editor, copy editor, and designer; Michelle estimates ~60-100 iterations per chart. "Spend more time on it" was advice from his old boss.
- His creativity recipe is specific and physical: a single-shot latte (not too much caffeine, referencing XKCD's "Ballmer Peak" applied to coffee), a ~2-hour deadline that makes him "feel like a machine," a good night's sleep, and time spent living life to gather raw material (cites David Sedaris saying yes to everything for material).
- Defining PM: Lenny's definition is "deliver business impact by prioritizing and solving the most impactful business problems"; he defends the PM-as-mini-CEO framing, the PM should channel "what would the CEO do on this specific product?" His PM-to-now transfer wasn't tactics but habits: organization, a very high bar for quality, and succinct communication.
- Deliberately staying small and avoiding self-built traps: Lenny tries hard to never have full-time employees to keep things simple; warns you can "create a job for yourself that you hate" by saying yes to things people want or things that feel big, be careful what you commit to. He also notes the downside of monetizing a passion (per Adam J.K. Finch's "How to Become an Artist").

## Frameworks & mental models
- Lindy effect (longevity predicts future longevity)
- Ikigai (enjoy it / good at it / people value it / can make money)
- Ballmer Peak (XKCD) applied to coffee
- Happiness baseline / hedonic adaptation (UPenn Science of Happiness)
- PM as mini-CEO
- Follow the pull

## Notable quotes
> “The visual I always have is the Indiana Jones boulder is chasing me constantly. It's like this treadmill you're on.”

> “How often do you enjoy something and people value it? ... that Venn diagram of things.”

> “The source of the best advice is from practitioners doing the thing for real, not just floating in the clouds pontificating.”

> “You can create a job for yourself that you hate by doing things that people want you to do or that feel big, and then you're like, 'I hate this.'”
