---
title: "We replaced our sales team with 20 AI agents, here's what happened next | Jason Lemkin (SaaStr)"
guest: "Jason M. Lemkin (founder of SaaStr; former CEO/co-founder of EchoSign, later Adobe Sign)"
date: "2026-01-01"
youtube_url: "https://www.youtube.com/watch?v=I-R1bc1rlFs"
slug: "jason-m-lemkin"
tags: ["sales hiring", "gtm", "plg vs sales-led", "pricing", "product-sales alignment", "saas metrics"]
---

# We replaced our sales team with 20 AI agents, here's what happened next | Jason Lemkin (SaaStr)

**Jason M. Lemkin (founder of SaaStr; former CEO/co-founder of EchoSign, later Adobe Sign)** · 2026-01-01 · [▶ Watch](https://www.youtube.com/watch?v=I-R1bc1rlFs)

> A tactical masterclass on building a B2B sales team from first rep to scale, hiring, comp, VP-of-sales, and the product-vs-sales tension. (Despite the title, no AI agents.)

**Topics:** sales hiring, gtm, plg vs sales-led, pricing, product-sales alignment, saas metrics

## Key lessons
- Founders must personally close the first ~10 customers before hiring sales; even sales-averse founders are 'A+ middlers' (great at the middle of a deal) and customers love talking to the CEO, they just need to learn to always ask for a next step. Hire reps once >20% of your time is consumed by sales calls (Lemkin's rule: a CEO should spend ~20% on sales and ~20% on recruiting).
- Hire TWO first reps (not one) so you can A/B test humans. Interview ~30 reps, ~20 break your brain with zero prep, ~8 are mediocre, and 1-2 are 'magicians.' The single cheat code: hire the rep YOU would buy your own product from, ignoring impressive LinkedIn logos. Leads are too precious to waste on the wrong person; his first EchoSign rep was living in his brother's garage but was the only one who could actually explain and sell the product.
- Do NOT hire a VP of Sales until you have two reps consistently hitting quota, hiring earlier asks one person to find product-market fit, be rep one, be rep two, AND scale, all at once; it's ~100% chance of failure and ~$2M of a $4M raise will burn. The VP should be a 'stretch' (previously a director/senior director), and in today's market must still carry a bag, if they only want to manage and won't visit customers, run.
- His #1 screening question for any VP (sales OR product): 'What do you want to do your first 14 days?' If the answer isn't 'meet 20 customers' and is instead 'process, Salesforce setup, territory planning,' don't hire them, too many burnt-out veterans 'don't want to sell/meet customers anymore.'
- Comp math: ~50/50 base/bonus, pay market (~$140-150K OTE example = only ~$6K/month base cash for a few months, a ~$20K bet). Reps should ultimately bring in 3x (SMB) to 5x (enterprise) their take-home, but don't demand it in quarter one. Let new reps keep ~100% of what they close for ONE quarter max to ramp them, then revert. Don't be sad when a great rep out-earns the founders, it means the model works (Pipedrive example: rep called self-serve accounts with multiple seats, e.g. AOL went from 20 to 100 seats).
- Hire reps whose LAST product was HARDER to sell, they'll feel like 'weight released from their feet.' Heuristics for 'harder': more technical (B2D/selling to VP Eng), more competitive (someone who did well at the #4 player coming to your #2), or a more complex business-process sale. Sam Blond went from selling cloud financials (Intacct), which nobody trusted in the cloud, to EchoSign and was instantly #1.
- Manage the product-vs-sales feature-request tension with a fixed quarterly BUDGET for sales (e.g. 10% of story points / pie chart). Sales owns that budget and force-ranks within it; changing mid-quarter is allowed but costly and the cost is made explicit. Tension between product and sales is HEALTHY ('if there's no stress, you're not in enough deals'). Push individual rep requests UP to manager-to-manager, never let a junior IC negotiate the roadmap with a mid-level PM directly. Org scaling follows 'rules of eight' (8 SDRs/manager, 8 AEs/director, etc.).
- Be customer-centric on monetization or you kill compounding: offer the longest customer-centric free trial (14-day trials exist only because Salesforce reps wanted to close same-month, not because it helps customers); avoid forcing annual contracts on SMBs ('terrible advice from people who never built products'); don't 'weaponize' customer success or product into revenue-extraction (one beloved vendor demanded $50K from a $299/mo customer, destroying trust). Appoint a 'VP of Free' to champion the non-converting long tail. And only raise prices if you 'earned it' with real new value.

## Frameworks & mental models
- A+ Middlers (founders are great at the middle of a sale, weak at open/close)
- The 'would I buy from them?' rep-hiring test
- Sell-me-this-pen / 'sell me this app' interview demo
- Rules of Eight (sales org scaling: 8 reports per manager)
- Quarterly feature-request budget for sales (story points / % of roadmap)
- Hire from a harder-to-sell product (the 'weight off your feet' heuristic)
- The Columbo question ('what will you do your first 14 days?')
- VP of Free (champion for the non-converting long tail)
- 3x-5x rule (reps must bring in 3-5x their take-home)
- Compounding / churn-first thinking (top-decile churn or pass)

## Notable quotes
> “You need that quirky pyromaniac that loves your product and can sell it. Forget about what's on their LinkedIn, I would buy from Lenny.”

> “Anytime an employee fails, it's your fault. You hired them. They never knew what they were getting themselves into. Be kind.”

> “It's not hires, it's mishires, probably the single most important thing in scaling startups.”

> “Going to annual contracts on a spreadsheet looks great. You know what's better? Letting customers pay what they want to pay.”
