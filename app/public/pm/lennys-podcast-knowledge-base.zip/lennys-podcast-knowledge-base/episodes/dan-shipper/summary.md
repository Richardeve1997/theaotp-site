---
title: "AI predictions: Job markets, Codex beats Claude, and the death of org charts | Dan Shipper"
guest: "Dan Shipper"
date: "2026-05-24"
youtube_url: "https://www.youtube.com/watch?v=4D3hDmGhFhA"
slug: "dan-shipper"
tags: ["ai agents", "future of work", "saas", "product management", "ai adoption", "org design"]
---

# AI predictions: Job markets, Codex beats Claude, and the death of org charts | Dan Shipper

**Dan Shipper** · 2026-05-24 · [▶ Watch](https://www.youtube.com/watch?v=4D3hDmGhFhA)

> Every's CEO predicts work shifts into agent harnesses (Codex/Co-work), SaaS survives and thrives, and every agent still needs a human who cares about it.

**Topics:** ai agents, future of work, saas, product management, ai adoption, org design

## Key lessons
- The 'super agent' beats personal agents for now: Shipper initially believed everyone would have their own agent (Open Claw / a 'parallel shadow org chart'), but flipped to one company-wide agent (like Shopify's River, Ramp's agent) because personal agents are too fiddly to maintain. The mechanism: agents need a human who cares about them, so start with one general agent at the top owned by a forward-deployed engineer, then specialize downward as models get more independent.
- Work is bifurcating into two surfaces: (1) async agents you delegate to, mostly in Slack (kept separate from personal-life agents), and (2) a coding-agent harness (Codex, Claude Co-work) that becomes the OS for ALL knowledge work, email, docs, research, not just code. Shipper runs one Codex thread per project and stays in 'inbox zero for 10 days' by having Codex gather emails via their Cora agent and acting on each as he monologues.
- Don't put AI in the browser, put a browser in the AI. The reverse of the expected pattern is winning: Codex's in-app browser lets the agent watch you work (e.g. in Proof, his open-source markdown editor) and act alongside you. Claude Code can't browse external sites, which Shipper sees as a gap that will close within a year.
- SaaS isn't dying, buy SaaS stocks. Agents INCREASE the number of SaaS users (Every's own SaaS spend is up YoY despite full AI adoption). Crucially, when users run agents against your app inside Codex they spend THEIR tokens, not the vendor's, fixing the margin problem of bolting an AI agent into your own product. Build software for humans AND agents collaborating on the same work, not a CLI an agent uses alone.
- The 'senior engineer benchmark' reveals the autonomy illusion: Shipper had two senior engineers independently rewrite his vibe-coded Proof codebase, then scores new models against them. Models stayed at ~30/100 until GPT-5.5 jumped to ~62 (humans hit high-80s/low-90s). GPT-5.5 was the only model with the 'agency and confidence' to rip out old code and rewrite from first principles instead of papering over patches. Even when benchmarks saturate, the human act of framing/articulating the problem can't be scored, so he still hires engineers.
- Automation is a lie / every agent needs a human. Every doubled headcount (15 -> ~30) over the year despite being maximally AI-forward. The emerging role is the forward-deployed engineer who builds systems so non-technical people can do technical work without doing something dumb, e.g. their 'Claudie' agent runs the consulting practice and engineer Nitesh spends most of his time talking to it in Slack, not coding.
- Bet hard on PMs and full-stack designers. Shipper's strongest evidence: Marcus (ex-Axios PM, 'lightly technical') now solo-runs their Spiral writing app and ships faster than almost anyone because coding models let him pair light technical knowledge with spiky product sense. Designers who go AND build their distinctive interactions stand out from undifferentiated 'slop' that all looks the same.
- 'Ride the models' is the only career advice: when a new model drops, replay your workflows and 'turn the rock over again' to test what it can now do. The edge of AI isn't San Francisco (they build it but don't know how to use it), it's wherever AI meets a real human doing real work, so find a 'moment of joy' and play rather than acting from FOMO.

## Frameworks & mental models
- The reach test (do you organically reach for the tool when you wake up?)
- Super agent vs. personal agent / parallel shadow org chart
- The senior engineer benchmark
- The allocation economy (working with AI = being a manager)
- Ride the models
- Models make yesterday's human competence cheap (commoditization, then humans push the next frontier)
- Spaciousness and strength (Rob Brezsny) for facing hard/scary change
- Moment of joy with AI (Nikhil Singhal)

## Notable quotes
> “Automation is a lie. Every time you automate something, in order to make sure the automation is working well, you need a human on top of it.”

> “In order for an AI agent to be useful right now, it really needs a human who cares about it... the minute you sever that connection is the minute the agent is not really that useful anymore.”

> “I would buy SaaS stocks right now. The SaaS apocalypse is dumb. What agents do is increase the number of users of SaaS, not get rid of it.”

> “What models do is make yesterday's human competence cheap... and what humans do is go in there and say, how do I use this to make something new and interesting?”
