---
title: "How Anthropic's product team moves faster than anyone else | Cat Wu (Head of Product, Claude Code)"
guest: "Cat Wu"
date: "2026-04-23"
youtube_url: "https://www.youtube.com/watch?v=PplmzlgE0kg"
slug: "cat-wu"
tags: ["ai product management", "ai agents", "shipping velocity", "evals", "enterprise ai adoption", "ai coding tools"]
---

# How Anthropic's product team moves faster than anyone else | Cat Wu (Head of Product, Claude Code)

**Cat Wu** · 2026-04-23 · [▶ Watch](https://www.youtube.com/watch?v=PplmzlgE0kg)

> Anthropic's Claude Code product lead on shipping features in days, ship-it-in-research-preview process, evals, and being "the right amount of AGI-pilled."

**Topics:** ai product management, ai agents, shipping velocity, evals, enterprise ai adoption, ai coding tools

## Key lessons
- Ship in research preview to slash commitment: Claude Code brands almost every feature as an early, possibly-unsupported experiment so the team can get something into users' hands in a week or two and iterate, instead of committing to support it forever.
- Compress idea-to-ship with a tight eng/docs/marketing handoff: when an engineer finishes and dogfoods a feature, they post in an 'evergreen launch room' and docs (Sarah), PMM (Alex) and DevRel (Tarek, Lydia) turn the launch announcement around the very next day. Timelines went from 6 months to 1 month to sometimes 1 day.
- Replace roadmap-alignment with goal-setting + team principles: instead of multi-quarter cross-team roadmaps, the team runs weekly metrics readouts and maintains a written list of 'team principles' (who the key users are, why, what they'll trade off) so anyone can make decisions without being blocked on PM.
- Hire engineers with product taste over more PMs: Claude Code's bet is engineers who can go from a Twitter complaint to a shipped feature by end of week with almost no PM involvement; nearly all their PMs were formerly engineers and designers were front-end engineers, which builds trust and speed.
- Be 'the right amount of AGI-pilled': don't over-build for a hypothetical super-smart model (which just needs a text box), and don't under-build; the rare, hard skill is eliciting maximum capability from the CURRENT model and guiding users onto the 'golden path' around its weaknesses.
- Use models to debug themselves and trust a small feedback circle: ask the model to introspect on why it did something unexpected (e.g. skipped front-end verification) to find harness gaps; identify ~5 high-quality 'taste' reviewers (like Amanda who molds Claude's character) rather than weighting all feedback equally.
- Build 10 great evals, not hundreds: evals are an underappreciated way to quantify the goal and progress; Cat personally jumps into evals when a feature (e.g. memory) needs more product definition, producing ~5 evals plus the prompt that raised the success rate.
- An automation that works 95% of the time is not an automation: people get something to 90-95% and give up, but the last 5-10% (teaching Claude your preferences via feedback) is what makes it trustworthy and reliable. Build apps you actually use daily, and avoid over-customizing your setup at the expense of the core task.

## Frameworks & mental models
- Ship-in-research-preview (low-commitment branded launches)
- Idea-to-ship in under a week (evergreen launch room + next-day docs/PMM/DevRel)
- Team principles + weekly metrics readouts (decentralized decision-making)
- The right amount of AGI-pilled
- Building-blocks vision: single task -> multi-task -> dozens/hundreds of remote agents (self-verifying, self-improving)
- Remove the harness as the model improves (to-do list crutch -> model does it natively)
- Observe model strengths/weaknesses -> elicit max capability for current model

## Notable quotes
> “It is very hard to be the right amount of AGI-pilled. It's very easy to build a product for the super-AGI strong model. The hard thing is figuring out, for the current model, how do you elicit the maximum capability?”

> “As code becomes much cheaper to write, the thing that becomes more valuable is deciding what to write.”

> “If an automation doesn't work 100% of the time, it's not really an automation.”

> “If Claude Code failed but Anthropic succeeded, I would be extremely happy.”
