---
title: "How to be a CEO when AI breaks all the old playbooks | Sequoia CEO Coach Brian Halligan"
guest: "Brian Halligan"
date: "2026-02-15"
youtube_url: "https://www.youtube.com/watch?v=3UyitfSbY6c"
slug: "brian-halligan"
tags: ["ceo coaching", "hiring", "ai gtm", "leadership", "scaling", "enterprise sales"]
---

# How to be a CEO when AI breaks all the old playbooks | Sequoia CEO Coach Brian Halligan

**Brian Halligan** · 2026-02-15 · [▶ Watch](https://www.youtube.com/watch?v=3UyitfSbY6c)

> HubSpot co-founder turned Sequoia CEO coach on hiring spiky over safe, "Halliganisms," and why AI changes the top of the funnel but not enterprise sales (yet).

**Topics:** ceo coaching, hiring, ai gtm, leadership, scaling, enterprise sales

## Key lessons
- Hire spiky, not safe: HubSpot stopped picking the candidate everyone rated 3/4 (fewest weaknesses) and started hiring the polarizing 4/4-and-2/4 candidate, and their hit rate improved. They also shrank interview panels from 8 to 4 people.
- Avoid the big-company hire at small scale: hiring fancy-title execs from Microsoft/Salesforce/Google at a 50-500 person startup created a near-100% attrition rate because of the 'impedance mismatch' in expectations; the McKinsey cohort 'never works' because consultants are conservative while founders rethink conventional wisdom.
- Better blind references: don't 'mail it in.' Ask sharp questions like 'On a scale of 1-10, would you enthusiastically rehire this person for this role?' and 'Were they in the top 1%/10% of your employees?' Parker Conrad's hack: have a C-level candidate sign an NDA, send them a board deck, then chat for 30 min, if they're only complimentary it's a red flag (you want a challenger, not a yes-person).
- The LOCKS algorithm for evaluating founders/CEOs: Lovable (inspires followership), Obsessed (deep founder-market fit, evidence of going down rabbit holes), Chip on the shoulder (a Sequoia trait), deeply Knowledgeable about the domain, and Student of the game (constantly learning, like an LLM).
- AI will change the top of the funnel first, not enterprise sales: buyers will research inside ChatGPT/Gemini/Anthropic instead of clicking blue links, so websites get less important and homepages become an all-knowing avatar you converse with; HubSpot built one and it's working. But enterprise sales (trust 'between two carbon-based life forms') will be the last white-collar job AI replaces.
- AI hasn't changed enterprise GTM mechanics yet: AI-driven companies hire the same roles and run the same enterprise sales process as the 1990s, except SEs are now relabeled 'forward-deployed engineers'/'solutions consultants.' Planning cycles compressed from ~1 year to ~3 months, raising the bar on fast decision-making and 'a massive tax on optionality.'
- DRI religion ('if you want to kill a plant, have two people water it'): everything important happens cross-functionally at scale, so one powerful directly-responsible individual must own it with authority over other divisions; committees never work. This pain only shows up after ~150 employees.
- Solve CV > EV > TV > MV (customer, then enterprise value, then team value, then me): immature managers optimize for their own team's bookings/metrics; HubSpot caught this via quarterly employee+customer NPS by department (e.g. sales NPS dropping 68 -> 30 -> -5 once a leader lost the team, almost never recovers), and baked EV-orientation into review forms and 'champagne award' recognition.

## Frameworks & mental models
- LOCKS algorithm (Lovable, Obsessed, Chip on shoulder, Knowledgeable, Student) for evaluating CEOs/founders
- 5-tool CEO (code, taste, vision, sell the product, convince employees), baseball '52 player' analogy
- CV > EV > TV > MV prioritization (Customer > Enterprise > Team > Me value)
- DRI (Directly Responsible Individual), 'kill a plant with two people watering it'
- Hire slow, fire fast (vs. the common hire fast, fire slow)
- Halliganisms (e.g. 'eat the sandwich, don't nibble'; 'never waste a good crisis'; 'no silver bullet, just lots of lead bullets')
- Kids table vs. adults table (CEO peer groups under/over 100 employees)
- Flash tags / FYI tagging system (Dharmesh's rubric for signaling do-now vs. discuss vs. FYI in CEO messages)
- Next play (Coach Krzyzewski), move on from unforced errors
- 2004 Red Sox team-building (homegrown talent + a few seasoned free agents)

## Notable quotes
> “I think CEOs and everyone dramatically overrates their ability to interview and overrates their gut feeling and underrates a really high quality blind reference.”

> “Companies are far more likely to die of overeating than indigestion.”

> “Old enterprise sales, where there's actual trust built up between two carbon-based life forms, will be very, very, very late to go in the white-collar world.”

> “If you want to kill a plant, have two people water it.”
