---
title: "Why most AI products fail: Lessons from 50+ AI deployments at OpenAI, Google & Amazon"
guest: "Aishwarya Naresh Reganti + Kiriti Badam"
date: "2026-01-11"
youtube_url: "https://www.youtube.com/watch?v=z7T1pCxgvlA"
slug: "aishwarya-naresh-reganti-kiriti-badam"
tags: ["ai agents", "ai product development", "evals", "enterprise ai adoption", "human-in-the-loop", "ai reliability"]
---

# Why most AI products fail: Lessons from 50+ AI deployments at OpenAI, Google & Amazon

**Aishwarya Naresh Reganti + Kiriti Badam** · 2026-01-11 · [▶ Watch](https://www.youtube.com/watch?v=z7T1pCxgvlA)

> Two AI builders behind 50+ enterprise deployments on why agents fail: start low-agency/high-control, climb deliberately, and calibrate behavior continuously.

**Topics:** ai agents, ai product development, evals, enterprise ai adoption, human-in-the-loop, ai reliability

## Key lessons
- The two ways AI products fundamentally differ from software: (1) non-determinism on BOTH input (natural-language interface, infinite ways users phrase intent) and output (probabilistic black-box LLM), and (2) the agency-control trade-off: every unit of autonomy you hand an agent is a unit of control you give up, so the agent must earn trust before you cede it.
- Climb the agency ladder deliberately, never start at V3. Concrete progression for customer support: V1 = route/classify tickets only (humans can undo); V2 = Copilot suggesting drafts against SOPs that humans edit; V3 = end-to-end resolution that can issue refunds and file feature requests. Same for coding (inline completions -> larger refactors for review -> autonomous PRs) and marketing (draft copy -> build campaign -> auto-launch A/B-optimized campaigns).
- The CCCD framework (Continuous Calibration / Continuous Development, an explicit nod to CI/CD): right loop = scope capability, curate an expected-input/output dataset, set eval metrics, deploy; left loop = analyze production behavior, spot error patterns, fix or design new metrics. Crucial insight: eval metrics only catch errors you already anticipated; production monitoring + human-in-the-loop logging surface EMERGENT patterns you never imagined.
- Human-in-the-loop isn't just a safety net, it gives you 'error analysis for free.' Logging what the human accepts, edits, or omits from an AI draft builds the flywheel data to improve the system, while keeping a human accountable so customer trust is never eroded.
- Reliability is the #1 enterprise blocker: a UC Berkeley / Matei Zaharia / Databricks study found ~74-75% of enterprises cited reliability as their biggest problem, which is why most deployed AI today is low-autonomy productivity tooling rather than end-to-end workflow replacement.
- 'One-click agents' are pure marketing. Replacing a critical workflow or getting meaningful ROI realistically takes 4-6 months even with the best data and infra, because enterprise data is messy (e.g. duplicated functions, broken hierarchical taxonomies where a 'dead node' last updated in 2019 still routes tickets). Buy the team that builds you a learning pipeline + flywheel, not a turnkey agent.
- Evals are a victim of 'semantic diffusion' (Martin Fowler's term): the word now means everything from a lawyer jotting error-analysis notes, to PMs writing PRD-like specs, to LLM judges, to checking LMArena benchmarks (which is just MODEL evals, not product evals). Codex itself uses a balanced approach: evals to protect core behavior + heavy customer-signal watching (A/B tests, users switching off the code-review product) + 'vibes' where each engineer stress-tests new models on their own hard problems.
- Watch for implicit signals, not just explicit feedback: a user regenerating a ChatGPT answer (rather than clicking thumbs-down) is a clear signal the first answer failed. Know when to STOP climbing: when daily calibration stops surfacing new data distributions, you're 'minimizing surprise' and ready for more agency, but a model swap (4o -> 5) or evolving user behavior (underwriters throwing whole 30-40pg docs in and asking 'what did previous underwriters do?') resets calibration and forces you back.

## Frameworks & mental models
- Agency-Control trade-off (more autonomy = less control; agent must earn trust)
- Agency ladder / start-small versioning (V1 high-control-low-agency -> V3 autonomous)
- CCCD - Continuous Calibration / Continuous Development (ode to CI/CD)
- Problem-first approach (obsess over the problem, AI is just a tool)
- Success triangle: great leaders + good culture + technical prowess
- Semantic diffusion (Martin Fowler) applied to 'evals' and 'agents'

## Notable quotes
> “Every time you hand over decision-making capabilities or autonomy to agentic systems, you're relinquishing some amount of control on your end... you want to make sure the agent has earned that ability or built up trust over time.”

> “If someone's selling you one-click agents, it's pure marketing. I'd rather go with a company that says 'we're going to build this pipeline for you' that learns over time and builds a flywheel.”

> “Pain is the new moat... successful companies are successful not because they're first to market, but because they went through the pain of understanding the non-negotiables. That pain is what translates into the moat.”

> “Evaluation metrics catch only the errors that you're already aware of, but there can be a lot of emerging patterns you understand only after you put things in production.”
