---
title: "Head of Growth (Anthropic): Anthropic is automating its own growth"
guest: "Amol Avasare"
date: "2026-04-05"
youtube_url: "https://www.youtube.com/watch?v=k-H4nsOTuxU"
slug: "anthropic-head-of-growth"
tags: ["growth", "ai agents", "activation", "pm role", "automation", "leadership"]
---

# Head of Growth (Anthropic): Anthropic is automating its own growth

**Amol Avasare** · 2026-04-05 · [▶ Watch](https://www.youtube.com/watch?v=k-H4nsOTuxU)

> Anthropic's growth lead on scaling $1B→$19B+ ARR in 14 months, automating growth experimentation with Claude, and why "success disasters" eat 70% of his time.

**Topics:** growth, ai agents, activation, pm role, automation, leadership

## Key lessons
- Index toward BIG bets when AI is your core value prop: a traditional growth team spends ~70% on small/medium optimizations and 20-30% on large swings; Anthropic flips this to ~50/50 or 70/30 toward large swings, because the exponential means product value in 2 years is ~100-1000x today (vs. only +30-50% for a non-AI product like grocery delivery), so capturing that differential requires big bets, not micro-optimization.
- Friction is a growth lever, not a tax: adding the RIGHT friction (onboarding questions about who the user is and their interests) consistently lifts conversion and funnel completion because it helps users feel the product is 'for them' and enables downstream personalization, look-alike ad targeting, and lifecycle. Cited proof: MasterClass's purchase-flow quiz was a major revenue driver; Calm and Mercury copy the pattern; breaking a 5-6 field form across two screens reduces cognitive load and performs better.
- Quality drives growth, the highest-impact growth quarter of his career (pre-Anthropic) was at Mercury when the growth team said 'forget metrics' and spent a whole quarter just fixing quality in the complex regulated banking onboarding flow, which produced a significant uplift in onboarding-start-to-completion.
- Anthropic runs 'CASH' (Claude Accelerates Sustainable Hypergrowth) to automate growth experimentation across a 4-stage loop you can eval/hill-climb on: (1) identify opportunities, (2) build the feature, (3) test against quality/brand bar, (4) analyze data and gather learnings. Currently human-in-the-loop, mostly copy changes and minor UI tweaks; win rate is roughly a 'junior PM 2-3 years in,' not yet senior PM. Wasn't possible before Opus 4.5; started working around Opus 4.6.
- Deputize engineers as mini-PMs with a two-week rule: projects under ~2 engineering-weeks put the engineer on the hook to act as PM (talk to security, legal, cross-functional stakeholders); over two weeks the PM stays squarely accountable. Product-minded engineers and design-capable PMs become 'unicorns' whose value rises an order of magnitude.
- Cross-functional stakeholder alignment is the one part of the loop AI can't yet automate, Anthropic's head of design joked 'we will have AGI and it will still be impossible to get six people in a room to align.' This is why PM/design work isn't going away soon, and why PMs and design are currently 'absolutely squeezed' as Claude Code 2-3x's engineering throughput.
- Leave money on the table on purpose: a top growth-team mistake is squeezing every last dollar. Anthropic forgoes metric impact to protect safety, brand, and quality. Controversial tests get sorted into bucket 1 (never ship, don't even run, AI safety lives here) vs. bucket 2 ('yikes but not a red line', run it only if the upside return justifies the cringe level).
- Living-in-the-future automations he runs personally: a Cowork scheduled task reviews ~20-25 dashboards every morning and surfaces only what's concerning/interesting in Slack; a weekly Claude+Slack-MCP job scans projects to flag cross-team MISALIGNMENT before teams waste effort; Claude books his meeting rooms, clears his inbox first-pass, and files Brex reimbursements; and he asks Claude to role-play his manager (Ami Vora) using her public writing + internal Slack to generate weekly self-coaching feedback.

## Frameworks & mental models
- CASH (Claude Accelerates Sustainable Hypergrowth), automating the 4-stage growth experiment loop
- 4-stage shipping/experiment loop: identify opportunities → build → test (quality/brand bar) → analyze & learn
- Success disasters, when things go so well other things break (~70% of his time)
- Two-week rule for PM vs. engineer-as-PM accountability
- Controversial-test buckets: (1) don't-run-don't-ship vs. (2) yikes-but-runnable
- Freedom through constraints
- T-shaped → 'sideways E' / multiple deep spikes (interdisciplinary advantage)
- Thinking in Bets (Annie Duke), put probabilities on uncertain claims

## Notable quotes
> “Linear charts are just not cool. No one cares about linear charts. Everything is log-linear, show me it on a log-linear scale.”

> “Roughly 70% of what I spend my time on is what we internally refer to as 'success disasters', where things have gone so well that other things are breaking now.”

> “We will have AGI and it will still be impossible to get six people in a room to align.”

> “We're very comfortable forgoing metric impact in order to prioritize safety, brand, a high-quality bar, and a great user experience, and that's actually the thing that drives more growth long-term.”
