---
title: "The surprising advice from a founder who built 2 unicorns | Jason Cohen (WP Engine)"
guest: "Jason Cohen"
date: "2026-01-25"
youtube_url: "https://www.youtube.com/watch?v=8xLquwfx6p0"
slug: "jason-cohen"
tags: ["growth", "churn", "pricing", "positioning", "nrr", "gtm channels"]
---

# The surprising advice from a founder who built 2 unicorns | Jason Cohen (WP Engine)

**Jason Cohen** · 2026-01-25 · [▶ Watch](https://www.youtube.com/watch?v=8xLquwfx6p0)

> A 5-question diagnostic for stalled growth (churn, pricing, NRR, channel saturation, "do you even need to grow?") from a 4x founder of 2 unicorns.

**Topics:** growth, churn, pricing, positioning, nrr, gtm channels

## Key lessons
- The growth ceiling math: your max customer count = (new customers/month) / cancellation rate. At 100 new/month and 5% churn, you can NEVER exceed 2,000 customers. Cancellations grow exponentially with size (% of base) while marketing only grows linearly, so churn always overtakes marketing, diagnose this FIRST because it's a hard cap.
- Reframe the cancellation survey question. Groove changed 'Why did you cancel?' to 'What made you cancel?' and usable responses jumped from 10% to 20%. Randomize dropdown options, when Smart Bear did this, all reasons got picked equally, proving the data was noise (people pick the first item).
- 'Too expensive' is never the real reason, they already saw the pricing page and bought. Use medical-style cause analysis (stopped breathing -> car crash -> passed out -> undiagnosed diabetes) to dig to the 'rooter cause'; Cohen rejects single-root-cause thinking entirely.
- Pricing selects the market, the demand curve is a mesa, not a downward line. A mid-size company (1,000 employees, $400M revenue) won't buy a $2 or $100/month tool because it 'can't be good enough.' One founder 12x'd his price (per-year to per-month) and signups didn't change at all, proving he was nowhere near the ceiling.
- The Double Down positioning lesson: same product, 8x the price by selling growth not savings. 'Cut AdWords cost in half' caps you at ~$5k/month (customer needs to actually save money). 'Double your leads for the same ROI' lets you charge the full $40k because the customer was already willing to spend $40k for that lead volume. Sell more of what the CEO values (growth), not cost savings.
- NRR alone is misleading because losses need a bigger gain to recover (down 20% then up 20% = 96%, not 100%). Track BOTH logo churn (N) and NRR. Proof point: of 100+ public SaaS companies only ~2 have NRR below 100%, and median NRR at IPO is 119%, 100%+ NRR is mandatory for durable growth.
- Channels follow an 'elephant curve' not an S-curve, they start S-shaped then the 'butt sags' as audiences saturate and channels quietly decline (magazines/conferences report great numbers right before going under). Adding one feature and 'flogging AdWords' won't restart growth. Get creative: Constant Contact ran in-person city workshops for a $20/month product; HubSpot's agency channel became 50% of revenue in 4-5 years.
- AB testing mostly doesn't work for non-experts: it can't test strategy/vision, and on details most 'winners' are false positives (when the real effect is rare, false positives outnumber true ones even at 95% accuracy). Even Shopify's ~100-person team sees ~1/3 of measured effects vanish in holdout re-checks. 'If you don't know who the fish is at the poker table, it's you.'

## Frameworks & mental models
- 5-question stalled-growth diagnostic (1. Are customers leaving? / logo churn 2. Is pricing/positioning correct? 3. Are existing customers growing? / NRR 4. Are acquisition channels saturated? 5. Do you need to grow?)
- Growth-ceiling formula: max size = new customers / cancellation rate
- 'What made you cancel?' open-ended cancellation survey
- Rooter-cause analysis (vs. single root cause / five whys)
- Pricing demand 'mesa' curve (vs. textbook downward demand curve)
- Create value for the customer, then split it (value-based pricing)
- Elephant curve (channel decay model)
- One-foot-in-strength expansion framework for new products/markets
- Create value -> deliver -> onboard -> customer realizes it -> you measure it (the common thread)

## Notable quotes
> “Your prices are way too low because you just guessed and you haven't changed them.”

> “Think about the gauntlet they went through to get to the product... and after all of that, which clearly means they wanted it to work, they're like 'No, bye.' You've got to go, wait a minute, that's terrible.”

> “If you don't know who the fish is at the poker table, it's you.”

> “If you are not growing, you're dying, well, maybe that's you the person, not you the company.”
