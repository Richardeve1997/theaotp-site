---
title: "Why securing AI is harder than anyone expected and guardrails are failing | HackAPrompt CEO"
guest: "Sander Schulhoff"
date: "2025-12-21"
youtube_url: "https://www.youtube.com/watch?v=J9982NLmTXg"
slug: "sander-schulhoff"
tags: ["ai security", "ai agents", "prompt injection", "guardrails", "ai governance", "enterprise ai"]
---

# Why securing AI is harder than anyone expected and guardrails are failing | HackAPrompt CEO

**Sander Schulhoff** · 2025-12-21 · [▶ Watch](https://www.youtube.com/watch?v=J9982NLmTXg)

> The CEO of HackAPrompt argues AI guardrails fundamentally don't work, and that the real defense is permissioning, education, and frontier-grade AI security expertise.

**Topics:** ai security, ai agents, prompt injection, guardrails, ai governance, enterprise ai

## Key lessons
- Guardrails do not work, full stop. The attack space for a model like GPT-5 is ~1 followed by a million zeros possible prompts, so a vendor's '99% caught' claim is statistically meaningless, basically infinite attacks remain. They also don't dissuade determined attackers and create false confidence in your security posture.
- The only valid way to measure adversarial robustness is adaptive evaluation (attackers that learn over time), not static datasets. In a joint paper with OpenAI, Google DeepMind, and Anthropic, human attackers broke 100% of state-of-the-art defenses in 10-30 attempts; automated systems needed orders of magnitude more tries and only succeeded ~90% of the time. Humans are still the best attackers.
- 'You can patch a bug, but you can't patch a brain.' Classical software bugs can be patched to 99.99% confidence; with an AI model you can be 99.99% sure the vulnerability is STILL there. AI security is fundamentally unlike classical cybersecurity.
- The real defense is at the permissioning/cybersecurity intersection, not guardrails. Frame every agent as 'an angry malicious God in a box' (the AI safety 'control' field), then lock down data access and actions: any data the AI can access, a user can make it leak; any action it can take, a user can make it take in any order.
- CaMeL (a framework out of Google) is the most promising practical defense: it inspects the user's request up front and restricts the agent to only the permissions that request needs (e.g. read-only if the user just asked for a summary), so a malicious injected email telling it to forward data can't execute. Limitation: when a task legitimately needs both read AND write (e.g. 'read my emails and forward ops requests'), CaMeL can't help. Sander called 'plug-and-play CaMeL' an obvious market opportunity.
- Attacking agents is now EASIER than CBRN elicitation. CBRN is more solvable because you can train the model to 'never' do something; agent actions require 'sometimes do this, sometimes don't' (send emails, except when something's weird), which is far harder to draw a line on. Indirect prompt injection (external web/email content attacking agents) remains very unsolved.
- Sander predicts a market correction in AI security within 6-12 months: guardrail/automated-red-teaming companies have little real revenue, are being acquired by classical security firms anyway, and many free open-source tools outperform paid products. Real-world agent harms (financial loss, data leaks, eventual physical injury via LLM robots) will start appearing within a year.
- For most chatbot deployments (FAQ, doc Q&A, read-only) you should do NOTHING for prompt-injection defense, worst case is reputational harm a user could replicate on ChatGPT anyway. Just verify it's truly 'only a chatbot,' log all inputs/outputs for monitoring, and get classical data/action permissioning right.

## Frameworks & mental models
- CaMeL (Google), pre-restrict agent permissions to only what the user's request requires
- Adaptive evaluation / ASR (Attack Success Rate) for measuring adversarial robustness
- 'God in a box' / AI control framing, assume the AI is malicious and contain it
- 'Patch a bug vs. patch a brain' mental model for AI vs. classical security
- CBRNE threat taxonomy (chemical, biological, radiological, nuclear, explosives)
- Cybersecurity + AI-security intersection as the durable security career path

## Notable quotes
> “You can patch a bug, but you can't patch a brain.”

> “When these guardrail providers say 'we catch everything,' that's a complete lie. 99% of one followed by a million zeros, there's still basically infinite attacks left.”

> “Not only do you have a God in the box, but that God is angry, that God is malicious, that God wants to hurt you. Can we control that malicious AI and make it useful to us?”

> “We actually want to scare people into not buying stuff.”
