---
title: "How to show up in any room with a low heart rate: Silicon Valley's missing etiquette playbook"
guest: "Sam Lessin"
date: "2026-01-15"
youtube_url: "https://www.youtube.com/watch?v=KtKJ3A6DWTs"
slug: "low-heart-rate-etiquette"
tags: ["etiquette", "founder skills", "trust building", "ai investing", "vibe coding"]
---

# How to show up in any room with a low heart rate: Silicon Valley's missing etiquette playbook

**Sam Lessin** · 2026-01-15 · [▶ Watch](https://www.youtube.com/watch?v=KtKJ3A6DWTs)

> Sam Lessin's etiquette-as-trust playbook for founders, show up with a low heart rate and an abundance mindset, plus a spicy take that "AI companies" are a terrible seed bet.

**Topics:** etiquette, founder skills, trust building, ai investing, vibe coding

## Key lessons
- The unifying frame is 'show up in a room with a low heart rate' driven by an abundance (not scarcity) mindset: even when it truly is your one shot at the Kleiner Perkins party, act like there will be other opportunities so you don't come in as an Energizer Bunny and project the wrong vibe.
- Forgot-a-name rescue trick: introduce the person you DO know to make the unknown person volunteer their name, say 'Jessica, I want to introduce you...' and let it hang, so they fill in 'Hi, I'm Bob.' Lessin uses this constantly because of a clinical face/name blindness that runs in his family (and was part of his early draw to Facebook).
- Treat conversation like ping-pong: questions are great but cap them, six questions in a row feels like an inquisition/extraction; every give should come with a get. Greet with 'great to see you' instead of 'nice to meet you' so it works whether or not you've already met.
- Dress: fit beats brand and price (a well-fitting $20 shirt beats a misfitting $500 one; most people can't tell cost but can tell fit). Dress exactly one level up, skip the Rolex as a startup founder, and if unsure just ask the level of dress, asking signals confidence and humility.
- Dining mechanics: don't order the most expensive thing (investors notice even when they don't care), order middle-to-last so you can match the host's tone, BBs/Ds with your hands tells you bread-left/drinks-right, napkin in lap, knife blade pointing in. Tip 20% minimum / ~30% ceiling, the goal is for your tip to NOT be memorable.
- Email/scheduling etiquette is a hidden status language: who's in the To vs CC line and the ORDER signals who you think matters (assistant first, CEO fourth = you did it wrong). Skip Calendly as a default, if you're the less-senior/less-busy person, let them name times and you flex; if you must send a link, give real options. Lessin's anti-Calendly rant once drove most of Calendly's monthly growth.
- Effort-signaling matters as much as the act: eye contact, repeating names back, standing to shake hands, sending a short thank-you note, and clean-up-after-yourself moves (his partner Kevin Collard maniacally asks where to put a coffee cup with LPs even though staff will clear it). Respecting EAs/PAs/servers is the #1 way to avoid looking classless.
- Contrarian AI take: disciplined seed investors should run from companies branded 'the AI for X', they're too capital-intensive (even OpenAI at a ~$500B cap only returned ~25x to seed, a middling outcome) and commoditizing. Use AI to supercharge a real business; don't BE an AI business. Lessin instead backs 'implications of AI' plays (Sublime Security, Outtake, JuneDating using ChatGPT histories as match data).

## Frameworks & mental models
- Low heart rate (show up calm, regulated, in control)
- Abundance vs scarcity mindset
- Conversation as ping-pong / give-to-get
- Signaling the effort matters as much as the act
- Dress one level up; fit over brand
- Small talk as TCP/IP handshake (modem-crash to sync wavelengths)
- Use AI as a propellant, don't be an 'AI company' (Teranova/frontier narrative critique)

## Notable quotes
> “Etiquette is a skill for how to show up in a room with a low heart rate.”

> “You kind of want to show up with the self-confidence and the calm of abundance. This is not your one shot, you'll have other opportunities.”

> “Build a relationship, not collect business cards. Understand how to give more than you take.”

> “I'd run away from things that are AI companies. Even if you look smart for the moment, you're playing a dangerous game of getting out before the narrative collapses.”
