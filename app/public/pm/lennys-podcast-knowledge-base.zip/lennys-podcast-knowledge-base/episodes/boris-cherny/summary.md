---
title: "Head of Claude Code: What happens after coding is solved | Boris Cherny"
guest: "Boris Cherny"
date: "2026-02-19"
youtube_url: "https://www.youtube.com/watch?v=We7BZVKbCVw"
slug: "boris-cherny"
tags: ["ai agents", "ai coding", "product strategy", "ai safety", "leadership", "future of work"]
---

# Head of Claude Code: What happens after coding is solved | Boris Cherny

**Boris Cherny** · 2026-02-19 · [▶ Watch](https://www.youtube.com/watch?v=We7BZVKbCVw)

> Claude Code's creator on how 100% of his code is now AI-written, "build for the model 6 months out," and latent demand as the #1 product principle.

**Topics:** ai agents, ai coding, product strategy, ai safety, leadership, future of work

## Key lessons
- Build for the model 6 months out, not today's model: Cherny wrote almost none of his own code in Claude Code's early days because Sonnet 3.5 wasn't good enough, but the product was architected so that when Opus 4 / Sonnet 4 (their first ASL-3 class model, May 2025) landed, adoption inflected and went exponential. Accept poor PMF for the first ~6 months as the price of being ready when the capability arrives.
- Latent demand is his single most important product principle: watch people 'abuse' a product to do something it wasn't designed for, then build the dedicated product. Examples cited: Facebook Marketplace (40% of group posts were buying/selling), Facebook Dating (60% of profile views were opposite-gender non-friends), and Co-work itself (people using Claude Code in a terminal to grow tomatoes, analyze a genome, recover wedding photos, read an MRI). The modern twist: also watch what the *model* is trying to do and remove friction for it ('being on distribution').
- Don't box the model in. A year ago you needed heavy scaffolding/orchestrators forcing step-1-2-3 workflows; now give the model a goal plus tools and let it figure out order and context. Scaffolding buys ~10-20% performance that gets wiped out by the next model release, so it's often better to just wait for the next model. They inverted the usual design: 'the product is the model' with minimal scaffolding.
- Use the most capable model with max effort, counterintuitively for cost: cheaper models (Sonnet vs Opus 4.6) are less intelligent so they burn MORE tokens correcting and hand-holding, so a 'cheaper' model is often more expensive per task. Don't optimize/cost-cut early; give engineers unlimited tokens to test crazy ideas, then optimize (Haiku/Sonnet) only once something works and scales. Anthropic has engineers spending hundreds of thousands a month in tokens.
- Concrete Claude Code workflow tips: start ~80% of tasks in plan mode (literally just one injected sentence, 'please don't write any code yet', shift-tab twice in terminal), let it produce a plan, then auto-accept edits because Opus 4.6 one-shots it; and experiment across form factors (terminal, desktop app, iOS/Android, Slack) since it's the same agent everywhere. Cherny's own coding is now ~1/3 terminal, 1/3 desktop, 1/3 iOS app.
- Under-resource projects on purpose to force 'Claudification', putting one engineer on a project makes them automate aggressively. Productivity per engineer at Anthropic rose 200% in PRs over the year (vs the few-percent gains he saw running code quality for Facebook/Instagram/WhatsApp at Meta); they ~4x'd the eng team yet ship far more. Cherny personally ships 10-30 PRs/day, has edited zero lines by hand since November, and runs ~5 agents in parallel.
- Hire generalists who cross disciplines: on the Claude Code team everyone codes (PM, EM, designer, finance, data scientist) and the strongest contributors blend product+infra, product+design, or product+business sense. He predicts that by end of year the title 'software engineer' starts disappearing, replaced by 'builder,' and 'everyone is a product manager and everyone codes.'
- Anthropic's safety stack is three layers, and shipping early IS a safety strategy: (1) alignment / mechanistic interpretability, peering at neurons, monitoring e.g. a 'deception' neuron, superposition; (2) evals in a 'petri dish'; (3) behavior in the wild. They ran Claude Code internally 4-5 months before release to study it as the first big agent, label new things 'research preview,' and open-sourced a model-agnostic sandbox, their 'race to the top' approach.

## Frameworks & mental models
- Build for the model 6 months out
- Latent demand (apply to both users and the model / 'being on distribution')
- Don't box the model in
- The Bitter Lesson (Rich Sutton), bet on the more general model
- Under-funding / 'Claudify'
- Three-layer safety stack (alignment+interpretability / evals / in-the-wild)
- Race to the top

## Notable quotes
> “100% of my code is written by Claude Code. I have not edited a single line by hand since November. Every day I ship 10, 20, 30 pull requests.”

> “Coding is virtually solved. At least for the kinds of programming that I do, it's just a solved problem because Claude can do it.”

> “An agent has a very specific technical meaning: it's an LLM that's able to use tools. So it doesn't just talk, it can actually act and interact with your system.”

> “The title software engineer is going to start to go away and it's just going to be replaced by builder, or maybe everyone's going to be a product manager and everyone codes.”
