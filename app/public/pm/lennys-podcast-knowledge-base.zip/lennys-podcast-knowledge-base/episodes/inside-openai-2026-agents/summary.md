---
title: "Inside OpenAI: 2026 is the year of agents, AI's biggest bottleneck, and why compute isn't the issue"
guest: "Alexander Embiricos"
date: "2025-12-14"
youtube_url: "https://www.youtube.com/watch?v=z1ISq9Ty4Cg"
slug: "inside-openai-2026-agents"
tags: ["ai agents", "coding agents", "product management", "agent ux", "human-in-the-loop", "openai"]
---

# Inside OpenAI: 2026 is the year of agents, AI's biggest bottleneck, and why compute isn't the issue

**Alexander Embiricos** · 2025-12-14 · [▶ Watch](https://www.youtube.com/watch?v=z1ISq9Ty4Cg)

> OpenAI's Codex product lead on 20x growth, why the real AGI bottleneck is human review/typing speed, and building agents that augment without overwhelming.

**Topics:** ai agents, coding agents, product management, agent ux, human-in-the-loop, openai

## Key lessons
- Codex grew 20x since the GPT-5 launch in August (publicly cited as 10x before this) and now serves many trillions of tokens/week, making it OpenAI's most-served coding model both in their first-party harness AND in the API.
- The original cloud-first Codex was 'too far in the future', it required environment config and async-only prompting. The growth unlock came from retreating to the more intuitive on-ramp: an IDE/VS Code extension and CLI that pairs interactively inside a secure sandbox, then converting that feedback loop into config so users can later delegate. Lesson: live in the future, but not TOO far ahead of your market.
- An 'agent' is a 3-layer stack, model + API + harness, and features must be built across all three. Their 'compaction' feature (lets Codex run 24h+ past its context window) required the model to understand compaction, an API endpoint to trigger it, and a harness to prepare the payload.
- Codex uses ONLY the shell/terminal (not semantic search or bespoke tools) made safe via a sandbox. Optimizing for one harness world lets you train and iterate much faster than supporting every coding-tool opinion.
- The new bottleneck has shifted from writing code (the fun part) to reviewing AI-written code (the unfun part). So the team's focus moved to code-review features, agents validating their own work, and UX choices like showing the image/preview BEFORE the diff to keep humans 'maximally accelerated.'
- Concrete velocity proof: the Sora Android app, built in 18 days to internal employees, then GA 10 days later (28 days total) by ~2-3 engineers, became the #1 app in the App Store, largely by having Codex port the existing iOS app. Atlas browser work that used to take 2-3 engineers 2-3 weeks now takes 1 engineer 1 week.
- 'If you want to build any agent, maybe you should build a coding agent', because the best way for models to use a computer is to write code, and code is composable/importable. Coding is framed as a core competency of any future agent, including ChatGPT.
- The team is unusually 'social-media pilled': a few PMs constantly monitor r/Codex, Reddit, and Twitter for complaints (Reddit = more negative but real, with good upvote signal; Twitter = hypier). They also obsess over D7 retention and repeatedly sign up from scratch (multiple paid Pro accounts) to dogfood the cold-start experience.

## Frameworks & mental models
- Ready-fire-aim (vs ready-aim-fire) with fuzzy long-horizon aiming
- Agent stack: model + API + harness
- Compressing the talent stack (Scott Belsky), blurring PM/design/eng boundaries
- Mixed-initiative / contextual-action UX (video-game 'press X to do the right thing')
- Be kind and candid (candor as an act of kindness)
- Maximally accelerated (Nick Turley's mantra)
- Spec-driven / plan-driven development vs 'chatter-driven development'

## Notable quotes
> “The current underappreciated limiting factor is literally human typing speed or human multitasking speed.”

> “It's a bit like this really smart intern that refuses to read Slack and doesn't check DataDog or Sentry unless you ask it to.”

> “It turns out the best way for models to use computers is simply to write code. So if you want to build any agent, maybe you should be building a coding agent.”

> “The best way to try Codex is to give it your hardest tasks, we're building it to be the professional tool you give your hardest problems to.”
