---
title: "The rise of the professional vibe coder (a new AI-era job)"
guest: "Lazar Jovanovic"
date: "2026-02-08"
youtube_url: "https://www.youtube.com/watch?v=0XNkUdzxiZI"
slug: "professional-vibe-coder"
tags: ["vibe coding", "ai tools", "product management", "career", "design", "prototyping"]
---

# The rise of the professional vibe coder (a new AI-era job)

**Lazar Jovanovic** · 2026-02-08 · [▶ Watch](https://www.youtube.com/watch?v=0XNkUdzxiZI)

> Lovable's first "vibe coding engineer" on shipping production AI products with zero coding background, clarity, context, and taste over code.

**Topics:** vibe coding, ai tools, product management, career, design, prototyping

## Key lessons
- Spend 80% of time planning/chatting and only 20% executing. 'Optimize for the right kind of speed', coding is the solved problem; clarity is what you're actually solving for. Lazar reads the AGENT output religiously, never the code itself.
- Parallel-build technique for clarity: open 4-5 tabs and seed each differently, (1) voice/whisper brain-dump, (2) typed-out prompt with features/pages, (3) attach a reference screenshot from Mobin or Dribbble, (4) paste actual CODE SNIPPETS from libraries like 21st.dev. 'English is the number one programming language, but Lovable still communicates in code the best, give it code for pixel-perfect results.' Compare the variants; clarity compounds and you avoid being locked into a bad first design (saving hundreds of credits later).
- Build a layered set of markdown source-of-truth docs before building: master-plan.md (10k-ft intent/why/who/feel), implementation-plan.md (build order, backend, tables, auth, then API), design-guidelines.md (with actual CSS so AI doesn't over-create), user-journeys.md, then tasks.md (the nitty-gritty subtasks all other docs feed into), plus rules.md/agent.md telling the agent 'read all PRDs and tasks.md before doing anything, do the next task, then tell me how to test it.'
- The 'three wishes' / context-window discipline: LLMs have a finite token budget (~genie grants 3 wishes, not 3,000). One task at a time keeps the context small so the agent doesn't burn 80% of tokens just reading a 60-70 edge-function codebase to find a bug, leaving only 20% to actually fix it (and then it 'picks the easiest fix in the book').
- The 4x4 debug framework, attempt each only ONCE: (1) click Lovable's 'try to fix'; (2) add an awareness layer, open the preview, right-click the broken function, read the browser console log, or ask the tool to write console.logs in relevant files, then paste the output into chat ('99% of the time that's enough'); (3) bring in an external diagnostician, export to GitHub and use Codex (diagnostic only, he won't let it make edits) or repomix to compress the whole codebase into one file for Claude/ChatGPT; (4) revert 3 steps, take a walk, re-prompt, 'it's your fault, you had a bad prompt.'
- After fixing a bug, ask the tool 'how can you help me prompt you better so next time we do it in one go?', then put the answer into rules.md so the agent prompts itself better. 'You're just going to learn that I'm stupid and you're going to prompt yourself better.'
- Don't over-invest in skills the tools will absorb: Lazar deliberately does NOT optimize for context-juggling or workarounds because agents will do it within months ('a year ago this would blow your mind; my March vibe-coding course is now obsolete'). Invest instead in judgment, taste, copy, fonts ('60%+ of how your output looks'), and exposure time, 'set aside more time on learning than building.'
- How the role became a job: build in public. Lazar got hired off a single conversation with Elena Verna because he was already vibe coding publicly (YouTube, LinkedIn) and sharing every failure. 'You don't need a company to hire you, you can hire yourself as a professional vibe coder first.' Some Lovable candidates got hired by sending a Lovable APP instead of a resume, 'we'll always open a *.lovable.app domain.'

## Frameworks & mental models
- Aladdin/genie three-wishes analogy (token/context-window limits)
- Parallel multi-tab build technique (4-5 seeded variants)
- Layered PRD docs (master-plan / implementation-plan / design-guidelines / user-journeys / tasks.md + rules.md)
- 4x4 debugging framework
- Exposure time (taste-building via deliberate exposure to world-class work)
- Demo don't memo
- Converging PM/engineer/designer Venn diagram
- Calligraphy analogy (hand-coding becomes a rare art)

## Notable quotes
> “The ceiling on the AI isn't the model intelligence, it's what the model sees before it acts.”

> “We won't be rewarded in the world of AI for faster raw output. We will be rewarded for better judgment.”

> “Coding is going to be like calligraphy... it's going to be so rare that it's going to become an art.”

> “Everybody produces good enough with AI. So now learning and optimizing for how do I produce world-class and magic is the key lesson, you can code garbage fast as well as magic fast. It's the same amount of time.”
