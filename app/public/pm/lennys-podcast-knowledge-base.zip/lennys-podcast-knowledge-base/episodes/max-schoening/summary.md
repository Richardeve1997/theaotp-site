---
title: "AI era skills: Why cultivating agency matters more than job titles | Max Schoening (Notion)"
guest: "Max Schoening"
date: "2026-05-02"
youtube_url: "https://www.youtube.com/watch?v=mCO-D3pkviM"
slug: "max-schoening"
tags: ["ai agents", "product building", "design", "malleable software", "team operations", "taste"]
---

# AI era skills: Why cultivating agency matters more than job titles | Max Schoening (Notion)

**Max Schoening** · 2026-05-02 · [▶ Watch](https://www.youtube.com/watch?v=mCO-D3pkviM)

> Notion's head of product on why agency beats job titles, code as the "material" to design AI agents, and why the SaaS apocalypse is overblown.

**Topics:** ai agents, product building, design, malleable software, team operations, taste

## Key lessons
- Notion's origin story for getting designers/PMs to code: two designers built 'the worst possible playground', a small, LLM-friendly codebase isolated from the main app, and moved all chat-interface prototyping there. The goal was to make the terminal 'least scary and most one-shotable' to get people 'on the treadmill,' after which they graduated to contributing to the production codebase.
- Schoening doesn't care if designers/PMs ship code to production. He'd rather hire someone who deeply understands how an agent loop works and can design it than someone who can only tweak UI styles in Codex/Claude Code. Reason to code: 'it forces you to really interrogate the material you're designing with', agent loops are made of code, so you must build them in that material to master them.
- Agency is the differentiator in the AI era, not skills (since the models supply the skills). Concrete examples: Brian Lovin blurs eng/design AND is Notion's 'number one recruiter'; Eric Lou asked to be hireable in a hypothetical 5-person startup, then taught himself Figma and then prototyping instead of writing long PRDs. The internal mantra: 'drive Notion like it's stolen.'
- The 'first 10% of every project are now free', no point writing a PRD when you can ship the janky demo version. But the last 10% is still 90% of the work. The cheap-exploration play: 'send off 10 agents to explore 10 different things.' GitHub-era heuristic: 'demos not memos' and 'give me something to react to' (e.g. write the changelog/blog post a user would read).
- Token spend is currently unlimited at Notion, Schoening calls it 'the wrong thing to optimize for' right now and predicts 'in six to 12 months a lot of companies are going to start asking questions around ROI.' One PM is Notion's highest token spender (excluding automated security/vuln scanning). Warning: making token spend a metric to boast about is as silly as bragging about lines of code.
- Software quality has NOT improved with vibe coding, only quantity has. Even the labs ship 'a regression like every two weeks' and 'still can't render a TUI at a reasonable frame rate.' The physical metaphor: 3D-printed prototypes (visible layer lines) vs. engineering = 'optimizing the factory so it works for 100 million people.' That manufacturing/engineering discipline is 'absent from most of the discourse.'
- Every great product has 'one tiny core that is so exceptionally good', a superpower. Examples: GitHub = the pull request, Heroku = 'git push heroku master', Dropbox = the menu-bar sync icon (so reliable it told you if you had internet better than the Mac did), Notion = blocks + slash commands, Snapchat = disappearing photos. The pitfall/death spiral: 'if I just add one more thing it'll finally be great', that never works.
- Taste = 'running a virtual machine in your head where given an idea you can predict whether a certain in-group will like it.' You build it the way you train a model: reps with feedback (input idea → how do people react → 'that seems very back-propagation'). The best designers both have full end-to-end side projects AND constantly try new tools. Pick a specific in-group, don't try to please 8 billion people.

## Frameworks & mental models
- Malleable software (software working closer to the user's interest than the maker's)
- Agency over job titles ('drive it like it's stolen')
- Demos not memos / 'give me something to react to'
- Automation vs. augmentation fork
- Incremental correctness + 'shots on goal'
- 'Obviously good' as the quality bar
- Tiny-core / superpower theory of products
- Taste as a trained model (reps + feedback / back-propagation)
- Jobs To Be Done
- Small-group theory ('the world is run by group chats of eight people or fewer')

## Notable quotes
> “We already have universal basic income. It's called knowledge work.”

> “I don't care at all whether designers write code that lands in production. The reason I like thinking in code is because it forces you to consider the material that you're designing with.”

> “Every time there is a human intervention in code, it should feel a little bit like a bug. That's a good litmus test for how agent-filled you are.”

> “One day you wake up and you realize the world is made up by people no smarter than you, and it just awakens you to the idea that you can just change things.”
