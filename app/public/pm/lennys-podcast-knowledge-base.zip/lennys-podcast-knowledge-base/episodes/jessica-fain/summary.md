---
title: "The art of influence: The single most important skill left that AI can't replace | Jessica Fain"
guest: "Jessica Fain"
date: "2026-03-22"
youtube_url: "https://www.youtube.com/watch?v=RP4vJeIb7WU"
slug: "jessica-fain"
tags: ["influence", "executive stakeholders", "product leadership", "ai agents", "career growth"]
---

# The art of influence: The single most important skill left that AI can't replace | Jessica Fain

**Jessica Fain** · 2026-03-22 · [▶ Watch](https://www.youtube.com/watch?v=RP4vJeIb7WU)

> A Slack-and-Webflow product leader's tactical playbook for influencing executives, treat them as your key user, not a rubber stamp.

**Topics:** influence, executive stakeholders, product leadership, ai agents, career growth

## Key lessons
- Treat the exec as your key user: run stakeholder conversations as discovery interviews. The mistake is going in to get approval; go in to learn and strengthen the plan. Annie Pearl's framing: 'It's not my fault, but it is my problem.' If a leader didn't buy your idea, that's a failure of YOUR influence, not their blindness.
- Open every meeting with a 30-60 second reset because an exec's calendar is 'a strobe light', they haven't thought about you since you last met. Script: 'We're here to discuss X. Last time we left off here. Today's goals are Y. Here's how we'll run it.' Then stop talking, and ask 'Was there anything else you were hoping to cover?' If you go past 60s you've lost them.
- Don't over-prove. Fain blew a review by walking through '16 participants from 15 geos' until the decision-maker glazed over and got on their phone, put proof in the appendix. But always present options: the 'Stuart plus two' rule (build exactly what the exec asked, plus two alternatives you believe in). When Rachel Woolen rejected a single-option doc, the team turned around a new doc in 2 days showing ALL permutations considered, and won the yes.
- Skip 'what's top of mind for you?' (gone generic). Ask spicier questions: 'Tell me what the board is pushing you on,' 'What's the most urgent priority you're scared of messing up?' Everyone has a boss. Then tie your pitch to their actual success metric / OKR / board pressure, execs want to be successful too.
- Use the disarming question 'That's so interesting, what led you to believe that?' to co-create rather than defend. Execs sound certain because they make fast decisions on little info; if they're learners, unpacking the 'why' gets you to a better solution together.
- Follow the breadcrumbs. Execs give subtle asks ('I wonder if...', 'have you considered...'). Webflow's Kev turned an offhand comment from Rachel about design reviews into a full framework Loom within an hour. Contrast: Fain watched Tamar ask 4 times for the 'top 10 use cases on X' before getting frustrated, ignoring repeated cues destroys trust. Calibrate by asking 'How strongly do you feel about this?' / 'Is this more important than these 3 other projects?' to separate mandates from passing ideas.
- Build trust by killing things, not acquiring resources, a senior move that signals aligned incentives. 'Shrink the change' (from the book Switch): turn a scary 6-month bet into a 1-week POC with a defined check-in date ('We'll test this, here's how we'll know it works, I'll come back to you on X date') to de-escalate execs' (and engineers') desire for certainty.
- In the AI era it's 'a golden age of product management, not of product managers.' As execution complexity plummets and everyone can build a V1, the 10x skill shifts to deciding what work survives and getting buy-in for the expensive V2/V3/V4. Onboard AI agents the way you'd onboard junior teammates, codify your product philosophy, success metrics, and taste, while keeping guardrails where you uniquely need to catch hallucinations or 'don't do this without me' moments.

## Frameworks & mental models
- Stuart plus two (deliver the exec's ask + two alternatives you believe in)
- Shrink the change (from the book 'Switch')
- Hey Stuart, what do you think? / office hours (treat strategy alignment as a user interview)
- Customer love sprint (engineer-chosen, must-ship craft sprint)
- Minto Pyramid (recommendation-first presenting, raised by Lenny, endorsed by Fain)
- Red teaming an idea (outsider's-perspective stress test)
- Themes-for-discussion section atop a doc to surface only what must be debated live

## Notable quotes
> “Politics is manipulating outcomes and people for your own gain. Influence is about increasing the odds that your good ideas survive.”

> “It's not my fault, but it is my problem.”

> “I describe an executive's calendar as a strobe light going off... they may not have gone to the bathroom today.”

> “One of the biggest things you can do to build trust is kill things, deprioritize things. That is a very senior way of thinking.”
