---
title: "The most rational take on AI you'll hear this year"
guest: "Benedict Evans"
date: "2026-05-31"
youtube_url: "https://www.youtube.com/watch?v=BD3vLtWhT5A"
slug: "the-most-rational-take-on-ai"
tags: ["ai strategy", "platform shifts", "foundation models", "jobs and automation", "value capture", "distribution"]
---

# The most rational take on AI you'll hear this year

**Benedict Evans** · 2026-05-31 · [▶ Watch](https://www.youtube.com/watch?v=BD3vLtWhT5A)

> Benedict Evans on why AI is "as big as the internet, and only as big," why we're stuck in 1997, and where value really accrues.

**Topics:** ai strategy, platform shifts, foundation models, jobs and automation, value capture, distribution

## Key lessons
- The 1997 frame: AI is as big as the internet/mobile and only as big, most of what will be built hasn't been built, nothing really works end-to-end yet, and even his own 80-slide deck 'mostly says we don't know.' Treat current model-race calls (OpenAI vs Anthropic) like guessing Excite vs Yahoo in 1997.
- Task vs job is the central diagnostic: ask 'what is the hard part?' A spreadsheet automates the accountant's calculation but the number of accountants kept rising all century (two charts in his deck). Claude Code writes the code, but knowing WHAT code/features/customer is the actual job. The PowerPoint is the task; what you pay McKinsey for is walking your org, the politics, and talking to customers.
- Why AI labs are buying consultancies/PE and hiring forward-deployed engineers: companies have no spare staff to reimagine workflows. Mapping which workflows to automate is a 5-10 person, 1-2 month project, and implementing is another project, so the labs themselves staff up. A forward-deployed engineer is 'an Accenture outsourced developer who works in San Francisco.'
- Foundation models likely lack pricing power: no network effects, no winner-take-all, undifferentiated commodity selling at marginal cost. Analogy to telecom, global mobile is ~$1T revenue, ~$200B/yr capex (15-20% of revenue), data consumption up 1,500-2,000x since 2010, yet stocks went nowhere for 25 years because the value sat further up the stack. He rebuts Altman's 'AI sold on a meter like electricity', TV makers don't pay the utility a cut.
- The model is 'the dumb thing underneath' that powers features; value moves up-stack. Browsers (Microsoft won browsers for 5-6 years and got nothing) and AWS (customers don't standardize on a cloud) are the templates, NOT Windows. If it must be apps and labs can't build them all, the value goes to app builders.
- Jobs: the lump-of-labor / lump-of-labour fallacy, since 1800 each tech kills crap jobs and creates better ones you can't name in advance ('railway engineer, who'd want to go that fast?'). Enterprise reality slows the apocalypse: 18-month sales cycles, no one rips out SAP overnight; the estate looks radically different in 3-10 years, not two weeks. Even Anthropic/OpenAI are increasing headcount.
- Adoption is fast because you stand on giants' shoulders: ChatGPT hit ~900M weekly users only because ~5.5-6B smartphones and 900M internet users already existed (Netscape in '94 had only 50-100M PCs). But people still don't know HOW to rebuild their business, most SaaS firms born pre-ChatGPT could have existed 15 years earlier; the lag is realizing the use case.
- The anti-AI backlash is a 'fuzzy mess', separate the real from the fake. Data-center water use is ~0.017% of US consumption (Livermore Lab, end-2024), a local planning problem, not a data-center problem. Energy (~5%, growing ~1 percentage point/yr) and youth-employment slowdowns are more real but not yet conclusively AI-caused. Crucially: labs publish NO daily-active-user numbers, so all data is economists backing it out of BLS surveys.

## Frameworks & mental models
- Task vs Job (what's the actual hard part you're hired for)
- The 1997 analogy / presume radical uncertainty
- Lump-of-labour fallacy + price elasticity (Jevons paradox)
- Capital / Deployment / Change (his deck's three sections)
- 'Do the old thing but more' -> then redefine the question entirely (U-shaped recorded-music revenue curve)
- Cloud-not-Windows model for value capture up the stack
- Skills x Jobs-it-enables x What-people-pay-for (want at least 2 of 3)

## Notable quotes
> “AI is whatever machines can't do yet, because once machines can do it, people say 'well that's just software.'”

> “You can't look at a senior partner at a law firm and say 'well, 17% of their work could be automated', this is horseshit. You can't do that.”

> “My dear sweet child, you need me to explain the margin structure of the utility industry to you... when you watch television the TV company isn't paying a percentage of your bill to the electricity company.”

> “Don't stick your head in the sand and say 'I hate all of this.' That gives you a great feeling of moral superiority and you can go on Blue Sky and shout about how evil AI is. Great. But that's not going to help. What helps is diving in and coming out understanding what you can do with it.”
