---
title: "A child psychologist's guide to working with difficult adults | Dr. Becky Kennedy"
guest: "Dr. Becky Kennedy"
date: "2026-02-01"
youtube_url: "https://www.youtube.com/watch?v=Auxs8ZsHRI4"
slug: "becky-kennedy"
tags: ["leadership", "management", "feedback", "psychological safety", "communication", "company building"]
---

# A child psychologist's guide to working with difficult adults | Dr. Becky Kennedy

**Dr. Becky Kennedy** · 2026-02-01 · [▶ Watch](https://www.youtube.com/watch?v=Auxs8ZsHRI4)

> A clinical psychologist maps her parenting playbook onto leadership: repair, sturdy authority, boundaries-as-what-you-do, and "I believe you AND I believe in you."

**Topics:** leadership, management, feedback, psychological safety, communication, company building

## Key lessons
- Repair, not perfection, is what builds secure attachment - and trust at work. 'Perfect is creepy.' Going back after a bad moment ('earlier I cut you off and used a harsh tone, that's no excuse, I'm sorry') reestablishes trust faster than anything else and cuts defensive, run-on conversations.
- Separate behavior from identity, literally with two hands. Defensiveness happens because people think you're attacking their identity, not their behavior. Open hard conversations with 'we're on the same team, I know you're a good person, you don't need me to tell you we need to start on time - but it keeps happening, so something's going on, let's get to the bottom of it together.'
- Connect before correct, and the first step is a MINDSET not a script: people feel your intention, not just your intervention. A 30-second 'connection' performed as a transaction to extract compliance feels dirty and fails. At work it's 'tell me about your weekend' without counting seconds until you can assign the next task.
- Use the Most Generous Interpretation (MGI). The least generous story you tell about a person at night becomes the leader you are the next morning. For someone belaboring a point: MGI = 'maybe they didn't feel heard,' which produces a private fix ('I wonder if you don't always feel heard, then the room tunes out, which makes you belabor more - we're in a bad cycle') instead of culture-corroding gossip.
- Boundaries = what YOU will tell someone you'll do, requiring the other person to do nothing. 'Don't press the elevator buttons or no dessert' is a request that hands your power to a toddler; 'I'm going to stand between you and the buttons' is a boundary. Threats undermine authority because you won't enforce them (you'll give the sorbet anyway).
- Be the sturdy leader: the airline-pilot metaphor. Three responses to turbulence - (1) 'stop screaming, you're distracting me' = unsafe, (2) 'does anyone want to fly the plane?' = the overcorrected validation trap where feelings dictate decisions, (3) 'this turbulence scares you, it doesn't scare me, I know what I'm doing' = sturdy. Validate the emotion as real for them WITHOUT being overwhelmed by it. Some decisions are leadership decisions, not consensus decisions, because only you hold certain information.
- Optimize for resilience over happiness. 'Optimizing for happiness in childhood is the quickest way to build anxiety and fragility in adulthood.' At work, withholding hard feedback to spare feelings (the Kim Scott story: nine months of silence, then a surprise firing) hurts people far worse. A resilient culture says 'this is hard and I can do hard things,' not 'this is hard, so someone must be at fault.'
- The 'I believe you AND I believe in you' formula. Picture the struggler in a hole: 'I believe you' = one foot in the hole (validation), 'I believe in you' = one foot out, seeing a more capable version than they can see right now. We over-rotate on validation and forget conviction. Pairing them ('this is genuinely hard, AND I know you can figure it out, I won't take the project away because I won't take the feeling of capability away') is the magic.

## Frameworks & mental models
- Repair (the #1 relationship strategy)
- Connect before correct
- Separating behavior from identity (good inside)
- Most Generous Interpretation (MGI)
- Sturdy leadership / the airline pilot metaphor
- Boundaries vs. requests (what you will do, requiring the other to do nothing)
- Resilience over happiness
- I believe you + I believe in you
- Feelings overpower skills (bad behavior = a missing skill)

## Notable quotes
> “Perfect is creepy. Only nonhumans can ever be perfect.”

> “The story you tell yourself about your kid at night kind of becomes the parent you are the next morning. Probably the same is true: the story you tell yourself about your organization at night becomes the leader you are the next morning.”

> “Boundaries are what you tell someone else you will do. And it requires the other person to do nothing.”

> “This turbulence, though it scares you, it doesn't scare me. I'm going to get off this loudspeaker to go do my job. I'll see you when we land. Now even if the turbulence is the same, all of a sudden I feel this deep breath because my worry is contained.”
