---
title: "Hard truths about building in the AI era | Keith Rabois (Khosla Ventures)"
guest: "Keith Rabois"
date: "2026-04-12"
youtube_url: "https://www.youtube.com/watch?v=xCd9ykretlg"
slug: "keith-rabois"
tags: ["hiring", "team building", "leadership", "ai era", "venture", "product management"]
---

# Hard truths about building in the AI era | Keith Rabois (Khosla Ventures)

**Keith Rabois** · 2026-04-12 · [▶ Watch](https://www.youtube.com/watch?v=xCd9ykretlg)

> Keith Rabois on barrels vs. ammunition, ruthless referencing, why he refuses to talk to consumers, and why PMs make no sense in the AI era.

**Topics:** hiring, team building, leadership, ai era, venture, product management

## Key lessons
- Barrels vs. ammunition: a company can only run as many initiatives in parallel as it has 'barrels', people who drive an initiative from inception to success ('get us over that hill, come hell or high water'). PayPal had 12-17 barrels among 254 people (extraordinary); Rabois says Lattice/'Lotus' had ~2, which is the common answer even for good companies. Hiring more people without adding barrels just adds coordination/collaboration tax and a drag coefficient, you do the same or less.
- Ruthless referencing beats interviews: Tony Xu at DoorDash does 20 references on every senior hire; David Sze at Greylock's rule was you keep referencing a founder until you hit your first negative reference. Framing the question correctly is everything, VCs who asked 'Was Max a good employee?' (mixed answer) passed on Fair and regret it; the right question was 'Is Max capable of being a world-class entrepreneur?' (yes).
- Hire undiscovered talent, not the people everyone wants. Startups have ~1/10 the 'salary cap' of incumbents, so the alpha is in people the homogeneous corporate hiring 'black box' will mis-process. This skews younger not because youth matters but because, like a FICO score, people over ~30 have too many data points and get evaluated like everyone else; people with no data points are hard for a black box to process, that's the alpha.
- The 30-day rehire test: 30 days after any hire, ask the whole hiring team 'Would you make the same decision again?' Research shows that loop is about as accurate as measuring 1-2 years out, giving a tight feedback loop to build the hiring 'muscle.'
- Don't talk to consumers/SMB customers, it's not just useless, it's harmful: purchasing is subconscious (ask a Porsche owner why they bought it and 99% give every reason except the real one), feedback is directionally wrong, and once a teammate cites '8 customers said X' it gets locked in everyone's brain. Enterprise/hardcore B2B is the exception (one real decision-maker, utilitarian decisions). His example: a B2B AI company he works with has 30 'must-win accounts' over 2 years, there you CAN meet every decision-maker.
- The PM role makes no sense going forward (via Peter Fenton): year-long roadmaps are incoherent when things impossible in November are easy by March. The durable skill across PM/designer/engineer is now CEO-like, 'what are we building and why' plus business acumen. Best signal: a Ramp eng director with a 20-person team personally ships as much code as he did as an IC, using AI as a 'second team.' At Shopify, PMs have been banned from PowerPoint/Keynote for 2+ years, every product pitch must be a working demo.
- Criticize in public, not private, and reject 'psychological safety.' Public criticism optimizes the system not the atomic unit: colleagues see the issue is known and being addressed, others can volunteer to help, and it becomes team-building. 'High-performance machines don't have psychological safety, they're about winning', read Jordan Rules / watch The Last Dance.
- Speed/operating tempo is the earliest signal of a generational company and it compounds. The tell: between two board meetings the team identifies a problem AND ships, measures, and reacts to the solution (Roelof Botha saw it at Square; same as PayPal). Ramp was on the precipice of shipping cards in ~3 months vs. the usual 9-12, which made Rabois preempt their Series A. Best companies also skip senior hires and grow talent internally (Ramp, Trade Republic), hiring for value creation not value preservation.

## Frameworks & mental models
- Barrels vs. ammunition (initiative-driving people vs. supporting resources)
- Ruthless referencing / reference until first negative reference
- The 30-day rehire test
- Value creation vs. value preservation hiring
- Relentless application of force (Moritz), push harder the better you're doing
- Criticize in public, not in private
- Accumulating advantages / unfair advantage (incl. network effects)
- The 'ugly baby' test, half your VC friends should laugh at the deal

## Notable quotes
> “The team you build is the company you build.”

> “I hate talking to customers. I refuse to allow colleagues of mine to talk to customers... Customers don't know what they want, it's a subconscious decision.”

> “High-performance machines don't have psychological safety. They're about winning.”

> “I want half my VC friends to laugh at me, because ugly babies are the ones where there's real alpha.”
