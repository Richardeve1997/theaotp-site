---
title: "\"I like being scared\": Molly Graham's frameworks for rapid career growth"
guest: "Molly Graham"
date: "2026-01-04"
youtube_url: "https://www.youtube.com/watch?v=twzLDx9iers"
slug: "molly-graham"
tags: ["leadership", "career growth", "scaling", "org design", "okrs", "culture"]
---

# "I like being scared": Molly Graham's frameworks for rapid career growth

**Molly Graham** · 2026-01-04 · [▶ Watch](https://www.youtube.com/watch?v=twzLDx9iers)

> A high-growth handbook for leaders: give away your Legos, jump off career cliffs (J-curve), snorkel before you scuba, and serve the business not the people.

**Topics:** leadership, career growth, scaling, org design, okrs, culture

## Key lessons
- Give away your Legos: in a fast-scaling company the pile of work only grows, so cling to what you've mastered and you get buried under it. At peak Facebook she was 'giving away my job every three weeks' and constantly rehiring herself. The territorial/fearful emotions when handing off work are inevitable but normal-and-not-useful.
- Name your monster 'Bob': externalize the change-related emotions (rage emails at 9pm, imposter dread) as a character whose job is to make you the worst version of yourself. Let Bob rant but don't act. Rule of thumb from Facebook: any feeling that's still there after two weeks is real signal worth raising with a manager/coach; everything shorter is just Bob waves.
- J-curve vs stairs (from Chamath, who whiteboarded it): stairs = safe promotion every ~2 years and boring; jumping off a cliff = ~6-9 months of falling then climbing far past where stairs could reach. Her own example: leaving HR for Chamath's failed Facebook phone, getting her lowest-ever performance rating, then becoming a mobile expert. The phone failed for Facebook but not for her.
- Distinguish fear types: financial fear is real signal you should listen to (do the runway/burn-rate math, find your concrete number like '5-10K/month from consulting' - 'specific financial anxiety is more useful than existential'). But 'I'm scared I can't do this' is a flashing GREEN light - go prove to YOURSELF you can. The goal is self-knowledge, not impressing others.
- Waterline model (from NOLS wilderness training): a team is a boat; diagnose problems top-down across four layers - structural (goals/roles/expectations), dynamics (how the team works/decides), interpersonal (two people), intrapersonal (within one person). 'Snorkel before you scuba' - 80% of team problems are structural/dynamics, but people wrongly jump straight to blaming individuals. A manager's one job if nothing else: clear roles and clear expectations.
- Six rules for goals (anti-OKR; goals are a communication tool): (1) no company needs more than 3 company goals - Facebook ran on growth/MAU, engagement, revenue for 5 years; (2) one goal must win in a fight (engagement beat raw MAU - you could buy bots in Indonesia but that's the wrong number); (3) explain-it-like-I'm-5: a Monday intern should understand them; (4) 'strategy should hurt' (Claire Hughes Johnson) - make painful trade-offs explicit; (5) one goal, one owner ('two people owning a goal is no one owning a goal'); (6) goals alone aren't enough - 'winners and losers have the same goal' (James Clear), build follow-up/accountability process.
- Leadership-through-change rules of thumb: your job isn't to have answers, it's to get good at finding them ('I don't know, let's go figure it out'). Don't promise things you can't control (titles, stability, no-layering) - Claire Hughes Johnson: 'promises like that are letter bombs you mail yourself that explode in a year.' Get as good at firing as hiring (even the best are right ~50% of the time; bad fits become 'barnacles on a ship'). Serve the business, not the people - and 'direct is kind.'
- On founders and culture: ~80% of a company's culture is defined by the founder's personality (Facebook = Mark, a '19-year-old hacker's dorm room'; Google = a 'two PhD students' paradise'). You cannot impose values that contradict the founder - it just creates cultural dissonance. Founder mode = build a company that decides the way the founder would when not in the room. Plus: escalation is a TOOL not tattling (go up TOGETHER when neither party has the power/context), invest in high performers (run small experiments to expand their box) not low performers, and head-count growth above 100%/year is a trap ('50% is the happiest growth rate, 100% is manageable') because you grow too fast to de-dupe duplicate roles.

## Frameworks & mental models
- Give Away Your Legos
- Bob the Monster (two-week rule)
- J-Curve vs Stairs career growth
- Waterline Model (snorkel before you scuba)
- Six Rules for Goals & Alignment
- Founder mode / culture is the founder's personality
- Escalation as a tool (go up together)
- Serve the business, not the people
- 50/100% head-count growth rule
- Proving phase / 'what does this get you that you don't already have?'

## Notable quotes
> “I've made every single mistake in the book. And then I got to the end of the book and I started inventing new mistakes.”

> “Two people owning a goal is no one owning a goal.”

> “Promises like that are letter bombs that you mail yourself that are going to explode in your face in a year.”

> “Facebook felt like a 19-year-old hacker's dorm room. Google was designed to basically be a two PhD students' paradise. 80% of the culture of a company is literally defined by the personality of the founder.”
