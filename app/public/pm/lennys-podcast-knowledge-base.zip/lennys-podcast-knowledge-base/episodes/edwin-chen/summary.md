---
title: "The $1B AI company training ChatGPT, Claude & Gemini on the path to responsible AGI | Edwin Chen"
guest: "Edwin Chen"
date: "2025-12-07"
youtube_url: "https://www.youtube.com/watch?v=dduQeaqmpnI"
slug: "edwin-chen"
tags: ["ai data labeling", "rl environments", "model evals", "ai alignment", "bootstrapping", "founder strategy"]
---

# The $1B AI company training ChatGPT, Claude & Gemini on the path to responsible AGI | Edwin Chen

**Edwin Chen** · 2025-12-07 · [▶ Watch](https://www.youtube.com/watch?v=dduQeaqmpnI)

> Surge AI's bootstrapped founder on data quality, why benchmarks lie, RL environments, and how labs are optimizing AI for "slop" over truth.

**Topics:** ai data labeling, rl environments, model evals, ai alignment, bootstrapping, founder strategy

## Key lessons
- Surge hit >$1B revenue in under 4 years with fewer than 100 people, fully bootstrapped (no VC) and profitable from day one, Chen's thesis is that AI efficiency makes tiny elite teams the future, predicting '$100B per employee' ratios; he believes you could 'fire 90% of people' at big tech and move faster.
- Data quality is not 'throwing bodies at the problem.' For an 8-line moon poem, low-quality grading just checks 'Is it a poem? 8 lines? Contains "moon"?', Surge instead grades for subtlety, imagery, emotional impact (Nobel-tier). They capture thousands of signals per worker/task (keystrokes, response speed, reviews, code standards) and train models on the outputs to see which actually improve the model, like Google Search ranking pages: remove worst-of-worst AND surface best-of-best.
- Benchmarks are untrustworthy for two reasons: (1) many contain outright wrong answers and hidden flaws even researchers don't catch; (2) they have clean objective answers models can 'hill-climb,' unlike the messy real world, which is why models win IMO gold medals but still fail to parse PDFs.
- Public leaderboards like LMArena actively steer models in the wrong direction: voters skim for 2 seconds and pick the flashiest answer, so the easiest way to climb is adding emojis, bolding, and tripling response length, even when the model hallucinates and gets the answer wrong. Labs chase it anyway because enterprise buyers ask 'why are you only #5 on LMArena?' and researchers say 'the only way I get promoted is to climb the leaderboard,' even knowing it makes the model worse.
- Surge measures real progress via deep human evals: domain experts (Nobel-tier physicists, working engineers, teachers) hold real conversations with models and verify the code, double-check the physics equations, and grade for accuracy/instruction-following, the opposite of casual users 'just vibing' on a ChatGPT A/B popup.
- RL environments are the new frontier: build a video-game-like simulation of a real company (Gmail, Slack, Jira, GitHub PRs, a codebase), then break it (AWS goes down, Slack goes down) and reward the model for fixing it. These reveal models that ace single-step benchmarks but 'fail catastrophically' on long-horizon, messy, multi-tool tasks where step 1 affects step 50. Watch the trajectory, not just the final answer, models often reward-hack or stumble to the right answer after 50 failed tries.
- Chen's post-training evolution map via human-learning analogies: SFT (supervised fine-tuning) = mimicking a master; RLHF = writing 55 essays and someone picking the best; rubrics/verifiers = being graded with detailed feedback; RL environments = the new stage that complements rather than replaces the others.
- Models will DIFFERENTIATE, not commoditize, driven by each lab's values/objective function. Chen's example: Claude spent 30 minutes and 30 versions perfecting an email that didn't matter; the real product question is whether you want a model that says 'you're absolutely right, 20 more improvements' (engagement) or one that says 'stop, it's great, send it' (your productivity). He singles out Anthropic as the most 'principled' lab.

## Frameworks & mental models
- Worst-of-worst / best-of-best data quality (Google Search ranking analogy)
- Post-training learning ladder: SFT -> RLHF -> rubrics/verifiers -> RL environments
- Trajectory-based reward (grade the path, not just the final answer)
- Dream objective function / 'you are your objective function' (raising a child, not labeling data)
- Build the one company only you could build (anti-pivot, anti-blitzscale, anti-hype)
- RL environment as simulated company world (Gmail/Slack/Jira + injected failures)

## Notable quotes
> “We're basically teaching our models to chase dopamine instead of truth. We're optimizing your models for the types of people who buy tabloids at a grocery store.”

> “It's kind of crazy that these models can win IMO gold medals, but they still have trouble parsing PDFs.”

> “The only way I'm going to get promoted at the end of the year is if I climb this leaderboard, even though I know that climbing it is probably going to make my model worse.”

> “I always thought it was ridiculous... I always felt that we could fire 90% of people and we would move faster because the best people wouldn't have all these distractions.”
