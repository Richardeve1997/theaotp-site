---
title: "Marc Andreessen: The real AI boom hasn't even started yet"
guest: "Marc Andreessen"
date: "2026-01-29"
youtube_url: "https://www.youtube.com/watch?v=87Pm0SGTtN8"
slug: "marc-andreessen"
tags: ["ai future", "careers", "founders", "venture capital", "moats", "education"]
---

# Marc Andreessen: The real AI boom hasn't even started yet

**Marc Andreessen** · 2026-01-29 · [▶ Watch](https://www.youtube.com/watch?v=87Pm0SGTtN8)

> Andreessen reframes AI as the philosopher's stone arriving exactly as depopulation and 50 years of stagnant productivity demand it, and why human workers get more valuable, not less.

**Topics:** ai future, careers, founders, venture capital, moats, education

## Key lessons
- The job-loss panic is the wrong frame: US productivity growth has run at ~half the 1940-1970 rate and ~a third the 1870-1940 rate, so even if AI TRIPLES productivity it only returns us to 1870-1930-era job churn, a period everyone remembered as awash with opportunity. Combined with depopulation (reproduction below 2 in many countries) and falling immigration, remaining human workers go to a premium, not a discount.
- Look at TASK loss, not job loss. A job is a bundle of tasks; the job persists longer than the individual tasks. His example: 1970s executives dictated to secretaries who typed and mailed letters, today execs do their own email while secretaries shifted to travel/event planning. Coding, PM, and design jobs will see tasks swap out the same way.
- The 'Mexican standoff' between PM, engineer, and designer: every coder now thinks AI lets them also PM and design, every PM thinks they can code and design, every designer thinks they can PM and code, and they're all roughly correct because AI is now genuinely good at all three. The winners pick up the other two roles and become 'superpowered individuals' / unicorns who can build and design products end to end.
- The T-shaped (or 'E/F on its side') strategy via Scott Adams: being good at two things is MORE than double the value, three things MORE than triple, you become a 'super-relevant specialist in the combination.' Adams could've been a decent cartoonist OR decent at business; being both made him uniquely able to write Dilbert. Larry Summers' version: 'don't be fungible', don't be a cog/just one thing.
- Still learn to code (and go all the way down to assembly/chip level) IF you want to be elite, because the best coders now 'orchestrate 10 coding bots in parallel,' and you can't evaluate or debug what the bots produce if you don't understand it. If you just want mediocre code, let AI do it; it'll generate infinite mediocre code fine.
- Underused superpower: use AI to TEACH you, not just do work for you. 'Spend every spare hour talking to AI: train me up.' Concrete tactics from the chat, watch the agent's output/thinking as it works to learn architecture; when you get unstuck ask 'what could I have said to avoid this error?'; have one AI write code and another debug/critique it ('LLM councils').
- Don't over-obsess on moats yet, early predictions in big platform shifts ('read 1993-2010 internet coverage') were almost all badly wrong. AI models look defensible (billions in capex, scarce talent) yet got commoditized fast: within ~18 months of ChatGPT there were ~5 US labs, ~5 Chinese, plus open source at parity. Claude Code built 'Cowork' in a week and a half, impressive, but also shows how low the barrier can be. Be flexible and adaptable instead.
- On AGI: the 'cosmic'/singularity definition overstates it, the 'basket of valuable tasks' definition understates it. Human IQ caps around 160 (Einstein level) purely due to biology, there's no reason that's the cap for machines. Today's models test ~131-140; expect 160, 180, 200+. The 'human-equivalent' milestone will be a footnote, the real story is exceeding human capability across coding, medicine, and law.

## Frameworks & mental models
- The philosopher's stone (sand -> thought; alchemy of common into rare)
- Task vs. job (a job is a bundle of tasks; tasks change before jobs do)
- The Mexican standoff (PM / engineer / designer; in Hollywood: director / writer / actor)
- Superpowered individual
- T-shaped / Scott Adams combination skills ('don't be fungible' - Larry Summers)
- Bloom's two-sigma effect (1:1 tutoring; AI as the scalable tutor)
- Determinate vs. indeterminate optimism (Peter Thiel 2x2; a16z = indeterminate optimist running many bets)
- Barbell media diet (read X / up-to-the-minute, and old books / timeless; distrust the middle)

## Notable quotes
> “We now have a technology that transfers the most common thing in the world, which is sand, into the most rare thing in the world, which is thought. AI is the philosopher's stone.”

> “If we didn't have AI, we'd be in a panic right now about what's going to happen to the economy... The timing has worked out miraculously well: we're going to have AI and robots precisely when we actually need them.”

> “Everybody wants to talk about job loss, but really what you want to look at is task loss. The job persists longer than the individual tasks.”

> “The history of the last three years has been everything that looks like the fundamental breakthrough gets replicated and lapped very quickly... there really aren't any secrets among the big labs.”
