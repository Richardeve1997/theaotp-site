---
title: "How to win when software is not a moat | Evan Spiegel (Snapchat CEO)"
guest: "Evan Spiegel"
date: "2026-04-26"
youtube_url: "https://www.youtube.com/watch?v=-7Yol5vX5xw"
slug: "evan-spiegel"
tags: ["consumer product", "distribution", "design", "moats", "ai agents", "leadership"]
---

# How to win when software is not a moat | Evan Spiegel (Snapchat CEO)

**Evan Spiegel** · 2026-04-26 · [▶ Watch](https://www.youtube.com/watch?v=-7Yol5vX5xw)

> Snap's CEO on why software is never the moat, how a 9-12 person design team out-innovates everyone, and why humanity (not tech) gates AI adoption.

**Topics:** consumer product, distribution, design, moats, ai agents, leadership

## Key lessons
- Distribution is the real bottleneck, not product-market fit. Spiegel argues TikTok and Threads are the only recent consumer successes because they solved distribution: TikTok spent billions subsidizing both sides of its video marketplace (paying viewers and creators), Threads piggybacked Meta's existing user base. He warns AI will help with ideas/strategy/code but won't solve distribution, making it the new moat.
- Snap's network-effect insight: don't connect people to ALL their friends, connect them to their best friend, partner, spouse. Most of a network's value lives in a few close ties, which is how Snapchat grew against bigger incumbents that bet on 'most friends wins.'
- Software is not a moat - learned 15 years ago, the lesson the AI industry is relearning now. Snap's response: build hard-to-copy ecosystems (creator-Snapchatter relationships, millions of AR lenses from developers) and a vertically-integrated hardware/AR stack (Specs), because you can clone a feature but not a full platform.
- Innovation org design from the book 'Loonshots' (Safi Bahcall): big orgs need hierarchy/rigor, which makes people promotion-focused and risk-averse; you also need a tiny, flat, no-title team. The CEO's job is brokering mutual respect between the two so the dialogue between reliability-focused engineers and designers produces innovation. Snap's design team deliberately stays at 9-12 people.
- Operationalizing innovation = velocity + critique. Spiegel meets designers ~2 hours weekly to review hundreds of new ideas; mantra is 'if you want to have a good idea, you have to have lots of ideas.' New hires present work on day one. Crucially, there is NO gate to getting work into the weekly meeting, so good ideas aren't filtered out prematurely.
- Hire designers on portfolio only (most join straight out of school, not big tech). Look for RANGE - work that looks totally different across pieces - because that signals design (empathy for the audience) vs. art (a single personal style). Then ask them to tell the story of one piece they feel strongly about to understand their process.
- Snap deliberately delayed PMs until ~200 employees by having designers do PM work themselves, to prevent designers becoming order-takers who just 'go make me visuals.' At scale, PMs became essential as coordinators across legal, trust & safety, and data science. Design remains an intentional shipping bottleneck to enforce a cohesive customer experience.
- Bringing order to AI chaos via jobs-to-be-done: Snap mapped every JTBD for community (download app, add close friends, use lenses) and advertisers (configure a campaign), then assigned agents and cross-functional teams to each, with metrics tracking business outcomes per job. They built automated code review (~10,000 bugs caught), shake-to-report with agents that debug and suggest fixes, and a one-shot go-to-market agent (Claude-based) that drafts spec, identifies sign-off owners, runs legal/trust-&-safety risk analysis, and writes the launch blog.

## Frameworks & mental models
- Loonshots (Safi Bahcall) - balancing flat innovation teams with structured operational orgs
- Jobs-to-be-done as the unit for deploying AI agents
- Portfolio range as the art-vs-design test for hiring
- Distribution-first lens on consumer product success
- Close-friend network value (vs. most-friends network effects)
- Explainer-in-chief model of leadership communication (from Bill Clinton)

## Notable quotes
> “15 years ago we essentially learned that software is not a moat, which is something that everyone is discovering today with AI.”

> “If you want to have a good idea, you have to have lots of ideas.”

> “Humanity is far more important than the technological developments, largely because humanity dictates how technology is adopted. Technology leaders think folks will just blindly adopt new technology as it comes out... there's going to be a huge amount of societal pushback on a lot of the changes coming with AI.”

> “Being president is really like being explainer-in-chief... your job is actually to just explain stuff to people and help them make sense of the world.”
