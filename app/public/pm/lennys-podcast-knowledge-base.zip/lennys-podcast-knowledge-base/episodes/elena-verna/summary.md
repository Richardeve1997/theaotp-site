---
title: "The new AI growth playbook for 2026 | How Lovable hit $200M ARR in one year"
guest: "Elena Verna"
date: "2025-12-18"
youtube_url: "https://www.youtube.com/watch?v=6qAB6aUMIeA"
slug: "elena-verna"
tags: ["growth", "ai products", "product-market fit", "pricing", "gtm", "hiring"]
---

# The new AI growth playbook for 2026 | How Lovable hit $200M ARR in one year

**Elena Verna** · 2025-12-18 · [▶ Watch](https://www.youtube.com/watch?v=6qAB6aUMIeA)

> Lovable's head of growth on why only 30-40% of the classic growth playbook survives AI: spend 95% on innovation, give the product away, and recapture PMF every 3 months.

**Topics:** growth, ai products, product-market fit, pricing, gtm, hiring

## Key lessons
- Lovable hit $200M ARR in under a year (8mo to $100M, then 4mo to $200M), with 8M+ users and only ~100 employees (30 just six months prior). Verna says only 30-40% of her 15-20 years of growth playbook transfers; she now spends 95% of time innovating on growth vs 5% optimizing (the inverse of her past roles).
- Growth team builds core features, not funnel optimizations: they shipped the Shopify integration (e-commerce storefronts) and voice mode, and are now writing agentic workflows / agent instructions to improve activation. They spend almost zero time on activation because the core 'agent team' is obsessed with making the first generation better.
- Deliberately do NOT optimize for revenue. North Star is engagement retention, not paid retention; revenue is treated as an output of getting more people through the door. They actively discuss how to 'reduce revenue growth rate' by giving more away to grab market share. Paid retention is on par with B2B SaaS benchmarks (Miro, Dropbox, etc.); NDR is strong because builders buy more credits.
- Give the product away as the growth secret sauce: free credits to every hackathon/event, sponsoring anyone who wants to run a Lovable hackathon. They book free credits and freemium LLM cost as MARKETING spend, not a cost center to cut. Logic: someone running a hackathon does your marketing/activating for free, and it's a lower cost-per-eyeball than competing on Google AdWords. AI margins sit ~40%, not 80-90%, so the script must flip from gating AI to exposing it.
- Build-in-public + founder/employee socials is a top organic channel. 'Velocity of shipping' is the #1 dev core value, shipping multiple times/day to keep 'noise in the market' so users log into X/LinkedIn to see 'what did Lovable ship now' (works as resurrection + reengagement). Organic has shifted from SEO/search to social even for B2B. Influencer marketing is 10x bigger than paid social for them because 10 seconds of video shows what vibe coding can do.
- PMF is now a treadmill: every ~3 months you must recapture product-market fit because BOTH sides shift fast: each new LLM release step-changes capability (you must build ahead of the model so the feature is ready when the model lands), AND consumer expectations now change in weeks ('it's not doing this yet, I'm bouncing'). Cited OpenAI's 'code red' losing ~6% share in a week to Gemini 3 as proof no one is bulletproof. Worry: so focused on recapturing 'pioneers' that they can't serve the 'latent majority' / adjacent users (Bangaly's adjacent user theory).
- Hiring shift: best talent = passion/'fire in the belly' + high agency + high autonomy over big logos; screen for people who convert chaos into clarity (don't need clarity given to them). Use paid multi-day work trials + probation. Ex-founders (even failed) and AI-native new grads are now the hottest, highest-paid hires. New role observed: full-time 'vibe coder' (his came from a chief-of-staff, non-technical background).
- Minimum Lovable Product replaces MVP ('viability left back in the 2010s'). Aha moment is now just a 'wow moment' (Lovable's first preview generation after the first prompt). Feedback cycle collapsed from weeks of research/design/build to idea-to-feedback in a day. Workflow at Lovable: every spec ships with a Lovable prototype; PMs recreate pages via screenshot-to-Lovable to hand engineers exactly what they want; heavy use of ChatGPT deep-thinking for brainstorm, Granola for meetings, Wispr Flow for voice.

## Frameworks & mental models
- Minimum Lovable Product (MLP) - replaces MVP
- Wow moment (replaces aha moment)
- PMF treadmill / recapturing PMF every 3 months
- John Cutler's capabilities -> value -> scaling stages of software
- Bangaly Kaba's Adjacent User Theory
- Lenny's race car growth model (engine + turbo boosts)
- Net Dollar Retention (NDR >100%) as investor superpower
- Build-in-public + founder-led socials

## Notable quotes
> “I usually spend maybe 5% innovating on growth in my previous roles; right now I'm spending 95% innovating on growth, and only 5% on optimization. To be ahead of them is not optimization of the problem, it's reinvention of the solution.”

> “We don't optimize for revenue at all. In fact, internally we have a lot of discussions about how can we give more products away, how can we reduce our revenue growth rate by just getting more paid subscribers.”

> “Every three months, I feel like we have to recapture our product-market fit... it's terrifying. Nobody's future is bulletproof yet.”

> “It shouldn't be minimum viable product anymore. Viability is left back in the 2010s. Now it's minimum lovable product.”
