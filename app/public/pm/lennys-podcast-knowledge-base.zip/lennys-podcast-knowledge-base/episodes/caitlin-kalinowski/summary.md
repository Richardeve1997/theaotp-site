---
title: "Why the next AI boom is physical AI | Caitlin Kalinowski (ex-OpenAI, Meta, Apple)"
guest: "Caitlin Kalinowski"
date: "2026-05-17"
youtube_url: "https://www.youtube.com/watch?v=G5WTgB87rYQ"
slug: "caitlin-kalinowski"
tags: ["physical ai", "robotics", "hardware", "supply chain", "ai safety", "team building"]
---

# Why the next AI boom is physical AI | Caitlin Kalinowski (ex-OpenAI, Meta, Apple)

**Caitlin Kalinowski** · 2026-05-17 · [▶ Watch](https://www.youtube.com/watch?v=G5WTgB87rYQ)

> Apple/Meta/OpenAI hardware leader on why physical AI is the next frontier, what makes hardware brutally hard, and the supply-chain shocks coming for everyone.

**Topics:** physical ai, robotics, hardware, supply chain, ai safety, team building

## Key lessons
- Hardware only 'compiles' 4-5 times a year (and the last compile at mass production is final, no OTA fix), so you must front-load reliability checks and stay conservative; software can recompile hourly, hardware cannot. Plan for +/-3 sigma part variance and solve 'the last half percent' before the final build.
- Four design principles she's written about: (1) write goals/KPIs down early and change them as little as possible (changing $300 to $150 mid-build burns months); (2) design the HARDEST/riskiest part first, not the part you already know how to design (e.g. route the cables through the hinge before finalizing hinge design); (3) iterate hardest on what the customer touches most (trackpad > keyboard); (4) do everything you know you need to do RIGHT NOW, because a surprise is always 2 days away and you have no slack.
- Elon-style engineering ratios: put explicit numbers on trade-offs (value of a gram of weight vs cost) so engineering decisions 'fall out' quickly. On MacBook Air they killed features like the ambient light sensor because the overarching goals were weight and size.
- Quest 2 cost-reduction case: aligning the whole team on the goal ('democratize VR by reducing price') drove a full redesign (removed cameras/components, changed materials/processes) and produced the best-selling VR headset ever, arguably a stronger product than before.
- Supply chain is the real bottleneck for robotics at scale: magnets -> processed magnets -> actuators -> robots, every layer outsourced to China/Japan/Korea over 25 years. A diecast part going EOL is recoverable (~3-5 months); silicon or RAM going unavailable is a 'catastrophic redesign' of the whole guts. She advises startups to PRE-BUY memory and stockpile it: memory prices are spiking (she's seen ~6x numbers, expects them to roughly double further), driven by AI/data-center demand that isn't cost-sensitive like consumer electronics.
- Robot safety physics: humanoids near people are still 'advanced prototypes'; strong Chinese robots ship with a '3-foot, no humans' warning. Safety = pulling mass inward (1X Neo), lighter arms, and compliant/soft (not hard) actuators to lower the impulse on impact. Prompt-injecting a robot ('tell it to punch someone') is a real adversarial-hardware threat we can't yet stop.
- AI can't do 'real CAD' yet: Claude can produce surfaces/point clouds but not dense solid parametric entities; LLMs and video models don't understand friction, weight, contact pressure, or 'fold paper 4 times, where's the hole'. She wants 'Codex for hardware engineering' and thinks it may require new world-model architectures. The blocker is data, since CAD files are companies' most proprietary IP, so hobbyists (who don't guard their CAD) are the likely starting point.
- Hiring for zero-to-one: you can't hire people who've done the exact thing because it doesn't exist; hire strong generalists who transfer across fields, blend builders + scalers, look adjacent (autonomous vehicles for the sensing/safety stack), and recruit truly AI-native ~20-21 year-olds to teach the rest of the team how to think (she says it's very hard to find a fully AI-native person in their 30s). Then weight mission alignment and gut-feel 'spark'.

## Frameworks & mental models
- Four hardware-build principles (clear KPIs early / hardest-part-first / iterate on what users touch most / do it now)
- Engineering trade-off ratios (Elon-style: numeric value per gram vs cost)
- 'Works-like / looks-like' prototype models
- Component criticality hierarchy (diecast = recoverable vs silicon/RAM = catastrophic redesign)
- Pre-buy / stockpile strategy for constrained components (memory)
- VR->AR->robotics technology lineage (SLAM, depth sensing, spatial positioning)
- Zero-to-one hiring mix (generalists + builders + scalers + AI-native new grads + mission alignment)

## Notable quotes
> “In hardware we only get to compile our code, quote unquote, like four or five times. And once you compile that last time, you're done.”

> “There's a meteor called memory prices coming for consumer hardware and robotics and physical AI. We're in trouble as an industry.”

> “The right approach is to design the hardest parts first... the best architects look at where this is going to fail and start the detailed design there.”

> “You can't really go ask a hundred people what they want, because they haven't seen it. But if you show it to them, they will absolutely know it's awesome.”
