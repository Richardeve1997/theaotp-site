---
title: "He's negotiated $1B+ in executive compensation. Here's his playbook. | Jacob Warwick"
guest: "Jacob Warwick"
date: "2026-03-15"
youtube_url: "https://www.youtube.com/watch?v=pEis2CBomVA"
slug: "jacob-warwick"
tags: ["career", "negotiation", "compensation", "leadership", "psychology", "personal growth"]
---

# He's negotiated $1B+ in executive compensation. Here's his playbook. | Jacob Warwick

**Jacob Warwick** · 2026-03-15 · [▶ Watch](https://www.youtube.com/watch?v=pEis2CBomVA)

> A behind-the-scenes exec negotiation coach on the exact tactics, psychology, and scripts to grow your comp 20-40%+ without being adversarial.

**Topics:** career, negotiation, compensation, leadership, psychology, personal growth

## Key lessons
- The single highest-ROI move: when you get an offer, just ask 'What's the chance there could be a little more?' Warwick says this alone almost always yields ~20% (e.g. $100k -> $120k), at any level including $1M W-2s. With real coaching he targets ~40% movement, and has seen 100-400% on up-leveling deals (three clients comped 185-285k landed at 1.1M; two at 600k landed at 1.1-1.2M when senior-director roles were re-leveled to VP).
- Never split the difference, and never re-anchor with a number you'd be happy with ('never be so sure of your worth that you wouldn't accept more'). His Hollywood example: a writer offered $700k, attorney countered $1.3M, studio said $1M and they settled, meaning the attorney left money on the table because they never found the ceiling. Anchor egregiously high: he cites a 1970s study where extreme anchors won 75% more than 'reasonable' ones.
- Negotiation starts far sooner than people think and runs entirely on information + timing. Your LinkedIn/resume/headshot/recruiter answers all anchor your perceived value ('if you are positioned as a commodity, you will be treated like a commodity'); say less so you can correct the narrative live. He uses the game of Werewolf to show information asymmetry, companies negotiate thousands of times a day, you do it 4-5 times a career.
- Never negotiate over email, you can't control tone, and a CEO reading your ask in the airport security line just thinks 'that bastard wants more money.' Insist on video or in-person so you can read body language and reschedule if they're having a bad day. Also skip the recruiter (a game of telephone) and get to the person who controls the P&L/EBITDA.
- Treat the interview like an enterprise B2B sales cycle, not a confession of your past. His framework: open with 'I've always loved interviews that feel like a brainstorm/consultation, open to that?', then label their pains ('It sounds like... is there anything I missed?'), run a SWOT, quantify the problem, then 'sell the vacation' (walk them 6 months forward to a board meeting where their head is held high because they hired you). 'If you're talking about your past, you're on the back foot.'
- Don't anchor early because of scope creep: the JD says senior PM, but through interviews it becomes a director role (5 reports, a PLG motion, an eng pod), yet the offer comes in at the number you gave. Slow everything down ('haste equals risk') to gather info, then say 'it sounds like I'm a little more horsepower than you anticipated, what's the chance we restructure for the talent you're bringing in?'
- Make it 'we' not 'me', and use creativity when comp is capped. Severance example: a CMO joining a flat-comp company got everyone on the exec team 6 months severance by framing it as making the CEO look good (proactive protection after a RIF). And when two $2.4M CEO offers stalled, he closed with a $350k G-Wagon, capped budgets, but a 6,000-lb vehicle is a company tax write-off, not 'comp.'
- Use 'reputation labeling' and the 'if you were in my shoes' line to flip emotional leverage. Pre-load the praise the other side wants to keep ('thank you for being an advocate for me') so they're trapped into living up to it; ask 'is this a slam dunk? what's one thing I should have asked?' live on the call so they can't ghost you. When stalled: 'If you were in my shoes, what else would you explore?'

## Frameworks & mental models
- 'What's the chance there could be a little more?' (the soft-pushback opener)
- Sell the vacation (walk the buyer into a future utopian state where you solved their pain)
- Interview-as-enterprise-sales / discovery process (why am I here -> label pains -> SWOT -> sell the vacation)
- Ethos / Pathos / Logos + Kairos (Aristotle's rhetoric, lead with emotion + timing, not logic/credibility)
- Tactical empathy & reputation labeling (Chris Voss-derived; pre-load the positive reputation you want them to defend)
- 'Never be so sure of your worth that you wouldn't accept more' / never split the difference
- Information + timing = power (the game of Werewolf as an information-asymmetry model)
- Reciprocity imbalance (make 2-3 intros live on the call so value is felt before any contract)
- 'If you were in my shoes, what would you do?' (stall-breaker / emotional reframe)
- Under-promise, over-deliver

## Notable quotes
> “If you are positioned as a commodity, you will be treated like a commodity.”

> “Just because it's uncomfortable doesn't mean you don't need to do it. It just means you don't know how to do it.”

> “If you're talking about your past, you're on the back foot and you're losing that conversation.”

> “You will always lose the logical and credible argument against a company. There's information asymmetry here, Meta negotiates thousands of times a day, you negotiate four or five times in your career.”
