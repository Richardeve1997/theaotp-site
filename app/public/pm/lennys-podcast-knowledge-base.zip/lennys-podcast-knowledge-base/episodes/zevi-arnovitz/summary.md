---
title: "How a Meta PM ships products without ever writing code | Zevi Arnovitz"
guest: "Zevi Arnovitz"
date: "2026-01-18"
youtube_url: "https://www.youtube.com/watch?v=1em64iUFt3U"
slug: "zevi-arnovitz"
tags: ["ai coding", "vibe coding", "pm workflow", "non-technical builder", "career", "ai agents"]
---

# How a Meta PM ships products without ever writing code | Zevi Arnovitz

**Zevi Arnovitz** · 2026-01-18 · [▶ Watch](https://www.youtube.com/watch?v=1em64iUFt3U)

> A non-technical Meta PM's exact slash-command workflow for shipping real products in Cursor + Claude Code, and using multiple LLMs to peer-review each other's code.

**Topics:** ai coding, vibe coding, pm workflow, non-technical builder, career, ai agents

## Key lessons
- Build a 7-step slash-command pipeline in Cursor/Claude Code: /create-issue (capture bug-or-idea into Linear fast via MCP), /exploration-phase (Claude reads the codebase + asks clarifying questions), /create-plan (outputs a markdown plan with TLDR, critical decisions, status-tracked tasks), /execute, /review, /peer-review, then update docs. Reusable prompts saved as files in the repo.
- The 'peer review' trick: run code review in Claude, Codex, AND Cursor Composer separately, then feed the other models' findings back via a /peer-review command that frames Claude as the 'dev lead', instructing it to defend why flagged issues aren't real OR fix them. Let the models 'fight it out' until no issues remain (Claude sometimes gets sassy: 'this has been raised for the third time and for the third time I'm telling you this is by design').
- Start by creating a ChatGPT/Claude 'project' (shared instructions + knowledge base) prompted to act as a CTO/technical co-founder that challenges you and is NOT a people-pleaser, to mitigate sycophancy. Graduate gradually: GPT project -> Bolt/Lovable -> Cursor in light mode -> full dark mode terminal. Treat looking at code as 'exposure therapy.'
- Match models to their strengths: Cursor's Composer for speed on non-complex work (full features in minutes); Gemini 3 for UI/front-end (split plans into backend/frontend and let Gemini read the plan); Claude as the communicative opinionated dev lead; Codex (5.1 Max) for the gnarliest bugs. The markdown plan file is the shared artifact passed between models.
- Run constant post-mortems on AI mistakes: when Claude makes a bad bug, ask 'what in your system prompt or tooling made you make this mistake?', let it introspect, then update CLAUDE.md / slash commands / docs so the mistake never recurs. Updating documentation and tooling is one of the biggest productivity hacks, your workflow gets smarter, not just the models.
- The /learning-opportunity command primes Claude with 'I am a technical PM in the making with mid-level engineering knowledge, explain this using the 80/20 rule', used whenever something is hard to understand, turning every build into a learning loop. Make codebases 'AI-native' with plain-text/markdown files explaining how agents should work in each area.
- Used AI to land the Meta PM job: built a Claude 'coach' project fed with Ben Erez's frameworks for mock interviews and brutal feedback; built a Base44 segmentation quiz game played on the bus; used Comet/Perplexity to analyze Lewis Lin's question bank to prioritize prep, but says the biggest game-changer was cold-outreaching humans on LinkedIn for live mocks. AI mocks only take you so far.
- Counter to 'AI = slop / atrophy': you must OWN your outputs, saying 'sorry, AI built that' is your mistake, not the AI's. Slop is human error from not giving context (writing style, problem, guardrails). For juniors, AI lets you 'play at a higher level' and get reps. Cursor reportedly has a '/de-slop' command to clean output.

## Frameworks & mental models
- 7-step slash-command pipeline (create-issue -> exploration -> create-plan -> execute -> review -> peer-review -> update-docs)
- Multi-model peer review / 'dev lead' adjudication
- CTO-as-a-project (anti-sycophancy custom prompt)
- Gradual exposure-therapy ladder (GPT project -> Bolt/Lovable -> Cursor)
- AI-mistake post-mortem -> update tooling/docs loop
- /learning-opportunity (80/20 rule prompt)
- Growth mindset / 10x learner not 10x doer
- Models-as-people mental model (Claude=CTO, Codex=hoodie bug-fixer, Gemini=artsy scientist)

## Notable quotes
> “It's not that you will be replaced by AI, you'll be replaced by someone who's better at using AI than you.”

> “If people walk away thinking how amazing you are, you failed. If people walk away and open their computer and start building, you've succeeded.”

> “The expectation of me wasn't being a 10x PM, it was being a 10x learner. The second I understood that, my whole mindset shifted.”

> “The job of a PM isn't always having the right answers and being the smartest person in the room, it's harnessing anything that gets us to the right solution for users as fast as possible.”
