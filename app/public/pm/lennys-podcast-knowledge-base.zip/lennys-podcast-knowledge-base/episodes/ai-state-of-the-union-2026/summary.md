---
title: "An AI state of the union: We've passed the inflection point & dark factories are coming"
guest: "Simon Willison"
date: "2026-04-02"
youtube_url: "https://www.youtube.com/watch?v=wc8FBhQtdsA"
slug: "ai-state-of-the-union-2026"
tags: ["ai coding agents", "ai security", "prompt injection", "agentic engineering", "ai adoption", "agents in production"]
---

# An AI state of the union: We've passed the inflection point & dark factories are coming

**Simon Willison** · 2026-04-02 · [▶ Watch](https://www.youtube.com/watch?v=wc8FBhQtdsA)

> Simon Willison on the November coding inflection, dark-factory software, and why prompt injection's "Challenger disaster" is still coming.

**Topics:** ai coding agents, ai security, prompt injection, agentic engineering, ai adoption, agents in production

## Key lessons
- The November 2025 inflection: GPT-5.1 + Claude Opus 4.5 crossed a threshold from 'mostly works, watch closely' to 'almost always does what you told it.' Code came first because it's verifiable (runs or doesn't) and absorbed all of Anthropic/OpenAI's 2025 RL training; it's the bellwether for whether other knowledge-work fields are prone to agent loops.
- The 'dark factory' / software-factory pattern (pioneered by StrongDM from ~Aug 2025): two rules - nobody writes code AND nobody reads the code. To validate without reading, they ran a swarm of simulated employees in a SIMULATED Slack/Jira/Okta (rebuilt from public API docs as a tiny Go binary, near-zero marginal cost) making access requests 24/7 - spending ~$10k/day on tokens for QA that never sleeps. The shift: from QA-by-reading-code to proof-of-usage.
- The lethal trifecta = a concrete diagnostic for agent risk: an agent that has (1) access to private data, (2) exposure to untrusted/malicious instructions, and (3) an exfiltration channel. You cannot reliably patch all three with guardrails; you must architecturally CUT one leg - usually exfiltration. Filters top out around 97%, which Willison calls a failing grade since 3-in-100 attacks steal everything.
- Prompt injection is unsolved and structurally unlike SQL injection (which is solved): LLMs cannot distinguish trusted instructions from untrusted pasted-in text - they're the same tokens - so any allow-list/deny-list fails against a novel character sequence or another language. He won't trust even a 100% detection score without a computer-science PROOF, which he can't imagine existing.
- The CaMeL pattern (Google DeepMind) is the most credible mitigation: split into a privileged agent (you trust, can act) and a quarantined agent (sees malicious input, can't act). The privileged agent writes a plan/code that's evaluated with taint-tracking, so once tainted data enters, the next high-risk action requires human approval - filtering human-in-the-loop down to only high-risk steps (asking a human to click OK 5x/min just trains them to rubber-stamp).
- Concrete agentic-engineering tactics: (1) Use test-driven development as the forcing function that makes agents actually RUN code, not paste-and-pray; the magic prompt 'red/green TDD' compresses a whole paragraph into jargon agents understand. (2) Start projects from a thin skeleton template (single 1+1=2 test, your indentation/style) rather than a long CLAUDE.md - agents copy existing patterns from even one file. (3) 'Hoard things you know how to do' in public GitHub repos (simonw/tools ~193 client-side HTML/JS tools; simonw/research = code-verified, not deep-research-vomit) and tell the agent to read/combine them.
- Run agents in unsafe/YOLO mode safely by controlling blast radius, not by trusting the model: Willison uses Claude Code for Web (runs on Anthropic's servers, his code is open-source so a leak doesn't matter) and runs OpenClaw only inside a Docker container or a dedicated Mac mini with its own email - never his private inbox. The 'normalization of deviance' (Challenger O-rings) means every safe launch breeds false confidence until disaster.
- OpenClaw is the market signal: first line of code Nov 25 to a Super Bowl ad (~3.5 months), hundreds of thousands set it up despite hard onboarding AND known catastrophic security (people lost Bitcoin wallets). Proves enormous latent demand for a personal digital assistant that the big labs DIDN'T ship because they couldn't do it securely. 'If you can build safe OpenClaw... that's a huge opportunity. I don't know how to do it.'

## Frameworks & mental models
- Lethal trifecta (private data + untrusted instructions + exfiltration channel)
- Dark factory / software factory pattern (StrongDM)
- Normalization of deviance (Challenger O-ring) applied to AI risk
- CaMeL - privileged vs quarantined agent with taint-tracking (Google DeepMind)
- Red/green test-driven development as agent forcing function
- Hoarding things you know how to do (reusable tools/research repos)
- Agentic engineering vs vibe coding (Karpathy's definition)
- Proof-of-usage / 'alpha' tag vs proof-of-work for AI-built software

## Notable quotes
> “You can get to 97% effectiveness on those filters. I think that's a failing grade. That means three out of a hundred of these attacks will steal all of your information.”

> “We've been using these systems in increasingly unsafe ways... we have this normalization of deviance in the field of AI. My prediction is that we're going to see a Challenger disaster.”

> “Anyone who can talk to your agent can make it do any of the things it's allowed to do - so make sure the blast radius is limited.”

> “The biggest opportunity in AI right now, if you can build safe OpenClaw... that's a huge opportunity. I don't know how to do it. If I knew how, I'd be building it right now.”
