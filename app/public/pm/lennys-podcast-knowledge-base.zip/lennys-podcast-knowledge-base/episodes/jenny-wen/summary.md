---
title: "The design process is dead. Here's what's replacing it. | Jenny Wen (head of design at Claude)"
guest: "Jenny Wen"
date: "2026-03-01"
youtube_url: "https://www.youtube.com/watch?v=eh8bcBIAAFo"
slug: "jenny-wen"
tags: ["design", "ai tools", "product development", "hiring", "leadership"]
---

# The design process is dead. Here's what's replacing it. | Jenny Wen (head of design at Claude)

**Jenny Wen** · 2026-03-01 · [▶ Watch](https://www.youtube.com/watch?v=eh8bcBIAAFo)

> Anthropic's Claude design lead on why the classic design process is dead, what replaces it, and how design splits into execution-support vs. short-horizon vision.

**Topics:** design, ai tools, product development, hiring, leadership

## Key lessons
- The classic linear design process (research -> diverge/converge -> polished mocks) is effectively dead because engineers using AI ship so fast that designers can't gate it. Wen's time-allocation shifted from ~60-70% mocking/prototyping a few years ago to mocking now being only 30-40%, with another 30-40% jamming/pairing directly with engineers and a new slice spent implementing/polishing code herself.
- Design work has 'stratified' into two modes: (1) supporting implementation/execution (let engineers cook, then polish the last mile in code), and (2) creating direction/vision, but vision horizons collapsed from 2-5-10 year decks to scrappy 3-6 month prototypes that just point the team in one direction so seven parallel agents don't build divergent things.
- Ship early but commit to visibly iterating: Claude Co-work launched as a labeled 'research preview' ('this is the worst it's ever going to be'). The trust mechanism is 'building trust through speed', respond to feedback publicly, fix fast, show continuous shipping. The brand-killer is releasing early then going silent.
- Figma still earns its place for breadth-of-exploration (8-10 different directions at once) and fine visual/interaction micro-details, because coding tools are too linear, you over-invest in one direction and iterate on it. Wen still uses an IDE (VS Code) as a designer specifically because she's tweaking frontend CSS/classes and wants to see the code, an inversion as engineers move to terminals/agents.
- For non-deterministic AI products you cannot mock all the states or even make a clickable prototype, you must build with the real model underneath and discover use cases by watching real users (this is literally how Co-work emerged). The '10 days' to ship Co-work was just the final externalization sprint; the real journey was many internal prototypes (e.g. 'Claude Studio') that fed the skills/to-do/context form factors.
- Hiring archetypes for the AI era: (1) 'strong generalists', block/sideways-E shaped, ~80th percentile across multiple skills so they flex into PM/eng-shaped roles; (2) 'deep specialists', the bottom of the T goes deeper than most (e.g. a designer who's basically 50% software engineer, valuable now because you work directly with the model); (3) the overlooked 'craft new grad', early-career, humble, fast learner unburdened by baked-in process. Advice to break in: build and ship lots of real things, not theory.
- Managers should do a stint back in IC work: Wen returned to full-time IC at Anthropic to learn the new hard skills firsthand, arguing you can't empathize with or guide teams through this shift without working that way. She mirrors how eng orgs rotate new EMs through hands-on tasks before managing. Future managers must combine direction-setting with people management, not pure people management.
- Two leadership rituals: (1) 'low-leverage time isn't real', senior leaders dogfooding the product, reproing bugs, filing PRs (she cites Mike Krieger) is actually high-leverage because of who's doing it and the culture it sets; (2) cultivate enough psychological safety that teammates roast you (mimicking her crit phrases) while still holding very high standards, 'tough parent' / radical candor.

## Frameworks & mental models
- Two stratified modes of design work (execution-support vs. short-horizon vision)
- Building trust through speed
- T-shaped / block-shaped (sideways-E/F) / deep-T talent archetypes + the 'craft new grad'
- The legibility 2x2 (legible/illegible founders x ideas), Evan Tana/SPC, applied internally: designers as VCs spotting illegible ideas
- Low-leverage-is-high-leverage manager principle
- Psychological safety + high standards ('tough parent' / radical candor)

## Notable quotes
> “This design process that designers have been taught, we sort of treat it as gospel. That's basically dead.”

> “You're better off not blocking that, letting them cook.”

> “It's not just designers feeling like we have to keep up with engineers, even engineers are like, how do we keep up with ourselves? How do we keep up with all our agents?”

> “A lot of the hard parts of building software are actually not building it... Someone still needs to be accountable for the decision.”
