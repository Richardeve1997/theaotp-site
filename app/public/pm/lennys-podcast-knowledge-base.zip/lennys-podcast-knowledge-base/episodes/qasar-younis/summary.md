---
title: "The real AI revolution isn't software. It's farms, mines, and trucks. | Qasar Younis"
guest: "Qasar Younis"
date: "2026-03-08"
youtube_url: "https://www.youtube.com/watch?v=_rcniEb9bLw"
slug: "qasar-younis"
tags: ["physical ai", "autonomous vehicles", "company culture", "founder advice", "china vs us", "ai anxiety"]
---

# The real AI revolution isn't software. It's farms, mines, and trucks. | Qasar Younis

**Qasar Younis** · 2026-03-08 · [▶ Watch](https://www.youtube.com/watch?v=_rcniEb9bLw)

> The $15B "physical AI" CEO nobody knows on why the real AI impact is tractors and trucks, why staying quiet wins, and how to build a truth-seeking culture.

**Topics:** physical ai, autonomous vehicles, company culture, founder advice, china vs us, ai anxiety

## Key lessons
- The biggest near-term AI impact is physical, not software: Applied Intuition adds intelligence to machines that already exist (cars, tractors, mining rigs, trucks, submarines) because the 50-60 years of hardware engineering is already done, you just inject a little intelligence. Younis's barometer: sit at the Detroit airport gate and count how many people use 'OpenClaw' (Claude Code), roughly zero, versus how many will be touched by autonomous vehicles.
- AI is coming 'just in time' to fill labor gaps, not steal jobs: average farmer age is ~58, long-haul trucking can't recruit because a working-class parent now picks Uber/DoorDash (turn the app off, pick up the kid) over weeks away from family. The right frame for autonomy is that 30,000+ Americans die in car accidents yearly and nobody is clamoring to work in mines, not 'what about the trucking jobs.'
- Don't compare Chinese 'companies' to American companies, read House of Huawei. ~25% of Huawei staff are Communist Party members; 'Huawei' means 'China's ambition,' so it's a state extension, not a profit-seeking firm. Reframe it as 'OpenAI vs the Chinese government' and 'Apple vs the Chinese government.' Chinese EVs look unbeatable only because the US equivalent (Rivian) is judged as a business that must turn a profit; remove the profit constraint and Tesla + others would field 'wow' products.
- Stay quiet and build (Berkshire Hathaway, not a Silicon Valley darling). Core value: 'Our best work is done alone and quietly.' Every minute spent on a podcast or X post is a minute not on customers/product. Caveat ('radical pragmatism'): Younis can do this only because he's already known (ex-YC COO, knows the network); a first-time unknown founder may genuinely need a following to recruit talent, investors, and customers, Naval's point that fame is a tool.
- Successful companies show traction early, then sustain it for a decade+. Heuristic for a founder ~2 years in and struggling: if market feedback is NOT pointing you toward a more and more specific path, hard-reset, the foundation (co-founders, market, or life-phase) may be wrong, not the table you keep adjusting. Treat your first startup as a guaranteed zero: you're a craftsperson building your first wobbly table and exercising the founder muscle; it's no accident Younis's third company is his most successful.
- Derive company values from why you're actually winning, not philosophy, write down the 5-10 reasons you're succeeding once you have traction, then compensate and promote against them (they assess managers on adherence). Applied's values: 'Move fast, move safe' (behavior measured: decisiveness), never disappoint the customer, technical mastery, high output, half the work is follow-up, and 'laugh a lot' (humor surfaces subtle feedback, 'it's not the best' vs 'this sucks').
- Build a truth-seeking culture where the best idea wins regardless of who raised it: the most junior person who worked at Zoox/Waymo/Tesla must feel safe sharing the one idea in their head. Counter-failure mode: Google (1B/month cash flow, 15-20x Facebook's size) couldn't beat Facebook because momentum/'wall of sound' drowns out the market changing, 'how does a gorilla learn to fly? By not being a gorilla.' But hold it in tension with decisiveness: once the debate ends, commit fully because you'll never get more information.
- Operationalize 'maintenance is the work' and remove emotion from decisions: weekly 'cleaning zen' (employees clean their own desks, Japanese-school style), no-shoe office, and the claim that they've never spent any capital they raised in ~10 years with 1,000+ engineers. On decisions: pretend nobody's feelings would be hurt and decide; a good heuristic for a low-emotion culture is that the same decision made by different people yields the same result. Read OLD, well-regarded books you know nothing about, time filters out the noise.

## Frameworks & mental models
- Radical pragmatism (core company value / advice filter)
- Industrial Revolution analogy for AI's societal impact
- The 'monkey brain' / rustle-in-the-bush fear reframe
- Tesla L2++ vs Waymo L4 autonomy spectrum
- Hard-reset heuristic for early-stage traction
- Values derived from why-you-win, tied to comp and promotion
- Truth-seeking culture vs 'wall of sound' momentum (gorilla-can't-fly)
- Score/valuation takes care of itself (Bill Walsh)

## Notable quotes
> “The core root of fear is misunderstanding... spend time to understand it and you will quickly see the limitations.”

> “Imagine instead of thinking OpenAI is competing against Deep Seek, you say OpenAI is competing against the Chinese government.”

> “Our best work is done alone and quietly.”

> “How does a gorilla learn how to fly? By not being a gorilla. The way Google would have won the social media wars was by being a social media company, and it's just fundamentally not.”
