---
title: "\"I deliberately understaff every project\" | Leadership lessons from Rippling's $16B journey"
guest: "Matt MacInnis"
date: "2025-12-28"
youtube_url: "https://www.youtube.com/watch?v=O_W76LR77Vw"
slug: "matt-macinnis"
tags: ["leadership", "hiring", "product management", "ai strategy", "product market fit", "startups"]
---

# "I deliberately understaff every project" | Leadership lessons from Rippling's $16B journey

**Matt MacInnis** · 2025-12-28 · [▶ Watch](https://www.youtube.com/watch?v=O_W76LR77Vw)

> Rippling's CPO on deliberate understaffing, alpha/beta hiring, entropy as the enemy, and why owning first-party data is the only AI moat.

**Topics:** leadership, hiring, product management, ai strategy, product market fit, startups

## Key lessons
- Deliberately understaff every project. Since you can never get staffing exactly right, decide which error to make: overstaffing breeds politics and work on low-priority items (poison/cruft), so always err toward under-staffing, the wisdom is in not under-under-staffing. Keep teams 'dehydrated' so they always want more.
- Use the alpha/beta framework from finance to design teams and process. Alpha = outperformance, beta = volatility. 0-to-1 products want high-alpha people; mature products (Rippling payroll) want low beta. Process exists solely to lower beta, but it suppresses alpha, so apply it surgically only where you don't want surprises.
- Build a 'vessel for meaning' to drive culture change at scale (1,300 R&D people). The Product Quality List (PQL, pronounced 'pickle') is a deliberately quirky, lightweight checklist run as a 'factory inspection' before ship, including the new rule 'one feature flag governs your whole product at ship,' added after Parker hit a blank screen from a forgotten feature flag.
- Fight entropy with relentless energy. Teams always optimize for local comfort over company outcomes; each management layer below the founder-CEO risks an order-of-magnitude drop in intensity. A leader's job is to MIRROR the CEO's intensity, not buffer people from it, call out every bug publicly, every time, in public channels.
- Quit sooner, 'try until you die' is VC propaganda. VCs are incentivized to keep you grinding because their downside is fixed at zero. If you've pivoted once or twice and it's not catching by year 4-5, it's time to reset the cap table. Good seed investors forecast every bet to zero and want your second/third company.
- Product-market fit is binding receptors, not marketing. Like drug discovery, the market is immutable, your launch is a thimble in an ocean of noise. You can't market your way to receptors that don't exist; fate has already decided. If you don't unmistakably know you have PMF, you don't have it.
- AI strategy: own the mine or sell the shovels. Sell shovels (OpenAI/Gemini) or own the data mine (Rippling), being in the middle (renting shovels AND ore) gets your unit economics crushed. Point solutions lack the data context AI needs; integrating via flat-file SFTP is 'drinking through a straw.' This kills 80-90% of standalone AI businesses.
- Ask for relevant experience, not advice, people always give advice but rarely have real experience. In hiring, trust trained intuition then decode it via SPOTAC (smart, passionate, optimistic, tenacious, adaptable, kind), and give every PM (L5 to VP) the same impossible case study to see how many corners they see around and whether they get defensive.

## Frameworks & mental models
- Extraordinary results require extraordinary efforts (attr. Dan Gill)
- Deliberate understaffing
- Alpha / beta (high alpha, low beta)
- Process exists to lower beta
- PQL, Product Quality List / 'factory inspection'
- Compounding + power law + entropy
- SPOTAC hiring rubric
- Binding-receptors / drug-discovery model of PMF
- Narrative violations (attr. Jeff Lewis)
- Own the mine vs. sell the shovels (AI)
- Bundling vs. unbundling
- Ask for relevant experience, not advice
- Conway's Law

## Notable quotes
> “The most selfish thing you can do is withhold feedback from someone... you're optimizing for your own comfort, and it's fundamentally selfish.”

> “Good teams get tired, and that's when great teams kick the good team's asses.”

> “We talk in Silicon Valley about never quit, but that is complete absolute venture capital bullshit... you should fucking quit. Reset the clock, reset the cap table.”

> “If you're selling the shovels you can make money, and if you own the mine you can make money. If you're somewhere in the middle... you're in a very difficult place.”
