---
title: "OpenAI's head of platform engineering on the next 12-24 months of AI | Sherwin Wu"
guest: "Sherwin Wu"
date: "2026-02-12"
youtube_url: "https://www.youtube.com/watch?v=B26CwKm5C1k"
slug: "sherwin-wu"
tags: ["ai agents", "enterprise ai adoption", "engineering management", "business process automation", "platform strategy", "ai roi"]
---

# OpenAI's head of platform engineering on the next 12-24 months of AI | Sherwin Wu

**Sherwin Wu** · 2026-02-12 · [▶ Watch](https://www.youtube.com/watch?v=B26CwKm5C1k)

> OpenAI's API eng lead on 95% Codex-written code, managing fleets of 20+ agents, why AI deployments go negative-ROI, and building for where models are going.

**Topics:** ai agents, enterprise ai adoption, engineering management, business process automation, platform strategy, ai roi

## Key lessons
- At OpenAI, 95% of engineers use Codex daily and 100% of PRs are reviewed by Codex; nearly 100% of code is AI-generated first, then human-reviewed. Engineers who use Codex more open ~70% more PRs and that gap keeps widening.
- Engineers are becoming tech-lead/managers of agent fleets, many run 10-20 parallel Codex threads, steering and checking in rather than writing code (the 'sorcerer's apprentice' problem: high leverage but you must steer or the brooms go wild).
- When a coding agent fails, it's usually a context/underspecification problem, not a model problem. The fix is encoding tribal knowledge into the repo, code comments, structure, MD/skills files, so the agent has what it needs. (Lesson from an internal team running a 100% Codex-written codebase with NO escape hatch to hand-coding.)
- The anti-pattern for enterprise AI: top-down-only mandates (C-suite buys tools, ties it to performance reviews) with no bottoms-up adoption, produces a workforce that 'knows it should use this' but doesn't know how, leading to likely negative ROI. The fix: staff a full-time 'tiger team' of the most excited people (often technical-adjacent non-engineers like an Excel-wizard ops lead) to explore capabilities, run hackathons/seminars, and evangelize.
- 'The models will eat your scaffolding for breakfast', vector stores (2023), agent frameworks, and even today's skills/file-based context will likely be obsoleted as models improve. Don't blindly chase customer feature requests into a local maximum; build for where models are going, not where they are today.
- Best startups build a product for a capability that's ~80% there today, it 'kind of works' but suddenly clicks (e.g., O3 → 5.1) as models improve, giving a far better experience than assuming static capability.
- On model trajectory (per METER benchmark): frontier models do multi-hour SE tasks ~50% of the time, ~sub-hour at 80%. Sherwin expects coherent multi-hour (toward 6-hour) tasks in 12-18 months, which will demand differently-shaped products. He's also bullish on native speech-to-speech audio models as an underrated enterprise unlock.
- Don't fear OpenAI squashing you, startups die from building things customers don't love, not from lab competition. The space is so big VCs now back competing companies freely. OpenAI runs as a neutral ecosystem/platform (every model ships to the API, no blocking competitors) because its charter is to spread AGI's benefits to all humanity, which it can't reach alone.

## Frameworks & mental models
- Sorcerer's apprentice / wizard metaphor (from SICP, 'the wizard book') for vibe-coding leverage and the need to steer agents
- Software-engineer-as-surgeon (from The Mythical Man-Month), empower one person, manager's job is to look around corners and have the scalpel ready
- Spend >50% of management time on your top ~10% performers, 'AI makes good people better and great people exceptional' (Marc Andreessen)
- The bitter lesson, applied to building with AI, remove hand-built logic/scaffolding, trust the model, give it tools
- Build for where the models are going, not where they are today (~80%-there product that clicks as models improve)
- One-person billion-dollar startup and its 2nd/3rd-order effects, a 'golden age of B2B SaaS' of thousands of micro-startups serving each other
- Top-down + bottoms-up AI adoption with a full-time 'tiger team' of evangelists
- Business process automation thesis, repeatable, high-determinism, SOP-driven work outside the SV bubble as the bigger AI opportunity

## Notable quotes
> “The models will eat your scaffolding for breakfast.”

> “This is the worst the models will ever be. (Kevin Weil)”

> “We in Silicon Valley just forget that we live in a bubble... most people in the US are not software engineers, are not very AI-pilled.”

> “Make sure you're building for where the models are going and not where they are today.”
