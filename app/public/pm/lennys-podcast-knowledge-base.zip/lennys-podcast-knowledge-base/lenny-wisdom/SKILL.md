---
name: lenny-wisdom
description: Answer any product, growth, AI, career or leadership question with cited advice from Lenny's Podcast guests, drawn from the Lenny's Podcast knowledge base (35 episode digests, Dec 2025 to May 2026). Also pressure-tests a plan, pitch, roadmap, pricing idea or strategy against what those guests said, including where they disagree. Use when someone asks "what would Lenny's guests say about X", "ask the Lenny knowledge base", "check this against Lenny's podcast", "what does [guest] think about Y", or "/lenny-wisdom".
---

# lenny-wisdom

Ask a product question, get an answer from what Lenny's Podcast guests actually said, with every point credited to the guest and the episode. You can also hand it something you made (a pitch, a roadmap, a pricing idea, a launch plan) and get it pressure-tested against the same people, including the ones who would disagree with you.

Treat it as an advisor, not a search box. The job is judgement: what the strongest voices in the knowledge base would tell you, where they conflict, and what to do next.

## Where the knowledge base lives

Look for a folder called `lennys-podcast-knowledge-base/` in the project. It contains:

- `index.md`: start here. The full episode catalogue with topics, a "start here, by question" table, and the themes that run across episodes.
- `all-episodes.md`: every digest in one file. Handy for searching across all 35 at once.
- `episodes/<slug>/summary.md`: one digest per episode. A one-line summary, key lessons, frameworks and mental models, a few short quotes, and a link to the full episode on YouTube.

If the folder isn't at that path, search the project for an `index.md` that sits next to an `episodes/` folder. If you can't find it, say so and ask where it is. Don't answer from memory and present it as the knowledge base.

## Input

The question or artefact that follows the request (for example "/lenny-wisdom how should I price an AI feature?"). If nothing was supplied, ask what they want advice on first.

## Process

1. **Read `index.md`.** Use the "start here, by question" table and the topics column to find the right episodes fast. The themes section gives you the cross-episode view.
2. **Pick 3 to 6 relevant episodes.** Match on topics and guest. To find every mention of a term across the whole set, search `all-episodes.md` or the `episodes/` folder (for example `grep -ril "pricing" episodes/`).
3. **Read those `summary.md` files.** Don't load the whole knowledge base at once.
4. **Answer with judgement, fully credited.** Give a direct take, then the evidence. Tie each point to a named guest and their episode (cite `episodes/<slug>`). Show disagreements and counter-signals, not just the views that confirm the question. End with concrete next steps.

## Rules

- **Always cite.** Anything you present as coming from the podcast names the guest and the episode. No unsourced claims.
- **Stay inside the knowledge base.** If it doesn't cover the question, say so plainly. Label your own reasoning as your own, separate from what the guests said.
- **Be discerning.** The episodes contain real counter-signals: enterprise sales cycles have not got shorter, customers often don't know what they want, models are becoming commodities. Show them when they apply.
- **Mind the coverage.** The digests cover 35 episodes from December 2025 to May 2026. For older episodes, point the user to the full public transcript archive at https://github.com/ChatPRD/lennys-podcast-transcripts rather than guessing what an older guest said.
- **Quote with care.** Most digests were made from YouTube auto-captions, so quotes are close but not always word for word. Before anyone quotes a guest in public, tell them to check the episode link in that digest.

## Output

Keep it tight. Default shape:

**Take** (1 to 3 sentences) → **What the guests say** (cited bullets, including dissent) → **Counter-signals and risks** → **What to do next**.
