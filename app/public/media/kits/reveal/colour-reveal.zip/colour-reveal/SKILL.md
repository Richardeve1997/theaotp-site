---
name: colour-reveal
description: Turn a finished website into a short "colour reveal" Reel, the three-step format where a site builds up colour by colour (background, then type, then one loud accent) while swatch cards stack beside it. Use when someone says "make a colour reveal video", "reveal video for my site", "do the 1, 2, 3 colour breakdown", "turn this website into a reel", or hands over a site screenshot or URL and asks for a short video about its colours. Works filmed (you on camera, Claude builds the overlay) or faceless (a voice plus an animated character).
---

# colour-reveal: a finished website in, a three-step colour Reel out

The format: a real site builds up in three steps while you name each colour. Two calm colours set the mood, then
one loud accent lands and the design suddenly comes alive. The swatch cards stack beside the site as each colour
is named. It works because the viewer sees the change happen, so the design lesson lands in about ten seconds.

You give Claude one thing: a finished website. Claude does the rest.

## What you need

| Thing | Why | Free option |
|---|---|---|
| A finished website (a URL or a full-width screenshot of the hero) | the design being revealed | your own site or a client's |
| Claude Code (or Claude with file access) | runs this skill | any paid Claude plan |
| A Gemini API key (`GEMINI_API_KEY`) | Google's Nano Banana image model strips the site back into layers | Google AI Studio free tier |
| Node 22+ and `npx hyperframes` | renders the overlay to video | free, open source |
| ffmpeg | joins the overlay to your clip | free |
| Faceless only: an ElevenLabs account | your cloned voice for the voiceover | ElevenLabs starter plan |

## The steps

### 1. Get the hero
If you were given a URL, take a 1600 to 2000 px wide screenshot of the first screen (Playwright or the browser's
own full-width capture). Crop off browser chrome. Landscape works best. Save it as `site/p3.png`. This is the
finished design and it is never edited.

### 2. Pick the three colours
Name three colours in plain, friendly words with their hex values:
- **Background**: the colour that fills most of the page (sky blue, cream, onyx black).
- **Type**: the colour of the headline and UI (cloud white, ink, warm grey).
- **Accent**: the one loud colour that pulls the eye (poppy red, electric lime, flare gold).

Sample the hexes from the screenshot, then check them by eye. A multi-colour accent (a gradient, a photo) samples
badly, so pick the accent hex by looking at it. Write them to `site/colours.json`:
```json
{"background": ["Sky Blue", "#4074AD"], "type": ["Cloud White", "#FFFFFF"], "accent": ["Poppy Red", "#D80506"]}
```

### 3. Strip the site back into layers
Run `python3 strip.py site/p3.png "<what the accent is>"`. It asks Nano Banana for two edits:
- `p2.png`: the same page with the accent removed (type and UI stay).
- `p1.png`: the background only, with every word, button and photo removed.

Describe the accent plainly in the second argument ("the giant red word BEAUTIFUL and the woman in the red dress").
Then open all three images side by side and check them. Nano Banana has three habits to watch for, and the script's
prompts already push against them:
- it regrades the whole photo when it removes an object (the prompt says keep the colour grading and time of day);
- it invents letters to "repair" a word with a gap (the prompt says do not add, move or invent letters);
- it leaves framing bars on the background pass (the prompt asks for a completely blank page).
If one comes back wrong, run that step again. Do not use an image model that re-crops the picture, because the
three layers have to sit exactly on top of each other.

### 4. Write the two lines
Use the format's own shape, with your three colour names:
> "**Background** and **type** look clean, but add some **accent** and the design steals attention."

Variations that work: "Looks clean, right? But add a little **accent**, and now look where your eyes go." /
"Two colours set the mood. The accent is what people remember." Keep it under 12 seconds spoken. Rewrite anything
that sounds like a brochure; it should sound like you talking to a friend.

### 5a. Filmed (you on camera)
Film yourself saying the two lines, vertical, framed so your head sits in the top half. Point up at the space
above your shoulder when you name each colour; that is where the swatches will land. Then:
1. Transcribe the clip with word timings (`npx hyperframes transcribe clip.mp4` or Whisper).
2. Copy `template/` to a new folder, save your three layers as `assets/p1.jpg`, `p2.jpg`, `p3.jpg`, and fill
   `reveal.js` with your colours, the start time of each colour word and the clip length.
3. `npx hyperframes render --format webm --fps 60 template -o overlay.webm` (a transparent overlay).
4. Lay it over your clip (scaled to 1080x1920): `ffmpeg -i clip.mp4 -c:v libvpx-vp9 -i overlay.webm -filter_complex
   "[0]scale=1080:1920[b];[b][1]overlay" -c:a copy reveal.mp4`.

### 5b. Faceless (a voice and an animated you)
1. Make the voiceover from the two lines with your ElevenLabs voice clone (or any voice you like). Speed it up a
   touch; a cloned voice usually reads slow.
2. Make your character once and reuse it: give an image model two or three clear photos of yourself and ask for a
   simple full-body character (pixel art, flat cartoon or 3D toy) in the same outfit, front view, plain background.
   Ask for four poses from the same model sheet: standing, talking with a raised hand, pointing up, thumbs up.
   Cut each onto a transparent background.
3. Set `mode: "faceless"` in `reveal.js` and save the poses as `assets/char-talk.png`, `char-point.png` and
   `char-thumbs.png`. The template stands your character under the site card, swaps to "pointing up" on the
   accent word and "thumbs up" on the last line.
4. Render it (`npx hyperframes render --fps 60 template -o picture.mp4`), then add the voiceover:
   `ffmpeg -i picture.mp4 -i vo.mp3 -c:v copy -c:a aac -shortest reveal.mp4`.

### 6. Check it before you post
- The site never zooms or shakes. The layers only cross-fade (about 3 frames) on their colour words.
- Each swatch lands on its word, and the accent swatch gets a ring when the accent lands.
- Captions are on and readable on a phone.
- Watch it once on mute: someone should still see the design change.

## Files
- `strip.py`: the Nano Banana layer strip (needs `pip install google-genai pillow` and `GEMINI_API_KEY`).
- `template/`: a HyperFrames composition (`index.html`, `reveal.js`, `assets/`, with the Beautiful example layers
  already in place) for the swatches, the three site layers, the accent ring and the faceless character.
