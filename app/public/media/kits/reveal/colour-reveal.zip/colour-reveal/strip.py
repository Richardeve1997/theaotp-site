"""strip.py: strip a finished website hero back into the three colour-reveal layers with Nano Banana.

usage: python3 strip.py site/p3.png "<plain description of the accent>"
writes p2.png (accent removed) and p1.png (background only) next to p3.png, at p3's exact size.
needs: pip install google-genai pillow, and GEMINI_API_KEY in the environment.
"""
import io, os, sys
from pathlib import Path
from google import genai
from google.genai import types
from PIL import Image

MODEL = os.environ.get("REVEAL_IMAGE_MODEL", "gemini-3.1-flash-image")   # Nano Banana

KEEP = ("Keep everything else exactly as it is: same layout, same text, same fonts, same sizes, same positions, "
        "same framing and same image size. Do not change the colour grading, lighting or time of day. "
        "Do not add, move or invent any letters or words. Do not add anything.")
BG_ONLY = ("Remove ALL text, the logo, the navigation, every button, input, icon, card, photo, badge and UI element. "
           "Leave ONLY the empty background with its original colour, gradient, texture, lighting and scenery, at the "
           "same framing and size, as a completely blank page with no bars or frames. Do not change the colour "
           "grading. Do not add anything.")


def ratio(w, h):
    opts = {"1:1": 1, "3:2": 1.5, "4:3": 4 / 3, "16:9": 16 / 9, "5:4": 1.25, "21:9": 21 / 9}
    return min(opts, key=lambda k: abs(opts[k] - w / h))


def edit(client, img, prompt):
    r = client.models.generate_content(
        model=MODEL, contents=[prompt, img],
        config=types.GenerateContentConfig(response_modalities=["IMAGE"],
                                           image_config=types.ImageConfig(aspect_ratio=ratio(*img.size))))
    for part in r.candidates[0].content.parts:
        if part.inline_data:
            return Image.open(io.BytesIO(part.inline_data.data)).convert("RGB").resize(img.size, Image.LANCZOS)
    raise RuntimeError("the model returned no image; run it again")


def main():
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    p3 = Path(sys.argv[1]); accent = sys.argv[2]
    img = Image.open(p3).convert("RGB")
    if img.width > 2000:
        img = img.resize((2000, round(img.height * 2000 / img.width)), Image.LANCZOS); img.save(p3)
    client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])
    p2 = edit(client, img, f"Remove {accent} completely, filling the space so the page looks natural and continuous. {KEEP}")
    p2.save(p3.with_name("p2.png")); print("wrote", p3.with_name("p2.png"))
    p1 = edit(client, p2, BG_ONLY)
    p1.save(p3.with_name("p1.png")); print("wrote", p3.with_name("p1.png"))
    print("Now open p1, p2 and p3 side by side and check them before you build the video.")


if __name__ == "__main__":
    main()
