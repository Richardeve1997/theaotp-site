// reveal.js: the only file you edit. Times are seconds into YOUR clip (or voiceover), at the start of each word.
window.REVEAL = {
  mode: "filmed",            // "filmed" = transparent overlay for your own clip; "faceless" = full frame with a character
  duration: 9.0,             // length of your clip or voiceover, in seconds
  colours: {
    background: { name: "Sky Blue",    hex: "#4074AD", text: "#FFFFFF", at: 0.20 },   // "Sky blue ..."
    type:       { name: "Cloud White", hex: "#FFFFFF", text: "#111111", at: 1.00 },   // "... cloud white ..."
    accent:     { name: "Poppy Red",   hex: "#D80506", text: "#FFFFFF", at: 3.10 }    // "... poppy red ..."
  },
  ringAt: 4.20,              // "... steals attention": the accent swatch gets a ring
  layers: ["assets/p1.jpg", "assets/p2.jpg", "assets/p3.jpg"],   // background only, without accent, finished
  // faceless only: your character's poses on transparent backgrounds
  character: { talk: "assets/char-talk.png", point: "assets/char-point.png", thumbs: "assets/char-thumbs.png", thumbsAt: 4.20 }
};
