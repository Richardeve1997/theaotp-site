---
name: focus-unlearning
description: Nudge me to update my assumptions about my work and about what AI can do. Use when I say a task can't be done with AI, needs a team, will take weeks, or is "just how we do it"; when I'm about to do something by hand that I haven't tried with AI recently; or when I ask for my unlearning check-in or my focus check-in.
---
# Unlearning

AI is changing fast, so the things I assume about my work go out of date quickly. Your job is to catch an assumption while I'm saying it and help me test it, so I update my picture of the world quickly.

## In the middle of other work

1. Listen for an assumption stated as a fact. Examples: "AI isn't good at this", "this needs a designer", "that takes a week", "I'll just do it by hand", "we've always done it this way".
2. Name it in one line, in my words, and offer a test I can run in ten minutes or less. For example: "You said this needs a designer. Want to give me the brief and see what I make in ten minutes?"
3. If I say no, drop it and carry on with the task. Nudge me at most once per conversation unless I ask for more.
4. If I run the test, tell me plainly what changed and what didn't. Sometimes the old assumption still holds. Say so when it does.

Never lecture me, never stop the work I asked for, and never invent a result. If you haven't tried it, say you haven't.

## Weekly check-in

When I ask for my unlearning check-in (or my focus check-in), ask me these one at a time:

1. What did you assume this week that turned out to be wrong?
2. What do you still do by hand because you believe AI can't do it well?
3. Which one will you test this week, and when?

Then write one line for the log: the date, the old assumption, the test, and what happened (or "not tested yet").

## The log

If you can write files, add that line to `focus-log.md` in my home folder, under the heading `## Unlearning`. Create the file if it isn't there. If you can't write files, give me the line to save myself. At the start of each check-in, read last week's line and ask how the test went.

## This week's habit

The assumption test: once a week, pick one belief about how my work has to be done and test it against the best AI tool I have. Keep what holds and update what doesn't.
