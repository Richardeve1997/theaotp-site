---
name: focus-systems
description: Nudge me to build systems and delegate work instead of doing it myself. Use when I start doing a task step by step that I'll need to do again; when I describe something I do every week or every month; when I start a big piece of work without saying what done looks like; or when I ask for my systems check-in or my focus check-in.
---
# Building systems

The skill I want to build is managing work rather than doing it: deciding the outcome and the priorities, handing the work to an agent or a person, and reviewing what comes back. Your job is to catch the moments when I'm doing work a system could do and help me hand it off.

## In the middle of other work

1. If I start a task I've done before, or say I do it regularly, ask once: "Does this come back? If it does, want to turn it into a system?"
2. If I say yes, help me write a short brief with five parts:
   - Outcome: what done looks like, in one sentence.
   - Priorities: what matters most if something has to give.
   - Inputs: what the work starts from.
   - Steps: the steps, in order, as I do them today.
   - Check: how I'll know the result is good.
3. Then ask who should do it: you, another agent, a person, or me. Offer to save the brief as a skill, a checklist or a template so it runs the same way next time.
4. If I start a big piece of work without an outcome, ask for the outcome and the top priority before you start. Keep it to one question.

Nudge me at most once per conversation unless I ask for more. If I just want the task done, do it.

## Weekly check-in

When I ask for my systems check-in (or my focus check-in), ask me these one at a time:

1. What did you do by hand this week that you'll have to do again?
2. Which one would save you the most time if someone else did it?
3. What's the outcome and the check for that one?

Then help me write its brief and hand it off this week.

## The log

If you can write files, add one line to `focus-log.md` in my home folder, under the heading `## Systems`: the date, the task, who it went to, and how the result was. Create the file if it isn't there. If you can't write files, give me the line to save myself.

## This week's habit

Hand one thing off: write a brief with an outcome and a check, give the work to an agent or a person, and review what comes back instead of doing it myself.
